package com.example.mushafconsolidated.Adaptersimport

android.content.BroadcastReceiverimport android.content.Contextimport android.content.SharedPreferencesimport android.content.res.ColorStateListimport android.content.res.TypedArrayimport android.graphics.Colorimport android.graphics.Typefaceimport android.graphics.drawable.Drawableimport android.preference.PreferenceManagerimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.webkit.WebViewimport android.widget.ImageViewimport android.widget.TextViewimport androidx.appcompat.widget.AppCompatTextViewimport androidx.cardview.widget.CardViewimport androidx.constraintlayout.widget.Groupimport androidx.core.content.ContextCompatimport androidx.recyclerview.widget.RecyclerViewimport com.example.Constantimport com.example.mushafconsolidated.Adapters.vtwoMushaAudioAdapterimport com.example.mushafconsolidated.Configimport com.example.mushafconsolidated.Entities.QuranEntityimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.colorimport com.example.mushafconsolidated.R.drawableimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.R.stringimport com.example.mushafconsolidated.intrface.OnItemClickListenerOnLongimport com.example.mushafconsolidated.model.CorpusAyahWordimport com.example.utility.FlowLayoutimport com.example.utility.QuranGrammarApplicationimport com.google.android.material.card.MaterialCardViewimport com.google.android.material.floatingactionbutton.FloatingActionButtonimport java.text.MessageFormat
 
 
 
 
 
 
 
 
 
  
 
 
 
 
 
 

//import com.example.mushafconsolidated.Entities.JoinVersesTranslationDataTranslation;
//public class CustomAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements OnItemClickListenerOnLong {
class vtwoMushaAudioAdapter constructor(
    var context: Context,
    private val allofQuran: List<QuranEntity>,
    val mItemClickListener: OnItemClickListenerOnLong?,
    surah_id: Long,
    surahName: String,
    ismakki: Int,
    header: ArrayList<String>
) : RecyclerView.Adapter<vtwoMushaAudioAdapter.ItemViewAdapter>() //implements OnItemClickListenerOnLong {
{
    var broadcastReceiver: BroadcastReceiver? = null
    private val isFABOpen: Boolean = false
    val surah_id: Long
    private val header: ArrayList<String>
    private val SurahName: String
    private val isMakkiMadani: Int
    var arabic: TextView? = null
    var rootword: TextView? = null
    val arabicfontSize: Int
    val translationfontsize: Int
    private var isNightmode: String? = null
    private var headercolor: Int = 0
    private val kathir_translation: WebView? = null
    private var colorwordfont: Typeface? = null
    private val ayahWord: CorpusAyahWord? = null

    init {
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            context
        )
        sharedPreferences.getBoolean(Config.Companion.SHOW_Erab, Config.Companion.defaultShowErab)
        //   this.header = header;
        arabicfontSize = sharedPreferences.getInt("pref_font_arabic_key", 18)
        translationfontsize = sharedPreferences.getInt("pref_font_englsh_key", 18)
        this.surah_id = surah_id
        SurahName = surahName
        isMakkiMadani = ismakki
        this.header = header
    }

    fun addContext(context: Context) {
        this.context = context
    }

    public override fun getItemViewType(position: Int): Int {
        if (position == 0) {
            return vtwoMushaAudioAdapter.Companion.TYPE_HEADER
        } else {
            return vtwoMushaAudioAdapter.Companion.TYPE_ITEM
        }
    }

    public override fun getItemCount(): Int {
        return allofQuran.size

        //     return  quran.size();
    }

    public override fun getItemId(position: Int): Long {
        return allofQuran.get(position).getAyah().toLong()
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): vtwoMushaAudioAdapter.ItemViewAdapter {
        val view: View
        if (viewType == 0) {
            view =
                LayoutInflater.from(parent.getContext()).inflate(R.layout.surah_header, parent, false)
        } else {
            view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.mushaf_row_ayah_word, parent, false)
            //  view = LayoutInflater.from(parent.getContext()).inflate(R.layout.new_mushaf_row_ayah_word, parent, false);
            //   view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_viewer_aya_cardview, parent, false);
        }
        return vtwoMushaAudioAdapter.ItemViewAdapter(view, viewType)
    }

    fun getItem(position: Int): Any {
        return allofQuran.get(position)
    }

    @SuppressLint("ResourceType")
    public override fun onBindViewHolder(
        holder: vtwoMushaAudioAdapter.ItemViewAdapter,
        position: Int
    ) {
        val sharedPreferences: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                context
            )
        isNightmode = sharedPreferences.getString("themepref", "dark")
        //  String arabic_font_selection = sharedPreferences.getString("Arabic_Font_Selection", String.valueOf(MODE_PRIVATE));
        val islamicfont: String = "AlQalam.ttf"
        val arabic_font_selection: String? =
            sharedPreferences.getString("Arabic_Font_Selection", "quranicfontregular.ttf")
        val custom_font: Typeface = Typeface.createFromAsset(
            context.getAssets(),
            islamicfont
        )
        val FONTS_LOCATION_PATH: String = "fonts/DejaVuSans.ttf"
        colorwordfont = Typeface.createFromAsset(
            QuranGrammarApplication.getContext().getAssets(),
            FONTS_LOCATION_PATH
        )
        val showrootkey: Boolean = sharedPreferences.getBoolean("showrootkey", true)
        val showErab: Boolean = sharedPreferences.getBoolean("showErabKey", true)
        val showWordColor: Boolean = sharedPreferences.getBoolean("colortag", true)
        val showTransliteration: Boolean =
            sharedPreferences.getBoolean("showtransliterationKey", true)
        val showJalalayn: Boolean = sharedPreferences.getBoolean("showEnglishJalalayn", true)
        val showTranslation: Boolean = sharedPreferences.getBoolean("showTranslationKey", true)
        val showWordByword: Boolean = sharedPreferences.getBoolean("wordByWord", false)
        val showKathir: Boolean = sharedPreferences.getBoolean("showKathir", false)
        //bg_black
        if (position % 2 == 1) {
            when (isNightmode) {
                "brown" -> holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(
                        context, color.bg_brown
                    )
                )

                "dark" -> holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(
                        context,
                        color.odd_item_bg_black
                    )
                )

                "blue" -> holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(
                        context,
                        color.bg_dark_blue
                    )
                )
            }
            //  holder.imageView.setBackgroundColor(Color.parseColor("#FFFFFF"));
        } else {
            when (isNightmode) {
                "brown" -> holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(
                        context, color.odd_item_bg_brown
                    )
                )

                "dark" -> holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(
                        context,
                        color.bg_black
                    )
                )

                "blue" -> holder.itemView.setBackgroundColor(
                    ContextCompat.getColor(
                        context,
                        color.bg_dark_blue
                    )
                )
            }
        }
        val whichtranslation: String? = sharedPreferences.getString("selecttranslation", "en_sahih")
        if (getItemViewType(position) == 0) {
            val imgs: TypedArray = context.getResources().obtainTypedArray(R.array.sura_imgs)

            // You have to set your header items values with the help of model class and you can modify as per your needs
            holder.tvRukus.setText(String.format("Ruku's :%s", header.get(0)))
            holder.tvVerses.setText(String.format("Aya's :%s", header.get(1)))
            holder.tvSura.setText(header.get(3))
            val chapterno: String = header.get(2)
            val tauba: Int = chapterno.toInt()
            if (tauba == 9) {
                holder.ivBismillah.setVisibility(View.GONE)
            }
            if (isMakkiMadani == 1) {
                holder.ivLocationmakki.setVisibility(View.VISIBLE)
                holder.ivLocationmadani.setVisibility(View.GONE)
            } else {
                holder.ivLocationmadani.setVisibility(View.VISIBLE)
                holder.ivLocationmakki.setVisibility(View.GONE)
            }
            val drawable: Drawable? = imgs.getDrawable(chapterno.toInt() - 1)
            imgs.recycle()
            holder.ivSurahIcon.setImageDrawable(drawable)
            if ((isNightmode == "dark") || (isNightmode == "blue") || (isNightmode == "green")) {
                headercolor = Color.YELLOW
                holder.ivLocationmakki.setColorFilter(Color.CYAN)
                holder.ivSurahIcon.setColorFilter(Color.CYAN)
                holder.ivLocationmadani.setColorFilter(Color.CYAN)
            } else {
                headercolor = Color.BLUE
                holder.ivLocationmakki.setColorFilter(Color.BLACK)
                holder.ivSurahIcon.setColorFilter(Color.BLACK)
                holder.ivLocationmadani.setColorFilter(Color.BLACK)
            }
        } else {
            displayAyats(
                showrootkey,
                holder,
                position,
                sharedPreferences,
                custom_font,
                showErab,
                showWordColor,
                showTransliteration,
                showJalalayn,
                showTranslation,
                showWordByword,
                whichtranslation,
                showKathir
            )
        }
    }

    fun displayAyats(
        showrootkey: Boolean,
        holder: vtwoMushaAudioAdapter.ItemViewAdapter,
        position: Int,
        sharedPreferences: SharedPreferences?,
        custom_font: Typeface?,
        showErab: Boolean,
        showWordColor: Boolean,
        showTransliteration: Boolean,
        showJalalayn: Boolean,
        showTranslation: Boolean,
        showWordByword: Boolean,
        whichtranslation: String?,
        showKathir: Boolean
    ) {
        //   holder.flowwbw.setBackgroundColor(R.style.Theme_DarkBlue);
        var entity: QuranEntity? = null


        //   String wbw = sharedPreferences.getString("wordByWord", String.valueOf(Context.MODE_PRIVATE));
        try {
            entity = allofQuran.get(position - 1)
        } catch (e: IndexOutOfBoundsException) {
            println("check")
        }
        var aya: String? = ""
        if (null != entity) {
            storepreferences(entity)
        }
        val  : String  = String ()
        val suraName: String = ""
        // suraName = getSuraNameFromIndex(item.getAyahItems().get(0).getSurahIndex());
        val tempSuraName: String = ""
        for (quran: QuranEntity in allofQuran) {
            aya = quran.getQurantext()
            // add sura name
            val isFirst: Boolean = true
            val bb: String  = String ()
            bb.append(aya).append("﴿ { ").append(quran.getAyah()).append("} ﴾")


            //     .append(aya); // +1 as substring upper bound is excluded
            //   .append("\n");
            // cute ayah
            //  aya = aya.substring(pos+1); // +1 to start with new character after البسملة
             .append(bb.toString())
            holder.quran_textView.setText( .toString())
            holder.quran_textView.setTextSize(arabicfontSize.toFloat())
            holder.quran_textView.setTypeface(custom_font)
        }


        /*    if(entity.getPassage_no()!=0){
            String    = new String ();
             .append(entity.getQurantext());
             .append(MessageFormat.format("{0} ﴿ {1} ﴾ {2}", aya, entity.getAyah(),R.drawable.ruku_new));
            //      .append("۩");
            holder.quran_textView.setText(entity.getQurantext());
            holder.quran_textView.setTextSize(arabicfontSize);
            holder.quran_textView.setTypeface(custom_font);

          //  holder.sajdaverse.setImageResource(R.drawable.ruku_new);

        }*/if (entity!!.getHas_prostration() == 1) {
            val  s: String  = String ()
             .append(entity.getQurantext())
             .append(MessageFormat.format("{0} ﴿ {1} ﴾ ۩", aya, entity.getAyah()))
            //      .append("۩");
            holder.quran_textView.setText( .toString())
            holder.quran_textView.setTextSize(arabicfontSize.toFloat())
            holder.quran_textView.setTypeface(custom_font)
        } else {
            val  s: String  = String ()
             .append(entity.getQurantext())
             .append(MessageFormat.format("{0} ﴿ {1} ﴾ ", aya, entity.getAyah()))
            holder.quran_textView.setText( .toString())
            holder.quran_textView.setTextSize(arabicfontSize.toFloat())
            holder.quran_textView.setTypeface(custom_font)
        }
        if (entity.getPassage_no() != 0) {
            holder.sajdaverse.setVisibility(View.VISIBLE)
        } else {
            holder.sajdaverse.setVisibility(View.GONE)
        }
        println("Position" + position)
        if (showTranslation) {
            if ((whichtranslation == "en_arberry")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getEn_arberry())
                }
                holder.translate_textViewnote.setText(string.arberry)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_sahih")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getTranslation())
                }
                holder.translate_textViewnote.setText(string.ensahih)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_jalalayn")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getEn_jalalayn())
                }
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_jalalayn")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getUr_jalalayn())
                }
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_junagarhi")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getUr_junagarhi())
                }
                holder.translate_textViewnote.setText(string.urjunagadi)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setVisibility(View.VISIBLE)
            holder.translate_textViewnote.setVisibility(View.VISIBLE)
        }
    }

    private fun storepreferences(entity: QuranEntity) {
        val pref: SharedPreferences = context.getSharedPreferences("lastread", Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = pref.edit()
        editor.putInt(Constant.CHAPTER, entity.getSurah())
        editor.putInt(Constant.AYAH_ID, entity.getAyah())
        editor.putString(Constant.SURAH_ARABIC_NAME, SurahName)
        editor.apply()
        //  editor.commit();
    }

    private fun setChapterInfo(holder: vtwoMushaAudioAdapter.ItemViewAdapter, verse: QuranEntity) {
        val surahInfo: String  = String ()
        //        surahInfo.append(surahName+".");
        surahInfo.append(verse.getSurah()).append(".")
        surahInfo.append(verse.getAyah()).append("-")
        surahInfo.append(SurahName)
        val sharedPreferences: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                context
            )
        val isNightmode: String? = sharedPreferences.getString("theme", "dark")
        if (isMakkiMadani == 1) {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                drawable.ic_makkah_48,
                0,
                0,
                0
            )
        } else {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                drawable.ic_madinah_48,
                0,
                0,
                0
            )
        }
        if ((isNightmode == "dark") || (isNightmode == "blue") || (isNightmode == "green")) {
//TextViewCompat.setCompoundDrawableTintList()
            holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.CYAN))
        } else {
            holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.BLUE))
        }
        holder.surah_info.setText(surahInfo)
        holder.surah_info.setTextSize(16f)
        //  holder.surah_info.setTextColor(ContextCompat.getColor(context,R.color.colorOnPrimary));
    }

    inner class ItemViewAdapter internal constructor(view: View, viewType: Int) :
        RecyclerView.ViewHolder(view), View.OnClickListener, View.OnLongClickListener {
        var quran_jalalayn: TextView? = null
        var kathir_translation: TextView? = null
        var quran_transliteration: TextView? = null
        var translate_textView: TextView? = null

        //   public TextView erab_textView;
        var erab_textView: TextView? = null
        var surah_info: TextView? = null
        var mafoolbihi: TextView? = null
        var bismilla: TextView? = null
        var quran_transliterationnote: TextView? = null
        var quran_jalalaynnote: TextView? = null
        var erab_textViewnote: TextView? = null
        var translate_textViewnote: TextView? = null
        var bookmark: ImageView? = null
        var jumpto: ImageView? = null
        var makkimadaniicon: ImageView? = null
        var ivSummary: ImageView? = null
        var expandImageButton: ImageView? = null
        var ivBismillah: ImageView? = null
        var erabexpand: ImageView? = null
        var erab_notes_expand: ImageView? = null
        var tvSura: TextView? = null
        var tvRukus: TextView? = null
        var tvVerses: TextView? = null
        var quran_textView: AppCompatTextView? = null
        var sajdaverse: ImageView? = null
        var ivSurahIcon: ImageView? = null
        var ivLocationmakki: ImageView? = null
        var ivLocationmadani: ImageView? = null
        var ivhelp: ImageView? = null
        var ivoverflow: ImageView? = null
        var ivoverflow2: ImageView? = null
        var arrowforward: ImageView? = null
        var arrowback: ImageView? = null

        //  public   com.nex3z.flowlayout.FlowLayout  flow_word_by_word;
        var flow_word_by_word: FlowLayout? = null

        //   RelativeLayout colllayout;
        var erabnotescardView: CardView? = null
        var kahteercardview: CardView? = null
        var mafoolatarow: ImageView? = null
        var showkatheer: ImageView? = null
        var hiddenGroup: Group? = null
        var card_group: Group? = null
        var base_cardview: MaterialCardView? = null
        var tafsir: FloatingActionButton? = null
        var jumptofb: FloatingActionButton? = null
        var bookmarfb: FloatingActionButton? = null
        var fabmenu: FloatingActionButton? = null
        var helpfb: FloatingActionButton? = null
        var summbaryfb: FloatingActionButton? = null
        var sharescreenfb: FloatingActionButton? = null

        init {
            view.setTag(this)
            itemView.setOnClickListener(this)
            if (viewType == 0) {
                ivLocationmakki = view.findViewById(id.ivLocationmakki)
                ivLocationmadani = view.findViewById(id.ivLocationmadani)
                ivSurahIcon = view.findViewById(id.ivSurahIcon)
                tvVerses = view.findViewById(id.tvVerses)
                tvRukus = view.findViewById(id.tvRukus)
                tvSura = view.findViewById(id.tvSura)
                ivBismillah = view.findViewById(id.ivBismillah)
            } else {
                //     kathir_note = view.findViewById(R.id.kathir_note);
                sajdaverse = view.findViewById(id.sajda)
                makkimadaniicon = view.findViewById(id.makkimadaniicon)
                translate_textViewnote = view.findViewById(id.translate_textViewnote)
                surah_info = view.findViewById(id.chaptername)
                //    verse_idTextView = view.findViewById(R.id.verse_id_textView);
                translate_textView = view.findViewById(id.translate_textView)

                //     erab_textView.setTextIsSelectable(true);
                quran_textView = view.findViewById(id.quran_textView)
                base_cardview = view.findViewById(id.base_cardview)
                view.setOnClickListener(this)
                view.setOnLongClickListener(this)
                quran_textView.setOnClickListener(this)
                quran_textView.setTag("verse")
                val shared: SharedPreferences =
                    androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                        QuranGrammarApplication.getContext()
                    )
                val colortag: Boolean = shared.getBoolean("colortag", true)
            }
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getLayoutPosition())
            }
        }

        public override fun onLongClick(v: View): Boolean {
            //   mItemClickListener.onItemLongClick(getAdapterPosition(), v);
            mItemClickListener!!.onItemLongClick(getBindingAdapterPosition(), v)
            return true
        }
    } //View.OnClickListener, View.OnLongClickListener

    companion object {
        private val TYPE_HEADER: Int = 0
        private val TYPE_ITEM: Int = 1
    }
}