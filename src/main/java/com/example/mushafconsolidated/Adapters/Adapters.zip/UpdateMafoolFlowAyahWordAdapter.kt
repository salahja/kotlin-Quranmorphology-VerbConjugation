package com.example.mushafconsolidated.Adaptersimport

android.app.Activityimport android.content.Contextimport android.content.SharedPreferencesimport android.content.pm.PackageManagerimport android.content.res.ColorStateListimport android.content.res.TypedArrayimport android.graphics.Colorimport android.graphics.Paintimport android.graphics.Typefaceimport android.graphics.drawable.Drawableimport android.os.Buildimport android.os.Bundleimport android.os.Environmentimport android.preference.PreferenceManagerimport android.text.Html import android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.widget.ImageViewimport android.widget.TextViewimport android.widget.Toastimport androidx.annotation .RequiresApiimport androidx.appcompat.app.AppCompatActivityimport androidx.appcompat.widget.SwitchCompatimport androidx.core.app.ActivityCompatimport androidx.core.content.ContextCompatimport androidx.fragment.app.FragmentManagerimport androidx.fragment.app.FragmentTransactionimport androidx.recyclerview.widget.RecyclerViewimport com.example.Constantimport com.example.mushafconsolidated.Adapters.UpdateMafoolFlowAyahWordAdapterimport com.example.mushafconsolidated.Configimport com.example.mushafconsolidated.Entities.QuranEntityimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.animimport com.example.mushafconsolidated.R.drawableimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.R.stringimport com.example.mushafconsolidated.Utilsimport com.example.mushafconsolidated.fragments.SentenceAnalysisBottomSheetimport com.example.mushafconsolidated.fragments.WordAnalysisBottomSheetimport com.example.mushafconsolidated.intrface.OnItemClickListenerOnLongimport com.example.mushafconsolidated.model.CorpusAyahWordimport com.example.mushafconsolidated.model.CorpusWbwWordimport com.example.utility.AnimationUtilityimport com.example.utility.CorpusUtilityorigimport com.example.utility.FileUtilityimport com.example.utility.FlowLayoutimport com.example.utility.PreferenceUtilimport com.example.utility.QuranGrammarApplicationimport java.io.Fileimport java.io.FileOutputStreamimport java.io.FileWriterimport java.io.IOException












 





//import com.example.mushafconsolidated.Entities.JoinVersesTranslationDataTranslation;
//public class CustomAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements OnItemClickListenerOnLong {
class UpdateMafoolFlowAyahWordAdapter constructor(
    private val header: ArrayList<String>,
    private val allofQuran: List<QuranEntity>,
    private val ayahWordArrayList: ArrayList<CorpusAyahWord>,
    var context: Context,
    val surah_id: Long,
    private val SurahName: String,
    private val isMakkiMadani: Int,
    listener: OnItemClickListenerOnLong?
) : RecyclerView.Adapter<UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter>(),
    OnItemClickListenerOnLong {
    private val issentence: Boolean
    private val sharedPreferences: SharedPreferences
    var adapterposition: Int = 0
    var arabic: TextView? = null
    var rootword: TextView? = null
    var wordno: TextView? = null
    var arabicfontSize: Int
    var translationfontsize: Int
    var mItemClickListener: OnItemClickListenerOnLong?
    var pref: PreferenceUtil? = null
    private val onclicklistner: OnItemClickListenerOnLong? = null
    private var isNightmode: String? = null

    init {
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(context)
        //   showTranslation =
        //        sharedPreferences.getBoolean(Config.SHOW_TRANSLATION, Config.defaultShowTranslation);
        sharedPreferences.getBoolean(Config.Companion.SHOW_Erab, Config.Companion.defaultShowErab)
        issentence = sharedPreferences.getBoolean("grammarsentence", false)
        arabicfontSize = sharedPreferences.getInt("pref_font_arabic_key", 18)
        translationfontsize = sharedPreferences.getInt("pref_font_englsh_key", 18)
        mItemClickListener = listener
    }

    fun setItemClickListener(clickListener: View.OnClickListener?) {
        //   private final List<QuranEntity> translations;
        //  privviewate final List<QuranEntity> erab;
    }

    fun addContext(context: Context) {
        this.context = context
    }

    fun SetOnItemClickListener(mItemClickListener: OnItemClickListenerOnLong?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun getItemViewType(position: Int): Int {
        if (position == 0) {
            return UpdateMafoolFlowAyahWordAdapter.Companion.TYPE_HEADER
        } else {
            return UpdateMafoolFlowAyahWordAdapter.Companion.TYPE_ITEM
        }
    }

    public override fun getItemCount(): Int {
        return ayahWordArrayList.size + 1
        //     return  quran.size();
    }

    public override fun getItemId(position: Int): Long {
        val ayahWord: CorpusAyahWord = ayahWordArrayList.get(position)
        var itemId: Long = 0
        for (word: CorpusWbwWord in ayahWord.getWord()) {
            itemId = word.getVerseId().toLong()
        }
        return itemId
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter {
        val view: View
        if (viewType == 0) {
            view =
                LayoutInflater.from(parent.getContext()).inflate(R.layout.surah_header, parent, false)
            return UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter(view, viewType)
        } else {
            view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_ayah_word, parent, false)
            //   view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_viewer_aya_cardview, parent, false);
            return UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter(view, viewType)
        }
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    public override fun onBindViewHolder(
        holder: UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter,
        position: Int
    ) {
        val sharedPreferences: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                context
            )
        isNightmode = sharedPreferences.getString("themepref", "dark")
        val arabic_font_selection: String? =
            sharedPreferences.getString("Arabic_Font_Selection", "quranicfontregular.ttf")
        val custom_font: Typeface = Typeface.createFromAsset(
            context.getAssets(),
            arabic_font_selection
        )
        val showrootkey: Boolean = sharedPreferences.getBoolean("showrootkey", true)
        val showErab: Boolean = sharedPreferences.getBoolean("showErabKey", true)
        val showWordColor: Boolean = sharedPreferences.getBoolean("colortag", true)
        val showTransliteration: Boolean =
            sharedPreferences.getBoolean("showtransliterationKey", true)
        val showJalalayn: Boolean = sharedPreferences.getBoolean("showEnglishJalalayn", true)
        val showTranslation: Boolean = sharedPreferences.getBoolean("showTranslationKey", true)
        val showWordByword: Boolean = sharedPreferences.getBoolean("wordByWord", false)
        val showKathir: Boolean = sharedPreferences.getBoolean("showKathir", false)
        val whichtranslation: String? = sharedPreferences.getString("selecttranslation", "en_sahih")
        if (getItemViewType(position) == 0) {
            val imgs: TypedArray = context.getResources().obtainTypedArray(R.array.sura_imgs)
            // You have to set your header items values with the help of model class and you can modify as per your needs
            holder.tvRukus.setText("Ruku's :" + header.get(0))
            holder.tvVerses.setText("Aya's :" + header.get(1))
            holder.tvSura.setText(header.get(3))
            val chapterno: String = header.get(2)
            val tauba: Int = chapterno.toInt()
            if (tauba == 9) {
                holder.ivBismillah.setVisibility(View.GONE)
            }
            if (isMakkiMadani == 1) {
                holder.ivLocationmakki.setVisibility(View.VISIBLE)
                holder.ivLocationmadani.setVisibility(View.GONE)
            } else {
                holder.ivLocationmadani.setVisibility(View.VISIBLE)
                holder.ivLocationmakki.setVisibility(View.GONE)
            }
            val drawable: Drawable? = imgs.getDrawable(chapterno.toInt() - 1)
            holder.ivSurahIcon.setImageDrawable(drawable)
            if ((isNightmode == "dark") || (isNightmode == "blue")) {
                holder.ivLocationmakki.setColorFilter(Color.CYAN)
                holder.ivSurahIcon.setColorFilter(Color.CYAN)
                holder.ivLocationmadani.setColorFilter(Color.CYAN)
            } else {
                holder.ivLocationmakki.setColorFilter(Color.BLACK)
                holder.ivSurahIcon.setColorFilter(Color.BLACK)
                holder.ivLocationmadani.setColorFilter(Color.BLACK)
            }
        } else {
            displayAyats(
                showrootkey,
                holder,
                position - 1,
                sharedPreferences,
                custom_font,
                showErab,
                showWordColor,
                showTransliteration,
                showJalalayn,
                showTranslation,
                showWordByword,
                whichtranslation,
                showKathir
            )
        }
    }

    private fun displayAyats(
        showrootkey: Boolean,
        holder: UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter,
        position: Int,
        sharedPreferences: SharedPreferences,
        custom_font: Typeface,
        showErab: Boolean,
        showWordColor: Boolean,
        showTransliteration: Boolean,
        showJalalayn: Boolean,
        showTranslation: Boolean,
        showWordByword: Boolean,
        whichtranslation: String?,
        showKathir: Boolean
    ) {
        //   holder.flowwbw.setBackgroundColor(R.style.Theme_DarkBlue);
        var entity: QuranEntity? = null
        val erabentity: QuranEntity? = null
        val wbw: String? = sharedPreferences.getString("wbw", Context.MODE_PRIVATE.toString())
        val actualposition: Int = position
        try {
            entity = allofQuran.get(actualposition)
        } catch (e: IndexOutOfBoundsException) {
            println("check")
        }
        val ayahWord: CorpusAyahWord = ayahWordArrayList.get(actualposition)
        if (null != entity) {
            storepreferences(entity)
        }
        val quranverses: SpannableString = ayahWordArrayList.get(actualposition).getSpannableverse()
        holder.quran_textView.setText(quranverses)
        holder.quran_textView.setTextSize(arabicfontSize.toFloat())
        holder.quran_textView.setTypeface(custom_font)
        setChapterInfo(holder, ayahWord)
        adapterposition = actualposition
        wordBywordWithTranslation(
            showrootkey,
            holder,
            custom_font,
            showWordColor,
            wbw,
            ayahWord,
            showWordByword
        )
        if (showKathir) {
            holder.kathir_translation.setText(
                Html.fromHtml(
                    entity!!.getTafsir_kathir(),
                    Html.FROM_HTML_MODE_LEGACY
                )
            )
            holder.kathir_translation.setTextSize(translationfontsize.toFloat())
            holder.kathir_translation.setTextSize(translationfontsize.toFloat())
            //   holder.kathir_translation.setVisibility(View.VISIBLE);
            holder.kathir_note.setVisibility(View.VISIBLE)
        }
        if (showTransliteration) {
            holder.quran_transliteration.setText(
                Html.fromHtml(
                    entity!!.getTranslation(),
                    Html.FROM_HTML_MODE_LEGACY
                )
            )
            holder.quran_transliteration.setTextSize(translationfontsize.toFloat())
            holder.quran_transliteration.setTextSize(translationfontsize.toFloat())
            holder.quran_transliteration.setVisibility(View.VISIBLE)
        }
        if (showJalalayn) {
            //   holder.quran_jalalaynnote.setText(enjalalayn.getAuthor_name());
            holder.quran_jalalayn.setText(entity!!.getEn_jalalayn())
            holder.quran_jalalayn.setTextSize(translationfontsize.toFloat())
            holder.quran_jalalayn.setTextSize(translationfontsize.toFloat())
            holder.quran_jalalayn.setVisibility(View.VISIBLE)
            holder.quran_jalalaynnote.setVisibility(View.VISIBLE)
        }
        if (showTranslation) {
            if ((whichtranslation == "en_arberry")) {
                holder.translate_textView.setText(entity!!.getEn_arberry())
                holder.translate_textViewnote.setText(string.arberry)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_sahih")) {
                holder.translate_textView.setText(entity!!.getTranslation())
                holder.translate_textViewnote.setText(string.ensahih)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_jalalayn")) {
                holder.translate_textView.setText(entity!!.getEn_jalalayn())
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_jalalayn")) {
                holder.translate_textView.setText(entity!!.getUr_jalalayn())
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_junagarhi")) {
                holder.translate_textView.setText(entity!!.getUr_junagarhi())
                holder.translate_textViewnote.setText(string.urjunagadi)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setVisibility(View.VISIBLE)
            holder.translate_textViewnote.setVisibility(View.VISIBLE)
        }
        if (showErab) {
            holder.erab_textView.setText(entity!!.getErabspnabble())
            //   holder.erab_textView.setText(entity.getAr_irab_two());
            //     holder.erab_textView.setText(erabentity.getErabspnabble());
            holder.erab_textView.setTextSize(translationfontsize.toFloat())
            holder.erab_textView.setTypeface(custom_font)
            //     holder.erab_textView.setVisibility(View.VISIBLE);
            holder.erab_textViewnote.setVisibility(View.VISIBLE)


            /*
if (SharedPref.themePreferences().equals("dark")) {
  holder.erab_textView.setTextColor(QuranGrammarApplication.getContext().getResources().getColor(R.color.white));

} else {
  holder.erab_textView.setTextColor(QuranGrammarApplication.getContext().getResources().getColor(R.color.burntamber));

}
*/
        }
    }

    private fun wordBywordWithTranslation(
        showrootkey: Boolean,
        holder: UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter,
        custom_font: Typeface,
        showWordColor: Boolean,
        wbw: String?,
        ayahWord: CorpusAyahWord,
        showWbwTranslation: Boolean
    ) {
        val inflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        holder.flow_word_by_word.removeAllViews()
        for (word: CorpusWbwWord in ayahWord.getWord()) {
            val view: View = inflater.inflate(R.layout.word_by_word, null)
            //      arabic.setOnLongClickListener((OnLongClickListener) this);
            //   final TextView arabic = view.findViewById(R.id.word_arabic_textView);
            arabic = view.findViewById(id.word_arabic_textView)
            rootword = view.findViewById(id.root_word)
            wordno = view.findViewById(id.wordno)
            val translation: TextView = view.findViewById(id.word_trans_textView)
            var spannedroot: SpannableString? = null
            wordno.setText(word.getWordno().toString())
            wordno.setTextSize(arabicfontSize.toFloat())
            wordno.setVisibility(View.VISIBLE)
            if (showrootkey) {
                if (!word.getRootword().isEmpty()) {
                    spannedroot = getSpannedRoots(word)
                    rootword.setText(spannedroot)
                    rootword.setTextSize(arabicfontSize.toFloat())
                    rootword.setVisibility(View.VISIBLE)
                } else {
                    spannedroot = SpannableString.valueOf(word.getRootword())
                    rootword.setText(spannedroot)
                    rootword.setTextSize(arabicfontSize.toFloat())
                    rootword.setVisibility(View.VISIBLE)
                }
            }
            if (showWordColor) {
                var spannedword: SpannableString? = null
                word.getRootword()
                spannedword = getSpannedWords(word)
                //   arabic.setText(fixArabic(String.valueOf(spannedword)));
                spannedword.toString().replace(" ".toRegex(), "")
                arabic.setText(spannedword)
            } else {
                arabic.setText(word.getWordsAr())
            }
            rootword.setText(spannedroot)
            rootword.setTextSize(arabicfontSize.toFloat())
            //  arabic.setTextSize(18);
            arabic.setTextSize(arabicfontSize.toFloat())
            arabic.setTypeface(custom_font)
            if (showWbwTranslation) {
                if ((wbw == "en")) {
                    translation.setText(word.getTranslateEn())
                    translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                } else if ((wbw == "bn")) {
                    translation.setText(word.getTranslateBn())
                    translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                } else if ((wbw == "in")) {
                    translation.setText(word.getTranslateIndo())
                    translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                } else if ((wbw == "ur")) {
                    translation.setText(word.getTranslationUrdu())
                    translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                }
                //  translation.setTextColor(context.getResources().getColor(R.color.neutral2));
            }
            //    translation.setTextSize(forntSize + 4);
            translation.setTextSize(arabicfontSize.toFloat())
            holder.flow_word_by_word.addView(view)
            val fael: String  = String ()
            view.setLongClickable(true)
            view.setOnLongClickListener(object : View.OnLongClickListener {
                public override fun onLongClick(v: View?): Boolean {
                    val utils: Utils = Utils(QuranGrammarApplication.getContext())
                    return true
                }
            })
            view.setOnClickListener(object : View.OnClickListener {
                @RequiresApi(api = Build.VERSION_CODES.N)
                public override fun onClick(view: View?) {
                    val utils: Utils = Utils(QuranGrammarApplication.getContext())
                    val filename: String = "mafool.csv"
                    //  writetofile(filename,word.getSurahId(), word.getVerseId(), word.getWordno(),word.getWordsAr());
                    val fl: FileUtility = FileUtility(context)
                    FileUtility.writetofile(
                        filename,
                        word.getSurahId(),
                        word.getVerseId(),
                        word.getWordno(),
                        word.getWordsAr()
                    )
                    Toast.makeText(
                        QuranGrammarApplication.getContext(),
                        "inserted",
                        Toast.LENGTH_SHORT
                    ).show()
                }

                private fun writetofile(
                    filename: String,
                    surahId: Int,
                    verseId: Int,
                    wordno: Int,
                    wordsAr: String
                ) {
                    val ammended: ArrayList<String> = ArrayList()
                    ammended.add(surahId.toString() + "|" + verseId + "|" + wordno + "|" + wordsAr + "|")
                    val state: String = Environment.getExternalStorageState()
                    if ((Environment.MEDIA_MOUNTED == state)) {
                        var myWriter: FileWriter?
                        var s: String?
                        if (checkPermission()) {
                            val sdcard: File = Environment.getExternalStorageDirectory()
                            val dir: File = File(sdcard.getAbsolutePath() + "/text/")
                            dir.mkdir()
                            val file: File = File(dir, filename)
                            val os: FileOutputStream
                            try {
                                os = FileOutputStream(file, true)
                                //      os.write(harfNasbIndexArrayList.toString().getBytes());
                                for (str: Any in ammended) {
                                    os.write(str.toString().toByteArray())
                                    val newline: String = "\n"
                                    os.write(newline.toByteArray())
                                }
                                os.close()
                            } catch (e: IOException) {
                                e.printStackTrace()
                            }
                        } else {
                            requestPermission() // Code for permission
                        }
                    }
                }

                private fun requestPermission() {
                    if (ActivityCompat.shouldShowRequestPermissionRationale(
                            (context as Activity?)!!,
                            Manifest.permission.WRITE_EXTERNAL_STORAGE
                        )
                    ) {
                        Toast.makeText(
                            QuranGrammarApplication.getContext() as Activity?,
                            "Write External Storage permission allows us to create files. Please allow this permission in App Settings.",
                            Toast.LENGTH_LONG
                        ).show()
                    } else {
                        ActivityCompat.requestPermissions(
                            (context as Activity?)!!,
                            arrayOf(Manifest.permission.WRITE_EXTERNAL_STORAGE),
                            100
                        )
                    }
                }

                private fun checkPermission(): Boolean {
                    val result: Int = ContextCompat.checkSelfPermission(
                        (context as Activity?)!!,
                        Manifest.permission.WRITE_EXTERNAL_STORAGE
                    )
                    return result == PackageManager.PERMISSION_GRANTED
                }

                private fun LoadItemList(dataBundle: Bundle) {
                    if (issentence) {
                        val item: SentenceAnalysisBottomSheet = SentenceAnalysisBottomSheet()
                        //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                        val fragmentManager: FragmentManager =
                            (context as AppCompatActivity).getSupportFragmentManager()
                        item.setArguments(dataBundle)
                        val data: Array<String> = arrayOf(
                            word.getSurahId().toString(),
                            word.getVerseId().toString(),
                            word.getTranslateEn(),
                            (word.getWordno()).toString()
                        )
                        val transactions: FragmentTransaction =
                            fragmentManager.beginTransaction().setCustomAnimations(
                                anim.abc_slide_in_top, android.R.anim.fade_out
                            )
                        //   transactions.show(item);
                        SentenceAnalysisBottomSheet.Companion.newInstance(data).show(
                            (context as AppCompatActivity).getSupportFragmentManager(),
                            SentenceAnalysisBottomSheet.Companion.TAG
                        )
                    } else {
                        val item: WordAnalysisBottomSheet = WordAnalysisBottomSheet()
                        //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                        val fragmentManager: FragmentManager =
                            (context as AppCompatActivity).getSupportFragmentManager()
                        item.setArguments(dataBundle)
                        val data: Array<String> = arrayOf(
                            word.getSurahId().toString(),
                            word.getVerseId().toString(),
                            word.getTranslateEn(),
                            (word.getWordno()).toString(),
                            SurahName
                        )
                        val transactions: FragmentTransaction =
                            fragmentManager.beginTransaction().setCustomAnimations(
                                anim.abc_slide_in_top, android.R.anim.fade_out
                            )
                        //   transactions.show(item);
                        WordAnalysisBottomSheet.Companion.newInstance(data).show(
                            (context as AppCompatActivity).getSupportFragmentManager(),
                            WordAnalysisBottomSheet.Companion.TAG
                        )
                    }
                }
            })
        }
        holder.flow_word_by_word.setVisibility(View.VISIBLE)
    }

    private fun getSpannedRoots(corpus: CorpusWbwWord): SpannableString {
        val b: Boolean =
            corpus.getVerseId() == 20 && (corpus.getWordno() == 2 || corpus.getWordno() == 9)
        if (b) {
            println("check")
        }
        val spannableString : SpannableString = CorpusUtilityorig.ColorizeRootword(
            corpus.getTagone(),
            corpus.getTagtwo(),
            corpus.getTagthree(),
            corpus.getTagfour(),
            corpus.getTagfive(),
            corpus.getRootword()
        )
        return spannableString 
    }

    private fun getSpannedWords(corpus: CorpusWbwWord): SpannableString {
        val b: Boolean =
            corpus.getVerseId() == 20 && (corpus.getWordno() == 2 || corpus.getWordno() == 9)
        if (b) {
            println("check")
        }
        val spannableString : SpannableString = CorpusUtilityorig.NewSetWordSpan(
            corpus.getTagone(),
            corpus.getTagtwo(),
            corpus.getTagthree(),
            corpus.getTagfour(),
            corpus.getTagfive(),
            corpus.getAraone(),
            corpus.getAratwo(),
            corpus.getArathree(),
            corpus.getArafour(),
            corpus.getArafive()
        )
        return spannableString 
    }

    private fun storepreferences(entity: QuranEntity) {
        val pref: SharedPreferences = context.getSharedPreferences("lastread", Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = pref.edit()
        editor.putInt(Constant.CHAPTER, entity.getSurah())
        editor.putInt(Constant.AYAH_ID, entity.getAyah())
        editor.putString(Constant.SURAH_ARABIC_NAME, SurahName)
        editor.apply()
        editor.commit()
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private fun setChapterInfo(
        holder: UpdateMafoolFlowAyahWordAdapter.ItemViewAdapter,
        verse: CorpusAyahWord
    ) {
        val surahInfo: String  = String ()
        //        surahInfo.append(surahName+".");
        surahInfo.append(verse.getWord().get(0).getSurahId()).append(".")
        surahInfo.append(verse.getWord().get(0).getVerseId()).append("-")
        surahInfo.append(SurahName)
        val sharedPreferences: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                context
            )
        val isNightmode: String? = sharedPreferences.getString("themepref", "dark")
        if (isMakkiMadani == 1) {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                drawable.ic_makkah_48,
                0,
                0,
                0
            )
            if ((isNightmode == "dark") || (isNightmode == "blue")) {
//TextViewCompat.setCompoundDrawableTintList()
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.WHITE))
            } else {
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.BLACK))
            }
        } else {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                drawable.ic_madinah_48,
                0,
                0,
                0
            )
            if ((isNightmode == "dark") || (isNightmode == "blue")) {
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.WHITE))
            } else {
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.BLACK))
            }
        }
        holder.surah_info.setText(surahInfo)
        holder.surah_info.setTextSize(arabicfontSize.toFloat())
        //  holder.surah_info.setTextColor(context.getResources().getColor(R.color.colorOnPrimary));
    }

    private fun fixArabic(s: String): String {
        // Add sukun on mem | nun
        var s: String = s
        s = s.replace("\u0000".toRegex(), "")
        s = s.replace("([\u0645\u0646])([ \u0627-\u064A]|$)".toRegex(), "$1\u0652$2")
        // Tatweel + Hamza Above (joining chairless hamza) => Yeh With Hamza Above
        s = s.replace("\u0640\u0654".toRegex(), "\u0626")
        return s
    }

    private fun getStringInt(sp: SharedPreferences, key: String, defValue: Int): Int {
        return sp.getString(key, Integer.toString(defValue))!!.toInt()
    }

    fun setListener(listener: OnItemClickListenerOnLong?) {
        mItemClickListener = listener
    }

    fun getItem(position: Int) {}
    public override fun onItemClick(v: View, position: Int) {}
    public override fun onItemLongClick(position: Int, v: View) {}
    inner class ItemViewAdapter internal constructor(view: View, viewType: Int) :
        RecyclerView.ViewHolder(view), View.OnClickListener, View.OnLongClickListener {
        var verse_idTextView: TextView? = null
        var quran_jalalayn: TextView? = null
        var kathir_translation: TextView? = null
        var kathir_note: TextView? = null
        var quran_transliteration: TextView? = null
        var translate_textView: TextView? = null
        var erab_textView: TextView? = null
        var surah_info: TextView? = null
        var bismilla: TextView? = null
        var quran_textView: TextView? = null
        var quran_transliterationnote: TextView? = null
        var quran_jalalaynnote: TextView? = null
        var erab_textViewnote: TextView? = null
        var translate_textViewnote: TextView? = null
        var bookmark: ImageView? = null
        var jumpto: ImageView? = null
        var makkimadaniicon: ImageView? = null
        var expandImageButton: ImageView? = null
        var ivBismillah: ImageView? = null
        var erabexpand: ImageView? = null

        // public MaterialCardView cardview;
        var cardview: FlowLayout? = null
        var tvSura: TextView? = null
        var tvRukus: TextView? = null
        var tvVerses: TextView? = null
        var ivSurahIcon: ImageView? = null
        var ivLocationmakki: ImageView? = null
        var ivLocationmadani: ImageView? = null
        var ivhelp: ImageView? = null
        var ivoverflow: ImageView? = null
        var arrowforward: ImageView? = null
        var arrowback: ImageView? = null
        var colorize: SwitchCompat? = null

        //  public   com.nex3z.flowlayout.FlowLayout  flow_word_by_word;
        var flow_word_by_word: FlowLayout? = null

        init {
            view.setTag(this)
            itemView.setOnClickListener(this)
            if (viewType == 0) {
                ivLocationmakki = view.findViewById(id.ivLocationmakki)
                ivLocationmadani = view.findViewById(id.ivLocationmadani)
                ivSurahIcon = view.findViewById(id.ivSurahIcon)
                tvVerses = view.findViewById<View>(id.tvVerses) as TextView?
                tvRukus = view.findViewById<View>(id.tvRukus) as TextView?
                tvSura = view.findViewById<View>(id.tvSura) as TextView?
                ivBismillah = view.findViewById(id.ivBismillah)
            } else {
                //  kathir_note =view.findViewById(R.id.kathir_note);
                kathir_translation = view.findViewById(id.katheer_textview)
                arrowforward = view.findViewById(id.arrowforward)
                arrowback = view.findViewById(id.arrowback)
                colorize = view.findViewById(id.colorized)
                bookmark = view.findViewById(id.bookmark)
                jumpto = view.findViewById(id.jumpto)
                ivhelp = view.findViewById(id.ivHelp)
                ivoverflow = view.findViewById(id.ivActionOverflow)
                ivhelp.setOnClickListener(this)
                ivoverflow.setOnClickListener(this)
                jumpto.setOnClickListener(this)
                bookmark.setOnClickListener(this)
                ivhelp.setTag("help_img")
                ivoverflow.setTag("overflow_img")
                bookmark.setTag("bookmark")
                //    colorize.setChecked(true);
                colorize.setOnClickListener(this)
                colorize.setTag("colorize")
                jumpto.setTag("jumpto")
                arrowforward.setOnClickListener(this)
                arrowback.setOnClickListener(this)
                arrowback.setTag("arrowback")
                arrowforward.setTag("arrowforward")
                makkimadaniicon = view.findViewById(id.makkimadaniicon)
                //    jumpto = view.findViewById(R.id.jumpto);
                bismilla = view.findViewById(id.bismillah)
                quran_transliterationnote = view.findViewById(id.quran_transliterationnote)
                quran_jalalaynnote = view.findViewById(id.quran_jalalaynnote)
                translate_textViewnote = view.findViewById(id.translate_textViewnote)
                erab_textViewnote = view.findViewById(id.erab_textViewnote)
                quran_transliteration = view.findViewById(id.quran_transliteration)
                quran_jalalayn = view.findViewById(id.quran_jalalayn)
                surah_info = view.findViewById(id.chaptername)
                //    verse_idTextView = view.findViewById(R.id.verse_id_textView);
                flow_word_by_word = view.findViewById(id.flow_word_by_word)
                translate_textView = view.findViewById(id.translate_textView)
                erab_textView = view.findViewById(id.erab_textView)
                quran_textView = view.findViewById(id.quran_textView)
                //     bookmark = view.findViewById(R.id.bookmarkView);
                erabexpand = view.findViewById(id.erabexpand)
                expandImageButton = view.findViewById(id.expandImageButton)
                quran_textView.setOnClickListener(this)
                quran_textView.setTag("qurantext")
                //    bookmark.setOnClickListener(this);
                //   jumpto.setOnClickListener(this);
                view.setOnClickListener(this)
                view.setOnLongClickListener(this)
                val shared: SharedPreferences =
                    androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                        QuranGrammarApplication.getContext()
                    )
                val colortag: Boolean = shared.getBoolean("colortag", true)
                colorize.setChecked(colortag)
                erabexpand.setOnClickListener(View.OnClickListener({ view1: View? ->
                    val visibility: Int = erab_textView.getVisibility()
                    if (erab_textView.getVisibility() == View.GONE) {
                        erab_textView.setVisibility(View.VISIBLE)
                        //  AnimationUtility.slide_down(context, erabexpand);
                        AnimationUtility.AnimateArrow(90.0f, erabexpand)
                    } else {
                        erab_textView.setVisibility(View.GONE)
                        AnimationUtility.AnimateArrow(0.0f, erabexpand)
                        //   Fader.slide_down(context,expandImageButton);
                    }
                }))
                expandImageButton.setOnClickListener(View.OnClickListener({ view1: View? ->
                    val visibility: Int = kathir_translation.getVisibility()
                    if (kathir_translation.getVisibility() == View.GONE) {
                        kathir_translation.setVisibility(View.VISIBLE)
                        AnimationUtility.AnimateArrow(90.0f, expandImageButton)
                    } else {
                        kathir_translation.setVisibility(View.GONE)
                        AnimationUtility.AnimateArrow(-0.0f, expandImageButton)
                        //    Fader.slide_down(context,expandImageButton);
                    }
                }))
                flow_word_by_word.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (translate_textView.getVisibility() == View.GONE) translate_textView.setVisibility(
                        View.VISIBLE
                    ) else translate_textView.setVisibility(View.VISIBLE)
                }))
                translate_textView.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (translate_textView.getVisibility() == View.VISIBLE) translate_textView.setVisibility(
                        View.GONE
                    ) else translate_textView.setVisibility(View.VISIBLE)
                }))
                erab_textView.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (erab_textView.getVisibility() == View.VISIBLE) erab_textView.setVisibility(
                        View.GONE
                    ) else erab_textView.setVisibility(View.VISIBLE)
                }))
            }
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }

        public override fun onLongClick(v: View): Boolean {
            mItemClickListener!!.onItemLongClick(getAdapterPosition(), v)
            return true
        }
    } //View.OnClickListener, View.OnLongClickListener

    companion object {
        private val TYPE_HEADER: Int = 0
        private val TYPE_ITEM: Int = 1
        var ItemViewAdapter: Any? = null
        var showTranslation: Boolean = false
        var wordByWord: Boolean = false
        var fontSizeArabic: Int = 0
        var fontSizeTranslation: Int = 0
        var corpusTypeface: Typeface? = null
    }
}