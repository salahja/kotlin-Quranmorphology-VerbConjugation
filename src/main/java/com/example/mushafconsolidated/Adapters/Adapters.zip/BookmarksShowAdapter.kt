package com.example.mushafconsolidated.Adaptersimport

import android.content.Context
import androidx.recyclerview.widget.RecyclerView
import com.example.utility.PreferenceUtil


/**
 * RecyclerView.Adapter<BookmarksShowAdapter.ViewHolder>
 * Adapter class for the bookmarks list view
</BookmarksShowAdapter.ViewHolder> */
class BookmarksShowAdapter : RecyclerView.Adapter<BookmarksShowAdapter.ViewHolder> {
    var mItemClickListener: OnItemClickListener? = null
    var BookmarksShowAdapterContext: Context? = null
    var bookmarkpostion: Int = 0
    var pref: PreferenceUtil? = null
    var holderposition: Int = 0
    var bookmarid: Int = 0
    val bookChapterno: Int = 0
    var bookMarkArrayList: List<BookMarks>? = null

    constructor() {}
    constructor(context: Context?) {
        BookmarksShowAdapterContext = context
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): BookmarksShowAdapter.ViewHolder {
        val view: View =
            LayoutInflater.from(parent.getContext()).inflate(R.layout.row_bookmar_two, parent, false)
        //   sendVerseClick=(SendVerseClick) getActivity();
        return BookmarksShowAdapter.ViewHolder(view, viewType)
    }

    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun onBindViewHolder(holder: BookmarksShowAdapter.ViewHolder, position: Int) {
        val d: Int = Log.d(BookmarksShowAdapter.Companion.TAG, "onBindViewHolder: called")
        val bookMark: BookMarks = bookMarkArrayList!!.get(position)
        holderposition = position
        bookmarid = bookMark.getId()
        val imgs: TypedArray =
            QuranGrammarApplication.getContext().getResources().obtainTypedArray(R.array.sura_imgs)
        val shared: SharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
        val isNightmode: String? = shared.getString("theme", "dark")
        val chapterno: String = bookMark.getChapterno()
        if (!chapterno.isEmpty()) {
            val drawable: Drawable? = imgs.getDrawable((chapterno.toInt() - 1))
            holder.surahicon.setImageDrawable(drawable)
        }
        if ((isNightmode == "dark") || (isNightmode == "blue")) {
            holder.surahicon.setColorFilter(Color.CYAN)
        }
        holder.header.setText(bookMark.getHeader())
        holder.datestamp.setText(bookMark.getDatetime())
        holder.suraName.setText(bookMark.getSurahname())
        holder.chapterno.setText(bookMark.getChapterno())
        holder.verseno.setText(bookMark.getVerseno() + "")
        val arabicFontSize: Int = shared.getInt("pref_font_arabic_key", 18)
        holder.datestamp.setTextSize(arabicFontSize.toFloat())
        holder.suraName.setTextSize(arabicFontSize.toFloat())
        holder.verseno.setTextSize(arabicFontSize.toFloat())
        holder.chapterno.setTextSize(arabicFontSize.toFloat())
        /*     if (isNightmode.equals("dark")) {
            ContextCompat.getColor(QuranGrammarApplication.getContext(), R.color.color_background_overlay);
            holder.cardView.setCardBackgroundColor(ContextCompat.getColor(QuranGrammarApplication.getContext(), R.color.color_background_overlay));

        } else if (isNightmode.equals("blue")) {
            holder.cardView.setCardBackgroundColor(ContextCompat.getColor(QuranGrammarApplication.getContext(), R.color.solarizedBase02));

        }
*/
    }

    public override fun getItemCount(): Int {
        return bookMarkArrayList!!.size
    }

    fun removeItem(position: Int) {
        bookMarkArrayList.removeAt(position)
        notifyItemRemoved(position)
    }

    fun getItem(position: Int): Any {
        return bookMarkArrayList!!.get(position)
    }

    // public void restoreItem(ArrayList<BookMarks> item, int position) {
    //      data.add(position, item);
    //     notifyItemInserted(position);
    //  }
    inner class ViewHolder constructor(view: View, viewType: Int) : RecyclerView.ViewHolder(view),
        View.OnClickListener // current clickListerner
    {
        val datestamp: TextView
        val suraName: TextView
        val verseno: TextView
        val surahicon: ImageView
        val cardView: CardView
        var chapterno: TextView
        val header: TextView

        init {
            view.setTag(this)
            itemView.setOnClickListener(this)
            header = view.findViewById(id.header)
            surahicon = view.findViewById(id.surahicon)
            cardView = view.findViewById(id.cardview)
            datestamp = view.findViewById(id.date)
            chapterno = view.findViewById(id.chapterno)
            suraName = view.findViewById<View>(id.surahname) as TextView
            verseno = view.findViewById(id.verseno)
            chapterno = view.findViewById(id.chapterno)
            surahicon.setTag("iocn")
            surahicon.setOnClickListener(this)
            chapterno.setTag("chapter")
            chapterno.setOnClickListener(this)
            suraName.setTag("surah")
            suraName.setOnClickListener(this)
            verseno.setTag("verse")
            verseno.setOnClickListener(this)
            view.setOnClickListener(this) // current clickListerner
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }
    }

    companion object {
        private val TAG: String = "BookmarksShowAdapter"
    }
}