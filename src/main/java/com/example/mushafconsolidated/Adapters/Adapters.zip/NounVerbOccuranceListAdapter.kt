package com.example.mushafconsolidated.Adaptersimport

android.content.SharedPreferencesimport android.graphics.Colorimport android.graphics.Typefaceimport android.preference.PreferenceManager import android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroup import android.widget.TextViewimport androidx.core.content.ContextCompatimport androidx.core.text.HtmlCompatimport com.example.mushafconsolidated.R.colorimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.utility.QuranGrammarApplication
 
 
 
 
 
 
 
 
 
  
 
 
 
 
 
 

class NounVerbOccuranceListAdapter constructor(// private   HashMap<String, List<SpannableString >> expandableListDetail;
    private val context: Context, private val expandableListTitle: List<String>,
    expandNounVerses: LinkedHashMap<String, List<SpannableString>>,
    expandVerbVerses: LinkedHashMap<String, List<SpannableString>>, expandVerbTitles: List<String>
) : BaseExpandableListAdapter() {
    private val expandVerbTitles: List<String>
    private val expandVerbVerses: LinkedHashMap<String, List<SpannableString>>
    var expandNounVerses: LinkedHashMap<String, List<SpannableString>> = LinkedHashMap()

    init {
        this.expandNounVerses = expandNounVerses
        this.expandVerbTitles = expandVerbTitles
        this.expandVerbVerses = expandVerbVerses
    }

    public override fun getChild(listPosition: Int, expandedListPosition: Int): Any {
        return expandNounVerses.get(expandableListTitle.get(listPosition))
            .get(expandedListPosition)
    }

    public override fun getChildId(listPosition: Int, expandedListPosition: Int): Long {
        return expandedListPosition.toLong()
    }

    public override fun getChildView(
        listPosition: Int, expandedListPosition: Int,
        isLastChild: Boolean, convertView: View, parent: ViewGroup
    ): View {
        //  SpannableString expandedListText = (SpannableString) getChild(listPosition, expandedListPosition);
        var convertView: View = convertView
        val child: Any = getChild(listPosition, expandedListPosition)
        if (convertView == null) {
            val layoutInflater: LayoutInflater = context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = layoutInflater.inflate(R.layout.list_grammar_item, null)
        }
        val mequran: Typeface =
            Typeface.createFromAsset(QuranGrammarApplication.getContext().getAssets(), "Taha.ttf")
        //  Typeface mequran = Typeface.createFromAsset(DarkThemeApplication.getContext().getAssets(), quranfont);
        val expandedListTextView: TextView = convertView
            .findViewById<View>(id.expandedListItem) as TextView
        val expandedListTextViewlane: TextView = convertView
            .findViewById<View>(id.expandedListItemverb) as TextView
        val contains: Boolean = false
        if (contains) {
            //setTextDirection(View.TEXT_DIRECTION_ANY_RTL)
            expandedListTextView.setTextDirection(View.TEXT_DIRECTION_LTR)
            //  CharSequence start = " Arabic to English" + child;
            //   expandedListTextView.setText((CharSequence) child);
            expandedListTextView.setText(HtmlCompat.fromHtml(child.toString(), 0))
        } else {
            expandedListTextView.setText(HtmlCompat.fromHtml(child.toString(), 0))
            //  expandedListTextView.setText((CharSequence) child);
        }
        expandedListTextView.setText(HtmlCompat.fromHtml(child.toString(), 0))
        expandedListTextView.setTypeface(mequran)
        return convertView
    }

    public override fun getChildrenCount(listPosition: Int): Int {
        return expandNounVerses.get(expandableListTitle.get(listPosition))
            .size
    }

    public override fun getGroup(listPosition: Int): Any {
        return expandableListTitle.get(listPosition)
    }

    public override fun getGroupCount(): Int {
        return expandableListTitle.size
    }

    public override fun getGroupId(listPosition: Int): Long {
        return listPosition.toLong()
    }

    public override fun getGroupView(
        listPosition: Int, isExpanded: Boolean,
        convertView: View, parent: ViewGroup
    ): View {
        var convertView: View = convertView
        val listTitle: String = getGroup(listPosition) as String
        if (convertView == null) {
            val layoutInflater: LayoutInflater =
                context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
            convertView = layoutInflater.inflate(R.layout.list_group, null)
        }
        val listTitleTextView: TextView = convertView
            .findViewById<View>(id.listTitle) as TextView
        listTitleTextView.setTypeface(null, Typeface.BOLD)
        val prefs: SharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
        val preferences: String? = prefs.getString("theme", "dark")
        if ((preferences == "dark") || (preferences == "blue") || (preferences == "green")) {
            listTitleTextView.setTextColor(Color.CYAN)
        } else {
            listTitleTextView.setTextColor(
                ContextCompat.getColor(
                    QuranGrammarApplication.getContext(),
                    color.burntamber
                )
            )
        }
        listTitleTextView.setTextSize(18f)
        listTitleTextView.setText(listTitle)
        return convertView
    }

    public override fun hasStableIds(): Boolean {
        return false
    }

    public override fun isChildSelectable(listPosition: Int, expandedListPosition: Int): Boolean {
        return true
    }
}