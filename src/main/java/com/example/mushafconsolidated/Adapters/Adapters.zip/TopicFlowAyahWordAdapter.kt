package com.example.mushafconsolidated.Adaptersimport

android.content.ActivityNotFoundExceptionimport android.content.Contextimport android.content.Intentimport android.content.SharedPreferencesimport android.content.pm.PackageManagerimport android.content.pm.ResolveInfoimport android.content.res.ColorStateListimport android.content.res.TypedArrayimport android.graphics.Bitmapimport android.graphics.Canvasimport android.graphics.Colorimport android.graphics.Paintimport android.graphics.Typefaceimport android.graphics.drawable.Drawableimport android.net.Uriimport android.os.Bundleimport android.os.Environmentimport android.text.Html import android.text.format.DateFormatimport android.view.Gravityimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.widget.ImageViewimport android.widget.TextViewimport android.widget.Toastimport androidx.appcompat.app.AppCompatActivityimport androidx.appcompat.widget.SwitchCompatimport androidx.cardview.widget.CardViewimport androidx.constraintlayout.widget.Groupimport androidx.core.content.ContextCompatimport androidx.core.content.FileProviderimport androidx.preference.PreferenceManagerimport androidx.recyclerview.widget.RecyclerViewimport androidx.transition.AutoTransitionimport androidx.transition.TransitionManagerimport com.example.Constantimport com.example.mushafconsolidated.Activity.TafsirFullscreenActivityimport com.example.mushafconsolidated.Adapters.TopicFlowAyahWordAdapterimport com.example.mushafconsolidated.Configimport com.example.mushafconsolidated.Entities.BookMarksimport com.example.mushafconsolidated.Entities.NounCorpusimport com.example.mushafconsolidated.Entities.VerbCorpusimport com.example.mushafconsolidated.NamesDetailimport com.example.mushafconsolidated.ParticleColorSchemeimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.colorimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.R.stringimport com.example.mushafconsolidated.R.styleimport com.example.mushafconsolidated.SurahSummaryimport com.example.mushafconsolidated.Utilsimport com.example.mushafconsolidated.fragments.SentenceAnalysisBottomSheetimport com.example.mushafconsolidated.fragments.WordAnalysisBottomSheetimport com.example.mushafconsolidated.fragments.WordMorphologyDetailsimport com.example.mushafconsolidated.intrface.OnItemClickListenerimport com.example.mushafconsolidated.intrface.OnItemClickListenerOnLongimport com.example.mushafconsolidated.model.CorpusAyahWordimport com.example.mushafconsolidated.model.CorpusWbwWordimport com.example.utility.AnimationUtilityimport com.example.utility.CorpusUtilityorigimport com.example.utility.FlowLayoutimport com.example.utility.QuranGrammarApplicationimport com.google.android.material.card.MaterialCardViewimport com.google.android.material.floatingactionbutton.FloatingActionButtonimport com.google.android.material.snackbar.Snackbarimport com.tooltip.Tooltipimport java.io.Fileimport java.io.FileOutputStreamimport java.io.IOExceptionimport java.util.Date
 
 
 
 
 
 
 
 
 
  
 
 
 
 
 
 

//import com.example.mushafconsolidated.Entities.JoinVersesTranslationDataTranslation;
//public class CustomAdapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> implements OnItemClickListenerOnLong {
class TopicFlowAyahWordAdapter : RecyclerView.Adapter<TopicFlowAyahWordAdapter.ItemViewAdapter> {
    val arabicfontSize: Int
    val translationfontsize: Int
    val mItemClickListener: OnItemClickListenerOnLong?
    private val issentence: Boolean
    private val ayahWordArrayList: ArrayList<CorpusAyahWord>
    var context: Context? = null
    var arabic: TextView? = null
    var rootword: TextView? = null
    private val listener: OnItemClickListener? = null
    private var isNightmode: String? = null
    private var SurahName: String? = null
    private val isMakkiMadani: Int = 0
    var ayahWord: CorpusAyahWord? = null
    var quranverses: SpannableString? = null

    constructor(
        corpusayahWordArrayList: ArrayList<CorpusAyahWord>,
        listener: OnItemClickListenerOnLong?
    ) {
        ayahWordArrayList = corpusayahWordArrayList
        mItemClickListener = listener
        //  mItemClickListener = listener;
        val sharedPreferences: SharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
        sharedPreferences.getBoolean(Config.Companion.SHOW_Erab, Config.Companion.defaultShowErab)
        issentence = sharedPreferences.getBoolean("grammarsentence", false)
        arabicfontSize = sharedPreferences.getInt("pref_font_arabic_key", 18)
        translationfontsize = sharedPreferences.getInt("pref_font_englsh_key", 18)
    }

    constructor(
        corpusayahWordArrayList: ArrayList<CorpusAyahWord>,
        listener: OnItemClickListenerOnLong?,
        surahname: String?
    ) {
        ayahWordArrayList = corpusayahWordArrayList
        mItemClickListener = listener
        //  mItemClickListener = listener;
        val sharedPreferences: SharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
        sharedPreferences.getBoolean(Config.Companion.SHOW_Erab, Config.Companion.defaultShowErab)
        issentence = sharedPreferences.getBoolean("grammarsentence", false)
        arabicfontSize = sharedPreferences.getInt("pref_font_arabic_key", 18)
        translationfontsize = sharedPreferences.getInt("pref_font_englsh_key", 18)
        SurahName = surahname
    }

    fun addContext(context: Context?) {
        this.context = context
    }

    public override fun getItemViewType(position: Int): Int {
        if (position == 0) {
            return TopicFlowAyahWordAdapter.Companion.TYPE_HEADER
        } else {
            return TopicFlowAyahWordAdapter.Companion.TYPE_ITEM
        }
    }

    public override fun getItemCount(): Int {
        return ayahWordArrayList.size
        //     return  quran.size();
    }

    public override fun getItemId(position: Int): Long {
        val ayahWord: CorpusAyahWord = ayahWordArrayList.get(position)
        var itemId: Long = 0
        for (word: CorpusWbwWord in ayahWord.getWord()) {
            itemId = word.getVerseId().toLong()
        }
        return itemId
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TopicFlowAyahWordAdapter.ItemViewAdapter {
        val view: View
        view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.topic_row_ayah_word, parent, false)
        //   view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_viewer_aya_cardview, parent, false);
        return TopicFlowAyahWordAdapter.ItemViewAdapter(view, viewType)
    }

    fun getItem(position: Int): Any {
        return ayahWordArrayList.get(0).getWord().get(position)
        //    return allofQuran.get(position);
    }

    public override fun onBindViewHolder(
        holder: TopicFlowAyahWordAdapter.ItemViewAdapter,
        position: Int
    ) {
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            (context)!!
        )
        isNightmode = sharedPreferences.getString("themepref", "dark")
        //grammatically colred word default font
        val arabic_font_selection: String? =
            sharedPreferences.getString("Arabic_Font_Selection", "quranicfontregular.ttf")
        val custom_font: Typeface = Typeface.createFromAsset(
            context!!.getAssets(),
            arabic_font_selection
        )
        val showrootkey: Boolean = sharedPreferences.getBoolean("showrootkey", true)
        val showErab: Boolean = sharedPreferences.getBoolean("showErabKey", true)
        val showWordColor: Boolean = sharedPreferences.getBoolean("colortag", true)
        val showTransliteration: Boolean =
            sharedPreferences.getBoolean("showtransliterationKey", true)
        val showJalalayn: Boolean = sharedPreferences.getBoolean("showEnglishJalalayn", true)
        val showTranslation: Boolean = sharedPreferences.getBoolean("showTranslationKey", true)
        val showWordByword: Boolean = sharedPreferences.getBoolean("wordByWord", false)
        val showKathir: Boolean = sharedPreferences.getBoolean("showKathir", false)
        val whichtranslation: String? = sharedPreferences.getString("selecttranslation", "en_sahih")
        displayAyats(
            showrootkey,
            holder,
            position,
            sharedPreferences,
            custom_font,
            showErab,
            showWordColor,
            showTransliteration,
            showJalalayn,
            showTranslation,
            showWordByword,
            whichtranslation,
            showKathir
        )
    }

    private fun displayAyats(
        showrootkey: Boolean,
        holder: TopicFlowAyahWordAdapter.ItemViewAdapter,
        position: Int,
        sharedPreferences: SharedPreferences,
        custom_font: Typeface,
        showErab: Boolean,
        showWordColor: Boolean,
        showTransliteration: Boolean,
        showJalalayn: Boolean,
        showTranslation: Boolean,
        showWordByword: Boolean,
        whichtranslation: String?,
        showKathir: Boolean
    ) {
        //   holder.flowwbw.setBackgroundColor(R.style.Theme_DarkBlue);
        val wbw: String? = sharedPreferences.getString("wbw", "en")
        try {
            ayahWord = ayahWordArrayList.get(position)
        } catch (e: IndexOutOfBoundsException) {
        }
        try {
            quranverses = ayahWordArrayList.get(position).getSpannableverse()
        } catch (e: IndexOutOfBoundsException) {
        }
        assert(ayahWord != null)
        holder.header.setText(ayahWord!!.getTopictitle())
        holder.quran_textView.setText(quranverses)
        holder.quran_textView.setTextSize(16f)
        holder.quran_textView.setTypeface(custom_font)
        holder.base_cardview.setVisibility(View.GONE)
        holder.mafoolbihi.setVisibility(View.GONE)
        holder.base_cardview.setVisibility(View.GONE)
        setChapterInfo(holder, ayahWord)
        //  setAdapterposition(position);
        wordBywordWithTranslation(
            showrootkey,
            holder,
            custom_font,
            showWordColor,
            wbw,
            ayahWord,
            showWordByword
        )
        if (showTransliteration) {
            holder.quran_transliteration.setText(
                Html.fromHtml(
                    ayahWord!!.getEn_transliteration(),
                    Html.FROM_HTML_MODE_LEGACY
                )
            )
            holder.quran_transliteration.setTextSize(translationfontsize.toFloat())
            holder.quran_transliteration.setTextSize(translationfontsize.toFloat())
            holder.quran_transliteration.setVisibility(View.VISIBLE)
        }
        if (showTranslation) {
            if ((whichtranslation == "en_arberry")) {
                holder.translate_textView.setText(ayahWord!!.getEn_arberry())
                holder.translate_textViewnote.setText(string.arberry)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_sahih")) {
                holder.translate_textView.setText(ayahWord!!.getQuranTranslate())
                holder.translate_textViewnote.setText(string.ensahih)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_jalalayn")) {
                holder.translate_textView.setText(ayahWord!!.getEn_jalalayn())
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_jalalayn")) {
                holder.translate_textView.setText(ayahWord!!.getUr_jalalayn())
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_junagarhi")) {
                holder.translate_textView.setText(ayahWord!!.getUr_junagarhi())
                holder.translate_textViewnote.setText(string.urjunagadi)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setVisibility(View.VISIBLE)
            holder.translate_textViewnote.setVisibility(View.VISIBLE)
        }
        if (showErab) {
            holder.erabexpand.setVisibility(View.VISIBLE)
            holder.erab_textView.setText(ayahWord!!.getAr_irab_two())
            holder.erab_textView.setTextSize(translationfontsize.toFloat())
            holder.erab_textView.setTypeface(custom_font)
            //     holder.erab_textView.setVisibility(View.VISIBLE);
            holder.erab_textViewnote.setVisibility(View.VISIBLE)
        } else {
            holder.erabexpand.setVisibility(View.GONE)
        }
    }

    private fun wordBywordWithTranslation(
        showrootkey: Boolean,
        holder: TopicFlowAyahWordAdapter.ItemViewAdapter,
        custom_font: Typeface,
        showWordColor: Boolean,
        wbw: String?,
        ayahWord: CorpusAyahWord?,
        showWbwTranslation: Boolean
    ) {
        val FONTS_LOCATION_PATH: String = "fonts/DejaVuSans.ttf"
        val colorwordfont: Typeface = Typeface.createFromAsset(
            QuranGrammarApplication.getContext().getAssets(),
            FONTS_LOCATION_PATH
        )
        val inflater: LayoutInflater =
            context!!.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        holder.flow_word_by_word.removeAllViews()
        for (word: CorpusWbwWord in ayahWord!!.getWord()) {
            val view: View = inflater.inflate(R.layout.word_by_word, null)
            arabic = view.findViewById(id.word_arabic_textView)
            rootword = view.findViewById(id.root_word)
            //   wordno = view.findViewById(R.id.wordno);
            val translation: TextView = view.findViewById(id.word_trans_textView)
            var spannedroot: SpannableString? = null
            val sb: String  = String ()
            sb.append(word.getWordno())
            if (showrootkey) {
                if (!word.getRootword().isEmpty()) {
                    spannedroot = getSpannedRoots(word)
                } else {
                    spannedroot = SpannableString.valueOf(word.getRootword())
                }
                rootword.setText(spannedroot)
                rootword.setTextSize(arabicfontSize.toFloat())
                rootword.setVisibility(View.VISIBLE)
            }
            if (showWordColor) {
                var spannedword: SpannableString?
                // word.getRootword();
                spannedword = getSpannedWords(word)
                arabic.setText(spannedword)
            } else {
                arabic.setText(word.getWordsAr())
            }
            rootword.setText(spannedroot)
            rootword.setTextSize(arabicfontSize.toFloat())
            //  arabic.setTextSize(18);
            arabic.setTextSize(arabicfontSize.toFloat())
            arabic.setTypeface(colorwordfont)
            if (showWbwTranslation) {
                when (wbw) {
                    "en" -> {
                        translation.setText(word.getTranslateEn())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }

                    "bn" -> {
                        translation.setText(word.getTranslateBn())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }

                    "in" -> {
                        translation.setText(word.getTranslateIndo())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }

                    "ur" -> {
                        translation.setText(word.getTranslationUrdu())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }
                }
                //  translation.setTextColor(context.getResources().getColor(R.color.neutral2));
            }
            //    translation.setTextSize(forntSize + 4);
            translation.setTextSize(translationfontsize.toFloat())
            holder.flow_word_by_word.addView(view)
            view.setLongClickable(true)
            view.setOnLongClickListener(View.OnLongClickListener({ v: View? ->
                val utils: Utils = Utils(QuranGrammarApplication.getContext())
                val verbCorpusRootWords: ArrayList<VerbCorpus> =
                    utils.getQuranRoot(word.getSurahId(), word.getVerseId(), word.getWordno())
                if (verbCorpusRootWords.size > 0 && (verbCorpusRootWords.get(0).getTag() == "V")) {
                    //    vbdetail = ams.getVerbDetails();
                    print("check")
                }
                val corpusNounWord: ArrayList<NounCorpus> =
                    utils.getQuranNouns(word.getSurahId(), word.getVerseId(), word.getWordno())
                val verbCorpusRootWord: ArrayList<VerbCorpus> =
                    utils.getQuranRoot(word.getSurahId(), word.getVerseId(), word.getWordno())
                val qm: WordMorphologyDetails =
                    WordMorphologyDetails(word, corpusNounWord, verbCorpusRootWord)
                val workBreakDown: SpannableString = qm.getWorkBreakDown()
                var color: Int =
                    context!!.getResources().getColor(color.background_color_light_brown)
                when (isNightmode) {
                    "dark", "blue", "green" -> color =
                        ContextCompat.getColor((context)!!, R.color.background_color)

                    "brown", "light" -> color =
                        ContextCompat.getColor((context)!!, R.color.neutral0)

                    "white" -> color =
                        ContextCompat.getColor((context)!!, R.color.background_color_light_brown)
                }
                val  : Tooltip.  = Tooltip. ((v)!!, style.ayah_translation)
                    .setCancelable(true)
                    .setDismissOnClick(false)
                    .setCornerRadius(20f)
                    .setGravity(Gravity.TOP)
                    .setArrowEnabled(true)
                    .setBackgroundColor(color)
                    .setText(workBreakDown)
                 .show()
                true
            }))
            view.setOnClickListener(object : View.OnClickListener {
                public override fun onClick(view: View?) {
                    val dialog: Dialog = Dialog((context)!!)
                    dialog.setTitle(word.getWordsAr())
                    val dataBundle: Bundle = Bundle()
                    dataBundle.putInt(Constant.SURAH_ID, word.getSurahId())
                    dataBundle.putInt(
                        Constant.AYAHNUMBER,
                        Math.toIntExact(word.getVerseId().toLong())
                    )
                    dataBundle.putInt(
                        Constant.WORDNUMBER,
                        Math.toIntExact(word.getWordno().toLong())
                    )
                    dataBundle.putString(Constant.SURAH_ARABIC_NAME, SurahName)
                    LoadItemList(dataBundle)
                }

                private fun LoadItemList(dataBundle: Bundle) {
                    if (issentence) {
                        val item: SentenceAnalysisBottomSheet = SentenceAnalysisBottomSheet()
                        item.setArguments(dataBundle)
                        val data: Array<String> = arrayOf(
                            word.getSurahId().toString(),
                            word.getVerseId().toString(),
                            word.getTranslateEn(),
                            (word.getWordno()).toString()
                        )
                        SentenceAnalysisBottomSheet.Companion.newInstance(data).show(
                            (context as AppCompatActivity?)!!.getSupportFragmentManager(),
                            SentenceAnalysisBottomSheet.Companion.TAG
                        )
                    } else {
                        val item: WordAnalysisBottomSheet = WordAnalysisBottomSheet()
                        item.setArguments(dataBundle)
                        val data: Array<String?> = arrayOf(
                            word.getSurahId().toString(),
                            word.getVerseId().toString(),
                            word.getTranslateEn(),
                            (word.getWordno()).toString(),
                            SurahName
                        )
                        WordAnalysisBottomSheet.Companion.newInstance(data).show(
                            (context as AppCompatActivity?)!!.getSupportFragmentManager(),
                            WordAnalysisBottomSheet.Companion.TAG
                        )
                    }
                }
            })
        }
        holder.flow_word_by_word.setVisibility(View.VISIBLE)
    }

    private fun getSpannedRoots(corpus: CorpusWbwWord): SpannableString {
        val b: Boolean =
            corpus.getVerseId() == 20 && (corpus.getWordno() == 2 || corpus.getWordno() == 9)
        if (b) {
            println("check")
        }
        return CorpusUtilityorig.ColorizeRootword(
            corpus.getTagone(),
            corpus.getTagtwo(),
            corpus.getTagthree(),
            corpus.getTagfour(),
            corpus.getTagfive(),
            corpus.getRootword()
        )
    }

    private fun getSpannedWords(corpus: CorpusWbwWord): SpannableString {
        val b: Boolean =
            corpus.getVerseId() == 20 && (corpus.getWordno() == 2 || corpus.getWordno() == 9)
        if (b) {
            println("check")
        }
        return CorpusUtilityorig.NewSetWordSpan(
            corpus.getTagone(),
            corpus.getTagtwo(),
            corpus.getTagthree(),
            corpus.getTagfour(),
            corpus.getTagfive(),
            corpus.getAraone(),
            corpus.getAratwo(),
            corpus.getArathree(),
            corpus.getArafour(),
            corpus.getArafive()
        )
    }

    private fun setChapterInfo(
        holder: TopicFlowAyahWordAdapter.ItemViewAdapter,
        verse: CorpusAyahWord?
    ) {
        val surahInfo: String  = String ()
        //        surahInfo.append(surahName+".");
        surahInfo.append(verse!!.getWord().get(0).getSurahId()).append(".")
        surahInfo.append(verse.getWord().get(0).getVerseId()).append("-")
        //  surahInfo.append(SurahName);
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            (context)!!
        )
        val isNightmode: String? = sharedPreferences.getString("themepref", "dark")
        val imgs: TypedArray =
            QuranGrammarApplication.getContext().getResources().obtainTypedArray(R.array.sura_imgs)
        val drawable: Drawable? =
            imgs.getDrawable((verse.getWord().get(0).getSurahId().toString().toInt() - 1))
        imgs.recycle()
        holder.surahicon.setImageDrawable(drawable)
        if ((isNightmode == "dark") || (isNightmode == "blue")) {
            holder.surahicon.setColorFilter(Color.CYAN)
        }
        if (isMakkiMadani == 1) {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                R.drawable.ic_makkah_48,
                0,
                0,
                0
            )
        } else {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                R.drawable.ic_madinah_48,
                0,
                0,
                0
            )
        }
        if ((isNightmode == "dark") || (isNightmode == "blue") || (isNightmode == "green")) {
//TextViewCompat.setCompoundDrawableTintList()
            holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.CYAN))
        } else {
            holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.BLUE))
            //   holder.surah_info.setBackgroundColor(getContext().getResources().getColor(R.color.burntamber));
            //   imageViewIcon.setColorFilter(getContext().getResources().getColor(R.color.blue));
        }
        holder.surah_info.setText(surahInfo)
        holder.surah_info.setTextSize(arabicfontSize.toFloat())
        //  holder.surah_info.setTextColor(context.getResources().getColor(R.color.colorOnPrimary));
    }

    inner class ItemViewAdapter internal constructor(view: View, viewType: Int) :
        RecyclerView.ViewHolder(view), View.OnClickListener, View.OnLongClickListener {
        val quran_jalalayn: TextView
        val kathir_translation: TextView
        val quran_transliteration: TextView
        val translate_textView: TextView
        val erab_textView: TextView
        val surah_info: TextView
        val mafoolbihi: TextView
        val bismilla: TextView
        val quran_textView: TextView
        val erab_notes: TextView
        val quran_transliterationnote: TextView
        val quran_jalalaynnote: TextView
        val erab_textViewnote: TextView
        val header: TextView
        val translate_textViewnote: TextView
        val makkimadaniicon: ImageView
        val expandImageButton: ImageView
        val erabexpand: ImageView
        val erab_notes_expand: ImageView
        val colorize: SwitchCompat
        val flow_word_by_word: FlowLayout

        //   RelativeLayout colllayout;
        val erabnotescardView: CardView
        val mafoolatarow: ImageView
        val surahicon: ImageView
        val ivoverflow: ImageView
        val hiddenGroup: Group
        val base_cardview: MaterialCardView
        var tafsir: FloatingActionButton
        var jumptofb: FloatingActionButton
        var bookmarfb: FloatingActionButton
        var fabmenu: FloatingActionButton
        var helpfb: FloatingActionButton
        var summbaryfb: FloatingActionButton
        var sharescreenfb: FloatingActionButton
        var bookmark: ImageView? = null
        var ivBismillah: ImageView? = null

        init {
            view.setTag(this)
            header = view.findViewById(id.headers)
            itemView.setOnClickListener(this)
            surahicon = view.findViewById(id.surahicon)
            kathir_translation = view.findViewById(id.katheer_textview)
            colorize = view.findViewById(id.colorized)
            ivoverflow = view.findViewById(id.ivActionOverflow)
            ivoverflow.setOnClickListener(this)
            ivoverflow.setTag("overflow_img")
            //  ivhelp.setOnClickListener(this);
            makkimadaniicon = view.findViewById(id.makkimadaniicon)
            bismilla = view.findViewById(id.bismillah)
            quran_transliterationnote = view.findViewById(id.quran_transliterationnote)
            quran_jalalaynnote = view.findViewById(id.quran_jalalaynnote)
            translate_textViewnote = view.findViewById(id.translate_textViewnote)
            erab_textViewnote = view.findViewById(id.erab_textViewnote)
            quran_transliteration = view.findViewById(id.quran_transliteration)
            quran_jalalayn = view.findViewById(id.quran_jalalayn)
            surah_info = view.findViewById(id.chaptername)
            //    verse_idTextView = view.findViewById(R.id.verse_id_textView);
            flow_word_by_word = view.findViewById(id.flow_word_by_word)
            translate_textView = view.findViewById(id.translate_textView)
            erab_textView = view.findViewById(id.erab_textView)
            //     erab_textView.setTextIsSelectable(true);
            quran_textView = view.findViewById(id.quran_textView)
            erab_notes = view.findViewById(id.erab_notes)
            erabexpand = view.findViewById(id.erabexpand)
            erab_notes_expand = view.findViewById(id.erab_img)
            expandImageButton = view.findViewById(id.expandImageButton)
            quran_textView.setOnClickListener(this)
            quran_textView.setTag("qurantext")
            erab_notes_expand.setOnClickListener(this)
            erab_notes_expand.setTag("erab_notes")
            erabnotescardView = view.findViewById(id.base_cardview)
            mafoolatarow = view.findViewById(id.show)
            hiddenGroup = view.findViewById(id.card_group)
            mafoolatarow.setOnClickListener(this)
            mafoolbihi = view.findViewById(id.directobject)
            base_cardview = view.findViewById(id.base_cardview)
            fabmenu = view.findViewById(id.expandfabs)
            tafsir = view.findViewById(id.tafsirfb)
            jumptofb = view.findViewById(id.jumptofb)
            bookmarfb = view.findViewById(id.bookmarfb)
            summbaryfb = view.findViewById(id.summbaryfb)
            helpfb = view.findViewById(id.helpfb)
            sharescreenfb = view.findViewById(id.sharescreenfb)
            sharescreenfb.setOnClickListener(this)
            fabmenu.setOnClickListener(this)
            tafsir.setOnClickListener(this)
            jumptofb.setOnClickListener(this)
            bookmarfb.setOnClickListener(this)
            summbaryfb.setOnClickListener(this)
            helpfb.setOnClickListener(this)
            view.setOnClickListener(this)
            view.setOnLongClickListener(this)
            val shared: SharedPreferences =
                PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
            val colortag: Boolean = shared.getBoolean("colortag", true)
            fabmenu.setOnClickListener(object : View.OnClickListener {
                private var isFABOpen: Boolean = false
                public override fun onClick(view: View?) {
                    if (!isFABOpen) {
                        showFABMenu()
                    } else {
                        closeFABMenu()
                        //     HideFabMenu();
                    }
                }

                private fun showFABMenu() {
                    isFABOpen = true
                    fabmenu.animate().rotationBy(180f)
                    tafsir.setVisibility(View.VISIBLE)
                    tafsir.animate().translationX(
                        -QuranGrammarApplication.getInstance().getResources()
                            .getDimension(R.dimen.standard_55)
                    )
                    tafsir.animate().rotationBy(360f)
                    tafsir.animate().setDuration(1500)
                    // ObjectAnimator animation = ObjectAnimator.ofFloat(tafsir, "translationX", 90f);
                    // animation.setDuration(1000);
                    //  animation.start();
                    //  jumptofb.setVisibility(View.VISIBLE);
                    //   jumptofb.animate().translationX(-getInstance().getResources().getDimension(R.dimen.standard_105));
                    //   jumptofb.animate().rotationBy(360);
                    bookmarfb.setVisibility(View.VISIBLE)
                    bookmarfb.animate().translationX(
                        -QuranGrammarApplication.getInstance().getResources()
                            .getDimension(R.dimen.standard_105)
                    )
                    bookmarfb.animate().rotationBy(360f)
                    bookmarfb.animate().setDuration(1200)
                    //  ObjectAnimator animationbook = ObjectAnimator.ofFloat(bookmarfb, "translationX", 155f);
                    // animationbook.setDuration(1000);
                    //   animationbook.start();
                    summbaryfb.setVisibility(View.VISIBLE)
                    summbaryfb.animate().translationX(
                        -QuranGrammarApplication.getInstance().getResources()
                            .getDimension(R.dimen.standard_155)
                    )
                    summbaryfb.animate().rotationBy(360f)
                    helpfb.setVisibility(View.VISIBLE)
                    helpfb.animate().translationX(
                        -QuranGrammarApplication.getInstance().getResources()
                            .getDimension(R.dimen.standard_205)
                    )
                    helpfb.animate().rotationBy(360f)


                    /*   ObjectAnimator animhelp = ObjectAnimator.ofFloat(helpfb, "translationX", 255f);
                        animhelp.setDuration(1000);
                        animhelp.start();*/sharescreenfb.setVisibility(View.VISIBLE)
                    sharescreenfb.animate().translationX(
                        -QuranGrammarApplication.getInstance().getResources()
                            .getDimension(R.dimen.standard_255)
                    )
                    sharescreenfb.animate().rotationBy(360f)
                    sharescreenfb.animate().setDuration(1000)
                    tafsir.setOnClickListener(object : View.OnClickListener {
                        public override fun onClick(view: View?) {
                            closeFABMenu()
                            //HideFabMenu();
                            val readingintent: Intent = Intent(
                                (context as AppCompatActivity?),
                                TafsirFullscreenActivity::class.java
                            )
                            //  flowAyahWordAdapter.getItem(position);
                            val chapter_no: Int = ayahWord!!.getWord().get(0).getSurahId()
                            //   int verse = ayahWord.getWord().get(0).getVerseId();
                            val verse: Int = ayahWord!!.getWord().get(0).getVerseId()
                            //   String name = getSurahArabicName();
                            readingintent.putExtra(Constant.SURAH_ID, chapter_no)
                            readingintent.putExtra(Constant.AYAH_ID, verse)
                            readingintent.putExtra(Constant.SURAH_ARABIC_NAME, SurahName)
                            (context as AppCompatActivity?)!!.startActivity(readingintent)
                        }
                    })
                    bookmarfb.setOnClickListener(object : View.OnClickListener {
                        public override fun onClick(v: View?) {
                            closeFABMenu()
                            //   HideFabMenu();
                            bookMarkSelected(getPosition())
                        }
                    })
                    summbaryfb.setOnClickListener(object : View.OnClickListener {
                        public override fun onClick(v: View?) {
                            closeFABMenu()
                            //  HideFabMenu();
                            val chapter_no: Int = ayahWord!!.getWord().get(0).getSurahId()
                            //   int verse = ayahWord.getWord().get(0).getVerseId();
                            val verse: Int = ayahWord!!.getWord().get(0).getVerseId()
                            val dataBundle: Bundle = Bundle()
                            dataBundle.putInt(Constant.SURAH_ID, chapter_no)
                            val item: SurahSummary = SurahSummary()
                            item.setArguments(dataBundle)
                            val data: Int = (chapter_no)
                            //  FragmentTransaction transactions = fragmentManager.beginTransaction().setCustomAnimations(R.anim.abc_slide_in_top, android.R.anim.fade_out);
                            //   transactions.show(item);
                            SurahSummary.Companion.newInstance(data).show(
                                (context as AppCompatActivity?)!!.getSupportFragmentManager(),
                                NamesDetail.Companion.TAG
                            )
                        }
                    })
                    helpfb.setOnClickListener(object : View.OnClickListener {
                        public override fun onClick(v: View?) {
                            closeFABMenu()
                            //  HideFabMenu();

                            //    FragmentTransaction transactions = fragmentManager.beginTransaction().setCustomAnimations(R.anim.abc_slide_in_top, android.R.anim.fade_out);
                            //   transactions.show(item);
                            ParticleColorScheme.Companion.newInstance().show(
                                (context as AppCompatActivity?)!!.getSupportFragmentManager(),
                                WordAnalysisBottomSheet.Companion.TAG
                            )
                        }
                    })
                    sharescreenfb.setOnClickListener(object : View.OnClickListener {
                        public override fun onClick(v: View?) {
                            closeFABMenu()
                            //HideFabMenu();
                            takeScreenShot(
                                (context as AppCompatActivity?)!!.getWindow().getDecorView()
                            )
                        }

                        private fun takeScreenShot(view: View) {
                            val date: Date = Date()
                            val format: CharSequence =
                                DateFormat.format("MM-dd-yyyy_hh:mm:ss", date)
                            try {
                                val mainDir: File = File(
                                    (context as AppCompatActivity?)!!.getExternalFilesDir(
                                        Environment.DIRECTORY_PICTURES
                                    ), "FilShare"
                                )
                                if (!mainDir.exists()) {
                                    val mkdir: Boolean = mainDir.mkdir()
                                }
                                val path: String =
                                    mainDir.toString() + "/" + "Mushafapplication" + "-" + format + ".jpeg"
                                //    File zipfile = new File(getExternalFilesDir(null).getAbsolutePath() + getString(R.string.app_folder_path) + File.separator + DATABASEZIP);
                                view.setDrawingCacheEnabled(true)
                                val color: Int = Color.RED
                                val bitmap: Bitmap = getBitmapFromView(view, color)
                                //  Bitmap bitmap = Bitmap.createBitmap(view.getDrawingCache());
                                //  view.setDrawingCacheEnabled(false);
                                val imageFile: File = File(path)
                                val fileOutputStream: FileOutputStream = FileOutputStream(imageFile)
                                bitmap.compress(Bitmap.CompressFormat.PNG, 90, fileOutputStream)
                                fileOutputStream.flush()
                                fileOutputStream.close()
                                shareScreenShot(imageFile)
                            } catch (e: IOException) {
                                e.printStackTrace()
                            }
                        }

                        fun getBitmapFromView(view: View, defaultColor: Int): Bitmap {
                            val bitmap: Bitmap = Bitmap.createBitmap(
                                view.getWidth(), view.getHeight(), Bitmap.Config.ARGB_8888
                            )
                            val canvas: Canvas = Canvas(bitmap)
                            canvas.drawColor(defaultColor)
                            view.draw(canvas)
                            return bitmap
                        }

                        private fun shareScreenShot(imageFile: File) {
                            val uri: Uri = FileProvider.getUriForFile(
                                ((context as AppCompatActivity?)!!),
                                QuranGrammarApplication.getContext().getPackageName() + ".provider",
                                imageFile
                            )
                            /*      CropImage.activity(uri)
                .start(this);*/
                            val intent: Intent = Intent()
                            intent.setAction(Intent.ACTION_SEND)
                            intent.setType("image/*")
                            intent.putExtra(
                                Intent.EXTRA_TEXT,
                                "Download Application from Instagram"
                            )
                            intent.putExtra(Intent.EXTRA_STREAM, uri)
                            val resInfoList: List<ResolveInfo> =
                                (context as AppCompatActivity?)!!.getPackageManager()
                                    .queryIntentActivities(
                                        intent,
                                        PackageManager.MATCH_DEFAULT_ONLY
                                    )
                            for (resolveInfo: ResolveInfo in resInfoList) {
                                val packageName: String = resolveInfo.activityInfo.packageName
                                (context as AppCompatActivity?)!!.grantUriPermission(
                                    packageName,
                                    uri,
                                    Intent.FLAG_GRANT_WRITE_URI_PERMISSION or Intent.FLAG_GRANT_READ_URI_PERMISSION
                                )
                            }
                            //  startActivity(Intent.createChooser(intent, "Share PDF using.."));
                            try {
                                (context as AppCompatActivity?)!!.startActivity(
                                    Intent.createChooser(
                                        intent,
                                        "Share With"
                                    )
                                )
                            } catch (e: ActivityNotFoundException) {
                                Toast.makeText(
                                    (context as AppCompatActivity?),
                                    "No App Available",
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }
                    })
                }

                private fun bookMarkSelected(position: Int) {
                    //  position = flowAyahWordAdapter.getAdapterposition();

                    //  flowAyahWordAdapter.getItem(position);
                    val chapter_no: Int = ayahWord!!.getWord().get(0).getSurahId()
                    //   int verse = ayahWord.getWord().get(0).getVerseId();
                    val verse: Int = ayahWord!!.getWord().get(0).getVerseId()
                    val en: BookMarks = BookMarks()
                    en.setChapterno(chapter_no.toString())
                    en.setVerseno(verse.toString())
                    en.setSurahname("SurahName")
                    val utils: Utils = Utils(QuranGrammarApplication.getContext())
                    //     Utils utils = new Utils(ReadingSurahPartActivity.this);
                    utils.insertBookMark(en)
                    val snackbar: Snackbar = Snackbar
                        .make(view, "BookMark Created", Snackbar.LENGTH_LONG)
                    snackbar.setActionTextColor(Color.BLUE)
                    snackbar.setTextColor(Color.CYAN)
                    snackbar.setBackgroundTint(Color.BLACK)
                    snackbar.show()
                }

                private fun closeFABMenu() {
                    isFABOpen = false
                    fabmenu.animate().rotationBy(-180f)
                    tafsir.animate().translationX(0f)
                    tafsir.animate().rotationBy(0f)

                    //   jumptofb.animate().translationX(0);
                    bookmarfb.animate().translationX(0f)
                    bookmarfb.animate().rotationBy(360f)
                    summbaryfb.animate().translationX(0f)
                    helpfb.animate().translationX(0f)
                    sharescreenfb.animate().translationX(0f)
                    sharescreenfb.animate().rotationBy(360f)
                }
            })
            mafoolatarow.setOnClickListener(View.OnClickListener({ view1: View? ->
                TransitionManager.beginDelayedTransition(erabnotescardView, AutoTransition())
                if (hiddenGroup.getVisibility() == View.VISIBLE) {
                    hiddenGroup.setVisibility(View.GONE)
                    mafoolatarow.setImageResource(android.R.drawable.arrow_down_float)
                } else {
                    //     colllayout.setLayoutParams(params);
                    hiddenGroup.setVisibility(View.VISIBLE)
                    mafoolatarow.setImageResource(android.R.drawable.arrow_up_float)
                }
            }))
            erabexpand.setOnClickListener(View.OnClickListener({ view1: View? ->
                if (erab_textView.getVisibility() == View.GONE) {
                    erab_textView.setVisibility(View.VISIBLE)
                    //  AnimationUtility.slide_down(context, erabexpand);
                    AnimationUtility.AnimateArrow(90.0f, erabexpand)
                } else {
                    erab_textView.setVisibility(View.GONE)
                    AnimationUtility.AnimateArrow(0.0f, erabexpand)
                    //   Fader.slide_down(context,expandImageButton);
                }
            }))
            flow_word_by_word.setOnClickListener(View.OnClickListener({ view1: View? ->
                if (translate_textView.getVisibility() == View.GONE) translate_textView.setVisibility(
                    View.VISIBLE
                ) else translate_textView.setVisibility(View.VISIBLE)
            }))
            translate_textView.setOnClickListener(View.OnClickListener({ view1: View? ->
                if (translate_textView.getVisibility() == View.VISIBLE) translate_textView.setVisibility(
                    View.GONE
                ) else translate_textView.setVisibility(View.VISIBLE)
            }))
            erab_textView.setOnClickListener(View.OnClickListener({ view1: View? ->
                if (erab_textView.getVisibility() == View.VISIBLE) erab_textView.setVisibility(
                    View.GONE
                ) else erab_textView.setVisibility(View.VISIBLE)
            }))
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener.onItemClick(v, getLayoutPosition())
            }
        }

        public override fun onLongClick(v: View): Boolean {
            //   mItemClickListener.onItemLongClick(getAdapterPosition(), v);
            mItemClickListener!!.onItemLongClick(getBindingAdapterPosition(), v)
            return true
        }
    }

    companion object {
        private val TYPE_HEADER: Int = 0
        private val TYPE_ITEM: Int = 1
    }
}