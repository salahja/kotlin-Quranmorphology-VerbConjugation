package com.example.mushafconsolidated.Adaptersimport

android.content.SharedPreferencesimport android.content.res.TypedArrayimport android.graphics.Colorimport android.graphics.drawable.Drawableimport android.util.Logimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.widget.ImageViewimport android.widget.LinearLayoutimport android.widget.RelativeLayoutimport android.widget.TextViewimport androidx.preference.PreferenceManagerimport androidx.recyclerview.widget.RecyclerViewimport com.example.mushafconsolidated.Adapters.vtwoNewSurahDisplayAdapterimport com.example.mushafconsolidated.Entities.ChaptersAnaEntityimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.intrface.OnItemClickListenerimport com.example.utility.QuranGrammarApplicationimport com.example.utility.SharedPref












 





//public class VerseDisplayAdapter extends RecyclerView.Adapter<VerseDisplayAdapter.ItemViewAdapter> {
//public class SurahPartAdap extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
class vtwoNewSurahDisplayAdapter constructor(
    private val context: Context,
    allAnaChapters: ArrayList<ChaptersAnaEntity>
) : RecyclerView.Adapter<vtwoNewSurahDisplayAdapter.ItemViewAdapter>() {
    var mItemClickListener: OnItemClickListener? = null
    private var listonearray: List<ChaptersAnaEntity> = ArrayList()
    private var listtwoarray: List<ChaptersAnaEntity> = ArrayList()
    private val surahname: String? = null

    init {
        listonearray = allAnaChapters
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): vtwoNewSurahDisplayAdapter.ItemViewAdapter {
        val view: View
        //    view = LayoutInflater.from(parent.getContext()).inflate(R.layout.surarowlinear, parent, false);
        // view = LayoutInflater.from(parent.getContext()).inflate(R.layout.orignalsurarowlinear, parent, false);
        view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.relative_main_surah_row, parent, false)
        return vtwoNewSurahDisplayAdapter.ItemViewAdapter(view, viewType)
    }

    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun onBindViewHolder(
        holder: vtwoNewSurahDisplayAdapter.ItemViewAdapter,
        position: Int
    ) {
        Log.d(vtwoNewSurahDisplayAdapter.Companion.TAG, "onBindViewHolder: called")
        val surah: ChaptersAnaEntity = listonearray.get(position)
        val context: Context = QuranGrammarApplication.getContext()
        val pref: SharedPreferences = context.getSharedPreferences("lastread", Context.MODE_PRIVATE)
        val chapterno: Int = pref.getInt("surah", 1)
        val verse_no: Int = pref.getInt("ayah", 1)
        val sharedPref: SharedPref = SharedPref(context)
        val isNightmode: String = SharedPref.themePreferences()
        val imgs: TypedArray = this.context.getResources().obtainTypedArray(R.array.sura_imgs)
        val array: TypedArray = imgs
        val sharedPreferences: SharedPreferences =
            PreferenceManager.getDefaultSharedPreferences(context)
        val theme: String? = sharedPreferences.getString("themepref", "dark")
        val sb: String  = String ()
        sb.append(surah.getChapterid())
        sb.append(":")
        sb.append(surah.getNameenglish())
        val sbs: String  = String ()
        sbs.append(surah.getChapterid())
        //    sbs.append(surahright.getChapterid());
        //  sbs.append(":");
        //  sbs.append(surahright.getNameenglish());
        //   int surahrightIsmakki = surahright.getIsmakki();
        val surahIsmakki: Int = surah.getIsmakki()
        val cno: Int = surah.getChapterid()
        holder.tvnumber.setText(sbs)
        holder.tvarabic.setText(surah.getAbjadname())
        holder.tvenglish.setText(surah.getNameenglish())
        val drawable: Drawable? = imgs.getDrawable(cno - 1)
        holder.ivsurahicon.setImageDrawable(drawable)
        if (surahIsmakki == 1) {
            holder.makkimadaniIcon.setImageResource(R.drawable.ic_makkah_foreground)
        } else {
            holder.makkimadaniIcon.setImageResource(R.drawable.ic_madinah_foreground)
        }

        /*
    if (theme.equals("dark")) {
      holder.surahcardview.setCardBackgroundColor(context.getResources().getColor(R.color.color_background_overlay));


    } else if (theme.equals("blue")) {
      holder.surahcardview.setCardBackgroundColor(context.getResources().getColor(R.color.solarizedBase02));

    }
 */if ((theme == "dark") || (theme == "blue")) {
            holder.makkimadaniIcon.setColorFilter(Color.CYAN)
            holder.ivsurahicon.setColorFilter(Color.CYAN)
        } else {
            holder.makkimadaniIcon.setColorFilter(Color.BLUE)
            holder.ivsurahicon.setColorFilter(Color.BLACK)
        }
        //   holder.tvarabic.setTextSize(SharedPref.SeekarabicFontsize());
    }

    public override fun getItemViewType(position: Int): Int {
        return listonearray.get(position).getPart_no()
    }

    public override fun getItemCount(): Int {
        return listonearray.size
    }

    fun getItem(position: Int): Any {
        return listonearray.get(position)
    }

    fun setUp(listone: List<ChaptersAnaEntity>, listtwo: List<ChaptersAnaEntity>) {
        listonearray = listone
        listtwoarray = listtwo
    }

    fun setUp(allAnaChapters: ArrayList<ChaptersAnaEntity>) {
        listonearray = allAnaChapters
    }

    inner class ItemViewAdapter internal constructor(R.layout: View, viewType: Int) :
        RecyclerView.ViewHolder(R.layout), View.OnClickListener // current clickListerner
    {
        var tvnumber: TextView
        var tvsurahright: TextView? = null
        var tvarabic: TextView
        var tvenglish: TextView
        var overlayTypeChapterView: TextView? = null
        var overlayTypePartView: TextView? = null
        var surah_name_arabic: TextView? = null

        // CardView surahcardview;
        var referenceview: TextView? = null
        var row_surah: RelativeLayout? = null

        //   public ConstraintLayout surah_row_table;///for rnew_surah_row
        var surah_row_table: LinearLayout? = null
        var makkimadaniIcon: ImageView
        var ivsurahicon: ImageView
        var tvarabicright: ImageView? = null

        init {
            //   surahcardview = itemView.findViewById(R.id.surahcardview);
            tvenglish = itemView.findViewById(id.tvenglish)
            tvnumber = itemView.findViewById(id.tvNumber)
            //            tvsurahright = itemView.findViewById(R.id.tvSuraright);
            tvarabic = itemView.findViewById(id.tvArabic)
            makkimadaniIcon = itemView.findViewById(id.makkimadaniicon)
            //  overlayTypeChapterView = itemView.findViewById(R.id.overlayTypeChapterView);
            ivsurahicon = itemView.findViewById(id.surahicon)
            //  overlayTypeChapterView.setOnClickListener(this);
            // overlayTypePartView.setOnClickListener(this);
            layout.setOnClickListener(this) // current clickListerner
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }
    }

    companion object {
        private val TAG: String = "SurahPartAdap "
    }
}