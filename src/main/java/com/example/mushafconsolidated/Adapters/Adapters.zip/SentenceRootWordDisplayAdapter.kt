package com.example.mushafconsolidated.Adaptersimport

android.content.SharedPreferencesimport android.graphics.Typeface  import android.text.TextUtils.TruncateAtimport android.util.Logimport android.view.LayoutInflaterimport android.view.Viewimport android.view.ViewGroupimport android.widget.ImageViewimport android.widget.TextViewimport androidx.fragment.app.FragmentActivityimport androidx.preference.PreferenceManagerimport androidx.recyclerview.widget.RecyclerViewimport com.example.Constantimport com.example.mushafconsolidated.Adapters.SentenceRootWordDisplayAdapterimport com.example.mushafconsolidated.Entities.NewCorpusExpandWbwPOJOimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.R.stringimport com.example.mushafconsolidated.intrface.OnItemClickListenerimport com.google.android.material.chip.Chip
 
 
 
 
 
 
 
 
 
  
 
 
 
 
 
 

class SentenceRootWordDisplayAdapter constructor(private var context: Context) :
    RecyclerView.Adapter<SentenceRootWordDisplayAdapter.ItemViewAdapter>() {
    var mItemClickListener: OnItemClickListener? = null
    var ismalatitle: String = "( الآلَة:)"
    var alaheader: String = "اِسْم الآلَة"
    var zarfheader: String = "اِسْم الْظَرفْ"
    var rootcolor: Int = 0
    var weaknesscolor: Int = 0
    var wazancolor: Int = 0
    var ismujarrad: Boolean = false
    var ismazeed: Boolean = false
    var isparticple: Boolean = false
    var isconjugation: Boolean = false
    var isSarfSagheerMazeed: Boolean = false
    private val worddetails: HashMap<String, SpannableString >? = null
    private val vbdetail: HashMap<String, String>? = null
    private var corpusexpand: ArrayList<NewCorpusExpandWbwPOJO>? = null
    private val isSarfSagheerThulahi: Boolean = false
    private val isverbconjugation: Boolean = false
    private val particples: Boolean = false
    private val ismfaelmafool: ArrayList<ArrayList<*>>? = null
    private val isnoun: Boolean = false
    private var spannalbeShart: SpannableString ? = null
    private var spannableHarf: SpannableString ? = null
    private var worddetailsmap: HashMap<Int, HashMap<String, SpannableString ?>>? = null
    private var verbdetailsmap: HashMap<Int, HashMap<String, String>?>? = null
    private var spannable: SpannableString ? = null

    // private ArrayList<GrammarWordEntity> grammarArayList = new ArrayList<>();
    private val sarfsagheer: ArrayList<ArrayList<*>>? = null
    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): SentenceRootWordDisplayAdapter.ItemViewAdapter {
        val view: View
        view = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.sentence_word_details, parent, false)
        return SentenceRootWordDisplayAdapter.ItemViewAdapter(view)
    }

    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun onBindViewHolder(
        holder: SentenceRootWordDisplayAdapter.ItemViewAdapter,
        position: Int
    ) {
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            context
        )
        val quranFont: String? = sharedPreferences.getString("quranFont", "kitab.ttf")
        val appliedFont: Typeface = Typeface.createFromAsset(
            context.getAssets(), quranFont
        )
        val theme: String? = sharedPreferences.getString("themePref", "dark")
        Log.d(SentenceRootWordDisplayAdapter.Companion.TAG, "onBindViewHolder: called")
        if ((theme == "dark")) {
            rootcolor = Constant.BCYAN
            weaknesscolor = Constant.BYELLOW
            wazancolor = Constant.BBLUE
        } else {
            rootcolor = Constant.WBURNTUMBER
            weaknesscolor = Constant.GOLD
            wazancolor = Constant.WMIDNIHTBLUE
        }
        val wordno: SpannableString ? = worddetailsmap!!.get(position + 1)!!.get("wordno")
        val wordposition: Int = wordno.toString().toInt()
        if (verbdetailsmap!!.get(wordposition) != null) {
            ismujarrad = !(verbdetailsmap!!.get(wordposition)!!.get("wazan") == "null")
            ismazeed = !(verbdetailsmap!!.get(wordposition)!!.get("form") == "null")
        }
        isparticple = worddetailsmap!!.get(wordposition)!!.get("PART") != null
        isconjugation = ismujarrad || ismazeed || isparticple
        //  holder.wordView.setText(worddetailsmap.get(wordposition).get("word"));
        val word: String = worddetailsmap!!.get(wordposition)!!.get("word").toString()
        holder.wordView.setText(word)
        println(worddetailsmap!!.get(wordposition)!!.get("word"))
        holder.lemma.setText(
            SentenceRootWordDisplayAdapter.Companion.LEMMA + worddetailsmap!!.get(wordposition)!!
                .get("lemma")
        )
        holder.wdetailstv.setText(
            worddetailsmap!!.get(wordposition)!!.get("worddetails"),
            TextView.BufferType.SPANNABLE
        )
        if (!(worddetailsmap!!.get(wordposition)!!.get("root") == null)) {
            holder.rootView.setText(
                SentenceRootWordDisplayAdapter.Companion.ROOTWORDSTRING + worddetailsmap!!.get(
                    wordposition
                )!!
                    .get("root")
            )
        }
        if (!(worddetailsmap!!.get(wordposition)!!.get("wordtranslation") == null)) {
            holder.translationView.setText(
                worddetailsmap!!.get(wordposition)!!.get("wordtranslation")
            )
        }
        //   holder.wordView.setText(worddetailsmap.get(wordposition).get("word"));
        if (!(worddetailsmap!!.get(wordposition)!!.get("PRON") == null)) {
            holder.pronoundetails.setText(worddetailsmap!!.get(wordposition)!!.get("PRON"))
        }
        if (isconjugation) {
            holder.verbconjugationbtn.setVisibility(View.VISIBLE)
            holder.wordoccurancebtn.setVisibility(View.VISIBLE)
        } else if (!(worddetailsmap!!.get(wordposition)!!.get("noun") == null)) {
            holder.noun.setText(worddetailsmap!!.get(wordposition)!!.get("noun"))
            holder.wordoccurancebtn.setVisibility(View.VISIBLE)
            holder.verbconjugationbtn.setVisibility(View.GONE)
        } else {
            holder.verbconjugationbtn.setVisibility(View.GONE)
            holder.wordoccurancebtn.setVisibility(View.GONE)
        }
        val wordd: Int? = null
        val verb: Int? = null
        var verbwordno: String? = ""
        try {
            verbwordno = verbdetailsmap!!.get(wordposition)!!.get("wordno")
        } catch (e: NullPointerException) {
        }
        //   wordd = Integer.valueOf(verbwordno);
        //    verb = Integer.valueOf(String.valueOf(worddetailswordno));
        val vb: String  = String ()
        vb.append("V-")
        try {
            if (worddetailsmap!!.get(wordposition)!!.get("thulathi") != null) {
                vb.append(worddetailsmap!!.get(wordposition)!!.get("thulathi"))
            }
        } catch (e: NullPointerException) {
        }
        try {
            if (worddetailsmap!!.get(wordposition)!!.get("png") != null) {
                vb.append(worddetailsmap!!.get(wordposition)!!.get("png"))
            }
        } catch (e: NullPointerException) {
        }
        try {
            if (worddetailsmap!!.get(wordposition)!!.get("tense") != null) {
                vb.append(worddetailsmap!!.get(wordposition)!!.get("tense"))
            }
        } catch (e: NullPointerException) {
        }
        try {
            if (worddetailsmap!!.get(wordposition)!!.get("voice") != null) {
                vb.append(worddetailsmap!!.get(wordposition)!!.get("voice"))
            }
        } catch (e: NullPointerException) {
        }
        try {
            if (worddetailsmap!!.get(wordposition)!!.get("mood") != null) {
                vb.append(worddetailsmap!!.get(wordposition)!!.get("mood"))
            }
        } catch (e: NullPointerException) {
        }
        if (vb.length > 2) {
            holder.verbdetails.setVisibility(View.VISIBLE)
            holder.verbdetails.setText(vb.toString())
        }
        //  wordbdetail.put("surahid", SpannableString .valueOf(String.valueOf(corpusSurahWord.get(0).getSurah())));
        //   wordbdetail.put("ayahid", SpannableString .valueOf(String.valueOf(corpusSurahWord.get(0).getAyah())));
        //   wordbdetail.put("wordno", SpannableString .valueOf(String.valueOf(corpusSurahWord.get(0).getWordno())));
        holder.referenceView.setText(
            worddetailsmap!!.get(wordposition)!!
                .get("surahid").toString() + ":" + worddetailsmap!!.get(wordposition)!!
                .get("ayahid") + ":" + worddetailsmap!!.get(wordposition)!!.get("wordno")
        )
        val sarfsagheerlen: Int = 0
        val length: Int = 0
        val toArray: Array<Any?> = arrayOfNulls(0)
        val mazeedArray: Array<Any?> = arrayOfNulls(0)
        holder.quranverseShart.setEllipsize(TruncateAt.MARQUEE)
        holder.spannableverse.setEllipsize(TruncateAt.MARQUEE)
        if (null != spannalbeShart) {
            val spans: Array<Any> =
                spannalbeShart!!.getSpans(0, spannalbeShart!!.length, Any::class.java)
            if (spans.size > 0) {
                holder.quranverseShart.setText(spannalbeShart)
                holder.quranverseShart.setTypeface(appliedFont)
            }
        }
        if (null != spannableHarf) {
            val spans: Array<Any> =
                spannableHarf!!.getSpans(0, spannableHarf!!.length, Any::class.java)
            if (spans.size > 0) {
                holder.spannableverse.setText(spannableHarf)
                holder.spannableverse.setTypeface(appliedFont)
            }
        }
        if (null != spannable) {
            val spans: Array<Any> = spannable!!.getSpans(0, spannable!!.length, Any::class.java)
            if (spans.size > 0) {
                holder.spannableverse.setText(spannable, TextView.BufferType.SPANNABLE)
                //   holder.spannableverse.setText(spannable);
                holder.spannableverse.setTypeface(appliedFont)
            }
        }
    }

    public override fun getItemCount(): Int {
        return worddetailsmap!!.size
    }

    fun setRootWordsAndMeanings(
        sencorpusSurahWord: ArrayList<NewCorpusExpandWbwPOJO>?,
        spannableShart: SpannableString ?,
        spannableHarf: SpannableString ?,
        spannable: SpannableString ?,
        worddetailsmap: HashMap<Int, HashMap<String, SpannableString ?>>?,
        verbdetailsmap: HashMap<Int, HashMap<String, String>?>?,
        activity: FragmentActivity
    ) {
        this.worddetailsmap = worddetailsmap
        this.verbdetailsmap = verbdetailsmap
        context = activity
        spannalbeShart = spannableShart
        this.spannableHarf = spannableHarf
        corpusexpand = sencorpusSurahWord
        this.spannable = spannable
    }

    public override fun getItemId(position: Int): Long {
        val wordno1: SpannableString ? = worddetailsmap!!.get(position)!!.get("wordno")
        val map: HashMap<String, SpannableString ?> = (worddetailsmap!!.get(position))!!
        val wordno: SpannableString ? = map.get("wordno")
        //   return SpannableString ;
        return wordno1.toString().toInt().toLong()
    }

    inner class ItemViewAdapter constructor(view: View) : RecyclerView.ViewHolder(view),
        View.OnClickListener // current clickListerner
    {
        val amr: TextView
        val nahiamr: TextView
        val ismfail: TextView
        val mumaroof: TextView
        val mamaroof: TextView
        val ismala: TextView
        val ismmafool: TextView
        val mumajhool: TextView
        val mamajhool: TextView
        val ismzarf: TextView

        //ISMFAEL
        val isone: TextView
        val istwo: TextView
        val isthree: TextView
        val isfour: TextView
        val isfive: TextView
        val issix: TextView
        val isseven: TextView
        val iseight: TextView
        val isnine: TextView
        val ismfemone: TextView
        val ismfemtwo: TextView
        val ismfemthree: TextView
        val ismfemfour: TextView
        val ismfemfive: TextView
        val ismfemsix: TextView
        val ismfemseven: TextView
        val ismfemeight: TextView
        val ismfemnine: TextView
        val imafone: TextView
        val imaftwo: TextView
        val imafthree: TextView
        val imaffour: TextView
        val imaffive: TextView
        val imafsix: TextView
        val imafseven: TextView
        val imafeight: TextView
        val imafnine: TextView
        val imafoolfemone: TextView
        val imafoolfemtwo: TextView
        val imafoolfemthree: TextView
        val imafoolfemfour: TextView
        val imafoolfemfive: TextView
        val imafoolfemsix: TextView
        val imafoolfemseven: TextView
        val imafoolfemeight: TextView
        val imafoolfemnine: TextView
        val mifalone: TextView
        val mifaltwo: TextView
        val mifalthree: TextView
        val mifalfour: TextView
        val mifalfive: TextView
        val mifalsix: TextView
        val mifalseven: TextView
        val mifaleight: TextView
        val mifalnine: TextView
        val mifalatunone: TextView
        val mifalatuntwo: TextView
        val mifalatunthree: TextView
        val mifalatunfour: TextView
        val mifalatunfive: TextView
        val mifalatunsix: TextView
        val mifalatunseven: TextView
        val mifalatuneight: TextView
        val mifalatunnine: TextView
        val mifaalone: TextView
        val mifaaltwo: TextView
        val mifaalthree: TextView
        val mifaalfour: TextView
        val mifaalfive: TextView
        val mifaalsix: TextView
        val mifaalseven: TextView
        val mifaaleight: TextView
        val mifaalnine: TextView
        val mafalunone: TextView
        val mafaluntwo: TextView
        val mafalunthree: TextView
        val mafalunfour: TextView
        val mafalunfive: TextView
        val mafalunsix: TextView
        val mafalunseven: TextView
        val mafaluneight: TextView
        val mafalunnine: TextView
        val sin1: TextView
        val dual1: TextView
        val plu1: TextView
        val sin2: TextView
        val dual2: TextView
        val plu2: TextView
        val sin3: TextView
        val dual3: TextView
        val plu3: TextView
        val sin4: TextView
        val dual4: TextView
        val plu4: TextView
        val nom: TextView
        val acc: TextView
        val gen: TextView
        val nom1: TextView
        val acc1: TextView
        val gen1: TextView
        val nom2: TextView
        val acc2: TextView
        val gen2: TextView
        val nom3: TextView
        val acc3: TextView
        val gen3: TextView
        val referenceView: TextView
        val wdetailstv: TextView
        val lemma: TextView
        val verbdetails: TextView
        val noun: TextView
        val pronoundetails: TextView
        val translationView: TextView
        val rootView: TextView
        val quranverseShart: TextView
        val spannableverse: TextView
        val babname: TextView
        val rootword: TextView
        val wazan: TextView
        val ismzarfheader: TextView
        val ismalaheader: TextView
        val masdaro: TextView
        val masdart: TextView
        val babno: TextView
        val babdetails: TextView
        val weaknessname: TextView
        val weaknesstype: TextView
        val sheet: View
        var wordView: Chip
        var dismissview: ImageView
        var apmas: TextView
        var apfem: TextView
        var ppmas: TextView
        var ppfem: TextView
        var verbconjugationbtn: TextView
        var verbOccurancebtn: TextView
        var wordoccurancebtn: TextView

        init {
            spannableverse = view.findViewById(id.spannableverse)
            quranverseShart = view.findViewById(id.quranverseShart)
            verbconjugationbtn = view.findViewById(id.verbconjugationbtn)
            verbOccurancebtn = view.findViewById(id.verboccurance)
            wordoccurancebtn = view.findViewById(id.wordoccurance)
            babname = view.findViewById(id.babno)
            rootword = view.findViewById(id.weaknesstype)
            ismzarfheader = view.findViewById(id.ismzarfheader)
            pronoundetails = view.findViewById(id.pronoundetails)
            noun = view.findViewById(id.noundetails)
            sheet = view.findViewById(id.sheet)
            wdetailstv = view.findViewById(id.wordDetails)
            lemma = view.findViewById(id.lemma)
            verbdetails = view.findViewById(id.verbdetails)
            dismissview = view.findViewById(id.dismissView)
            referenceView = view.findViewById(id.referenceView)
            wordView = view.findViewById(id.wordView)
            translationView = view.findViewById(id.translationView)
            rootView = view.findViewById(id.rootView)
            //   if(!particples) {
            //      dismissview.setOnClickListener(this);
            //  }
            //     view.setOnClickListener(this); // current clickListerner
            ismalaheader = view.findViewById(id.ismalaheader)
            ismala = view.findViewById(id.ismaalatable)
            wazan = view.findViewById(id.wazan)
            ismfail = view.findViewById(id.ismfail)
            masdaro = view.findViewById(id.masdar)
            mumaroof = view.findViewById(id.mumaroof)
            mamaroof = view.findViewById(id.mamaroof)
            ismmafool = view.findViewById(id.ismmafool)
            masdart = view.findViewById(id.masdar2)
            mumajhool = view.findViewById(id.mumajhool)
            mamajhool = view.findViewById(id.mamajhool)
            amr = view.findViewById(id.amr)
            nahiamr = view.findViewById(id.nahiamr)
            babno = view.findViewById(id.babno)
            ismzarf = view.findViewById(id.zarftable)
            babdetails = view.findViewById(id.babno)
            weaknesstype = view.findViewById(id.weaknesstype)
            weaknessname = view.findViewById(id.weknessname)
            var listcollapse: ImageView?
            spannableverse.setOnClickListener(this)
            //  view.setOnClickListener(this);
            wordView.setOnClickListener(this)
            verbconjugationbtn.setOnClickListener(this)
            wordoccurancebtn.setOnClickListener(this)
            //  verbOccurancebtn.setOnClickListener(this);
            wordoccurancebtn.setOnClickListener(this)
            sin4 = view.findViewById(id.singular4)
            dual4 = view.findViewById(id.dual4)
            plu4 = view.findViewById(id.plural4)
            //    }
            nom = view.findViewById(id.nominative)
            acc = view.findViewById(id.accusative)
            gen = view.findViewById(id.genitive)
            nom1 = view.findViewById(id.nominative1)
            acc1 = view.findViewById(id.accusative1)
            gen1 = view.findViewById(id.genitive1)
            nom2 = view.findViewById(id.nominative2)
            acc2 = view.findViewById(id.accusative2)
            gen2 = view.findViewById(id.genitive2)
            nom3 = view.findViewById(id.nominative3)
            acc3 = view.findViewById(id.accusative3)
            gen3 = view.findViewById(id.genitive3)
            sin1 = view.findViewById(id.singular1)
            dual1 = view.findViewById(id.dual1)
            plu1 = view.findViewById(id.plural1)
            sin2 = view.findViewById(id.singular2)
            dual2 = view.findViewById(id.dual2)
            plu2 = view.findViewById(id.plural2)
            sin3 = view.findViewById(id.singular3)
            dual3 = view.findViewById(id.dual3)
            plu3 = view.findViewById(id.plural3)
            apmas = view.findViewById(id.apmas)
            apfem = view.findViewById(id.apfem)
            ppmas = view.findViewById(id.ppmas)
            ppfem = view.findViewById(id.ppfem)
            ismfemone = view.findViewById(id.ismfemone)
            if (particples) {
                ismfemone.setText(string.faelmazi)
            }
            ismfemtwo = view.findViewById(id.ismfemtwo)
            ismfemthree = view.findViewById(id.ismfemthree)
            ismfemfour = view.findViewById(id.ismfemfour)
            ismfemfive = view.findViewById(id.ismfemfive)
            ismfemsix = view.findViewById(id.ismfemsix)
            ismfemseven = view.findViewById(id.ismfemseven)
            ismfemeight = view.findViewById(id.ismfemeight)
            ismfemnine = view.findViewById(id.ismfemnine)
            //
            isone = view.findViewById(id.isone)
            istwo = view.findViewById(id.istwo)
            isthree = view.findViewById(id.isthree)
            isfour = view.findViewById(id.isfour)
            isfive = view.findViewById(id.isfive)
            issix = view.findViewById(id.issix)
            isseven = view.findViewById(id.isseven)
            iseight = view.findViewById(id.iseight)
            isnine = view.findViewById(id.isnine)
            //ismmafoolmasculine
            imafone = view.findViewById(id.imafone)
            imaftwo = view.findViewById(id.imaftwo)
            imafthree = view.findViewById(id.imafthree)
            imaffour = view.findViewById(id.imaffour)
            imaffive = view.findViewById(id.imaffive)
            imafsix = view.findViewById(id.imafsix)
            imafseven = view.findViewById(id.imafseven)
            imafeight = view.findViewById(id.imafeight)
            imafnine = view.findViewById(id.imafnine)
            //ismmafoolfeb
            imafoolfemone = view.findViewById(id.imafoolfemone)
            imafoolfemtwo = view.findViewById(id.imafoolfemtwo)
            imafoolfemthree = view.findViewById(id.imafoolfemthree)
            imafoolfemfour = view.findViewById(id.imafoolfemfour)
            imafoolfemfive = view.findViewById(id.imafoolfemfive)
            imafoolfemsix = view.findViewById(id.imafoolfemsix)
            imafoolfemseven = view.findViewById(id.imafoolfemseven)
            imafoolfemeight = view.findViewById(id.imafoolfemeight)
            imafoolfemnine = view.findViewById(id.imafoolfemnine)
            mifalone = view.findViewById(id.mifalone)
            mifaltwo = view.findViewById(id.mifaltwo)
            mifalthree = view.findViewById(id.mifalthree)
            mifalfour = view.findViewById(id.mifalfour)
            mifalfive = view.findViewById(id.mifalfive)
            mifalsix = view.findViewById(id.mifalsix)
            mifalseven = view.findViewById(id.mifalseven)
            mifaleight = view.findViewById(id.mifaleight)
            mifalnine = view.findViewById(id.mifalnine)
            mifalatunone = view.findViewById(id.mifalatunone)
            mifalatuntwo = view.findViewById(id.mifalatuntwo)
            mifalatunthree = view.findViewById(id.mifalatunthree)
            mifalatunfour = view.findViewById(id.mifalatunfour)
            mifalatunfive = view.findViewById(id.mifalatunfive)
            mifalatunsix = view.findViewById(id.mifalatunsix)
            mifalatunseven = view.findViewById(id.mifalatunseven)
            mifalatuneight = view.findViewById(id.mifalatuneight)
            mifalatunnine = view.findViewById(id.mifalatunnine)
            mifaalone = view.findViewById(id.mifaalone)
            mifaaltwo = view.findViewById(id.mifaaltwo)
            mifaalthree = view.findViewById(id.mifaalthree)
            mifaalfour = view.findViewById(id.mifaalfour)
            mifaalfive = view.findViewById(id.mifaalfive)
            mifaalsix = view.findViewById(id.mifaalsix)
            mifaalseven = view.findViewById(id.mifaalseven)
            mifaaleight = view.findViewById(id.mifaaleight)
            mifaalnine = view.findViewById(id.mifaalnine)
            mafalunone = view.findViewById(id.mafalunone)
            mafaluntwo = view.findViewById(id.mafaluntwo)
            mafalunthree = view.findViewById(id.mafalunthree)
            mafalunfour = view.findViewById(id.mafalunfour)
            mafalunfive = view.findViewById(id.mafalunfive)
            mafalunsix = view.findViewById(id.mafalunsix)
            mafalunseven = view.findViewById(id.mafalunseven)
            mafaluneight = view.findViewById(id.mafaluneight)
            mafalunnine = view.findViewById(id.mafalunnine)
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }
    }

    companion object {
        private val TAG: String = "VerseDisplayAdapter"
        private val ROOTWORDSTRING: String = "Root Word:-"
        private val LEMMA: String = "Lemma/Derivative-"
    }
}