package com.example.mushafconsolidated.Adaptersimport

import CorpusWbwWord
import TameezEnt

class FlowAyahWordAdapterPassage(
    private val passageLinkedMap: LinkedHashMap<Int, ArrayList<CorpusWbwWord>>,
    private val mutlaqent: List<mutlaqagent>,
    private val tameezEnts: ArrayList<TameezEnt>,
    private val badalErabNotesEnt: ArrayList<BadalErabNotesEnt>,
    private val liajlihient: ArrayList<LiajlihiEnt>,
    private val jumlahaliya: ArrayList<HalEnt>,
    private val mafoolBihis: ArrayList<MafoolBihi>,
    private val header: ArrayList<String>,
    private val allofQuran: List<QuranEntity>,
    private val ayahWordArrayList: ArrayList<CorpusAyahWord>,
    var context: Context,
    val surah_id: Long,
    private val SurahName: String,
    private val isMakkiMadani: Int,
    listener: OnItemClickListenerOnLong?
) : RecyclerView.Adapter<FlowAyahWordAdapterPassage.ItemViewAdapter>(), OnItemClickListenerOnLong {
    private var colorwordfont: Typeface? = null
    private val issentence: Boolean
    var adapterposition: Int = 0
    var arabic: TextView? = null
    var rootword: TextView? = null
    var arabicfontSize: Int
    var translationfontsize: Int
    var mItemClickListener: OnItemClickListenerOnLong?
    private var isNightmode: String? = null
    private var headercolor: Int = 0
    private val kathir_translation: WebView? = null

    init {
        val sharedPreferences: SharedPreferences = PreferenceManager.getDefaultSharedPreferences(
            context
        )
        //   showTranslation =
        //        sharedPreferences.getBoolean(Config.SHOW_TRANSLATION, Config.defaultShowTranslation);
        sharedPreferences.getBoolean(Config.Companion.SHOW_Erab, Config.Companion.defaultShowErab)
        issentence = sharedPreferences.getBoolean("grammarsentence", false)
        arabicfontSize = sharedPreferences.getInt("pref_font_arabic_key", 18)
        translationfontsize = sharedPreferences.getInt("pref_font_englsh_key", 18)
        mItemClickListener = listener
    }

    fun addContext(context: Context) {
        this.context = context
    }

    public override fun getItemViewType(position: Int): Int {
        if (position == 0) {
            return FlowAyahWordAdapterPassage.Companion.TYPE_HEADER
        } else {
            return FlowAyahWordAdapterPassage.Companion.TYPE_ITEM
        }
    }

    public override fun getItemCount(): Int {
        return passageLinkedMap.size + 1
        //     return  quran.size();
    }

    public override fun getItemId(position: Int): Long {
        val ayahWord: ArrayList<CorpusWbwWord> = (passageLinkedMap.get(position))!!
        val itemId: Long = ayahWord.get(position).getVerseId().toLong()
        return itemId
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): FlowAyahWordAdapterPassage.ItemViewAdapter {
        val view: View
        if (viewType == 0) {
            view =
                LayoutInflater.from(parent.getContext()).inflate(R.layout.surah_header, parent, false)
            return FlowAyahWordAdapterPassage.ItemViewAdapter(view, viewType)
        } else {
            view = LayoutInflater.from(parent.getContext())
                .inflate(R.layout.row_ayah_word, parent, false)
            //   view = LayoutInflater.from(parent.getContext()).inflate(R.layout.item_viewer_aya_cardview, parent, false);
            return FlowAyahWordAdapterPassage.ItemViewAdapter(view, viewType)
        }
    }

    public override fun onBindViewHolder(
        holder: FlowAyahWordAdapterPassage.ItemViewAdapter,
        position: Int
    ) {
        val sharedPreferences: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                context
            )
        isNightmode = sharedPreferences.getString("themepref", "dark")
        val arabic_font_selection: String? =
            sharedPreferences.getString("Arabic_Font_Selection", "quranicfontregular.ttf")
        val normalfontstr: String? =
            sharedPreferences.getString("Arabic_Font_Selection", "me_quran.ttf")
        val wbwcoloredfont: Typeface = Typeface.createFromAsset(
            context.getAssets(), arabic_font_selection
        )
        val normalfont: Typeface = Typeface.createFromAsset(
            context.getAssets(), normalfontstr
        )
        val showrootkey: Boolean = sharedPreferences.getBoolean("showrootkey", true)
        val showErab: Boolean = sharedPreferences.getBoolean("showErabKey", true)
        val showWordColor: Boolean = sharedPreferences.getBoolean("colortag", true)
        val showTransliteration: Boolean =
            sharedPreferences.getBoolean("showtransliterationKey", true)
        val showJalalayn: Boolean = sharedPreferences.getBoolean("showEnglishJalalayn", true)
        val showTranslation: Boolean = sharedPreferences.getBoolean("showTranslationKey", true)
        val showWordByword: Boolean = sharedPreferences.getBoolean("wordByWord", false)
        val showKathir: Boolean = sharedPreferences.getBoolean("showKathir", false)
        val whichtranslation: String? = sharedPreferences.getString("selecttranslation", "en_sahih")
        val FONTS_LOCATION_PATH: String = "fonts/DejaVuSans.ttf"
        colorwordfont = Typeface.createFromAsset(
            QuranGrammarApplication.getContext().getAssets(),
            FONTS_LOCATION_PATH
        )
        if (getItemViewType(position) == 0) {
            val imgs: TypedArray = context.getResources().obtainTypedArray(R.array.sura_imgs)
            // You have to set your header items values with the help of model class and you can modify as per your needs
            holder.tvRukus.setText(String.format("Ruku's :%s", header.get(0)))
            holder.tvVerses.setText(String.format("Aya's :%s", header.get(1)))
            holder.tvSura.setText(header.get(3))
            val chapterno: String = header.get(2)
            val tauba: Int = chapterno.toInt()
            if (tauba == 9) {
                holder.ivBismillah.setVisibility(View.GONE)
            }
            if (isMakkiMadani == 1) {
                holder.ivLocationmakki.setVisibility(View.VISIBLE)
                holder.ivLocationmadani.setVisibility(View.GONE)
            } else {
                holder.ivLocationmadani.setVisibility(View.VISIBLE)
                holder.ivLocationmakki.setVisibility(View.GONE)
            }
            val drawable: Drawable? = imgs.getDrawable(chapterno.toInt() - 1)
            holder.ivSurahIcon.setImageDrawable(drawable)
            if ((isNightmode == "dark") || (isNightmode == "blue") || (isNightmode == "white")) {
                headercolor = Color.YELLOW
                holder.ivLocationmakki.setColorFilter(Color.CYAN)
                holder.ivSurahIcon.setColorFilter(Color.CYAN)
                holder.ivLocationmadani.setColorFilter(Color.CYAN)
            } else {
                headercolor = Color.BLUE
                holder.ivLocationmakki.setColorFilter(Color.BLACK)
                holder.ivSurahIcon.setColorFilter(Color.BLACK)
                holder.ivLocationmadani.setColorFilter(Color.BLACK)
            }
        } else {
            displayAyats(
                normalfont,
                showrootkey,
                holder,
                position - 1,
                sharedPreferences,
                wbwcoloredfont,
                showErab,
                showWordColor,
                showTransliteration,
                showJalalayn,
                showTranslation,
                showWordByword,
                whichtranslation,
                showKathir
            )
        }
    }

    private fun displayAyats(
        normalfont: Typeface,
        showrootkey: Boolean,
        holder: FlowAyahWordAdapterPassage.ItemViewAdapter,
        position: Int,
        sharedPreferences: SharedPreferences,
        custom_font: Typeface,
        showErab: Boolean,
        showWordColor: Boolean,
        showTransliteration: Boolean,
        showJalalayn: Boolean,
        showTranslation: Boolean,
        showWordByword: Boolean,
        whichtranslation: String?,
        showKathir: Boolean
    ) {
        //   holder.flowwbw.setBackgroundColor(R.style.Theme_DarkBlue);
        var entity: QuranEntity? = null
        val wbw: String? = sharedPreferences.getString("wbw", Context.MODE_PRIVATE.toString())
        try {
            entity = allofQuran.get(position)
        } catch (e: IndexOutOfBoundsException) {
            println("check")
        }
        var mafoolBihi: MafoolBihi? = null
        try {
            mafoolBihi = mafoolBihis.get(position)
        } catch (e: IndexOutOfBoundsException) {
            println(e.message)
        }
        val ayahWord: CorpusAyahWord = ayahWordArrayList.get(position)
        val passageAyahworrd: ArrayList<CorpusWbwWord> = (passageLinkedMap.get(position + 1))!!
        if (null != entity) {
            storepreferences(entity)
        }
        val quranverses: SpannableString = ayahWordArrayList.get(position).getSpannableverse()
        holder.quran_textView.setText(quranverses)
        holder.quran_textView.setTextSize(arabicfontSize.toFloat())
        holder.quran_textView.setTypeface(custom_font)
        holder.base_cardview.setVisibility(View.GONE)
        val mf: SpannableString  = SpannableString ()
        val halsb: String  = String ()
        val tameezsb: String  = String ()
        val badalsb: String  = String ()
        val ajlihisb: String  = String ()
        val mutlaqsb: String  = String ()
        holder.mafoolbihi.setVisibility(View.GONE)
        //  holder.tameez.setVisibility(View.GONE);
        // holder.badal.setVisibility(View.GONE);
        // holder.liajlihi.setVisibility(View.GONE);
        holder.base_cardview.setVisibility(View.GONE)
        // mafoolate(holder, custom_font, entity, mafoolBihi, mf, halsb, tameezsb, badalsb, ajlihisb, mutlaqsb);
        setChapterInfo(holder, ayahWord)
        adapterposition = position
        wordBywordWithTranslation(
            normalfont,
            showrootkey,
            holder,
            custom_font,
            showWordColor,
            wbw,
            ayahWord,
            showWordByword,
            passageAyahworrd
        )
        if (showTransliteration) {
            if (entity != null) {
                holder.quran_transliteration.setText(
                    Html.fromHtml(
                        entity.getTranslation(),
                        Html.FROM_HTML_MODE_LEGACY
                    )
                )
            }
            holder.quran_transliteration.setTextSize(translationfontsize.toFloat())
            holder.quran_transliteration.setTextSize(translationfontsize.toFloat())
            holder.quran_transliteration.setVisibility(View.VISIBLE)
        }
        if (showJalalayn) {
            //   holder.quran_jalalaynnote.setText(enjalalayn.getAuthor_name());
            if (entity != null) {
                holder.quran_jalalayn.setText(entity.getEn_jalalayn())
            }
            holder.quran_jalalayn.setTextSize(translationfontsize.toFloat())
            holder.quran_jalalayn.setTextSize(translationfontsize.toFloat())
            holder.quran_jalalayn.setVisibility(View.VISIBLE)
            holder.quran_jalalaynnote.setVisibility(View.VISIBLE)
        }
        if (showTranslation) {
            if ((whichtranslation == "en_arberry")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getEn_arberry())
                }
                holder.translate_textViewnote.setText(string.arberry)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_sahih")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getTranslation())
                }
                holder.translate_textViewnote.setText(string.ensahih)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "en_jalalayn")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getEn_jalalayn())
                }
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_jalalayn")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getUr_jalalayn())
                }
                holder.translate_textViewnote.setText(string.enjalalayn)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            if ((whichtranslation == "ur_junagarhi")) {
                if (entity != null) {
                    holder.translate_textView.setText(entity.getUr_junagarhi())
                }
                holder.translate_textViewnote.setText(string.urjunagadi)
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setTextSize(translationfontsize.toFloat())
                holder.translate_textView.setVisibility(View.VISIBLE)
                holder.translate_textViewnote.setVisibility(View.VISIBLE)
            }
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setTextSize(translationfontsize.toFloat())
            holder.translate_textView.setVisibility(View.VISIBLE)
            holder.translate_textViewnote.setVisibility(View.VISIBLE)
        }
        if (showErab) {
            holder.erabexpand.setVisibility(View.VISIBLE)
            if (entity != null) {
                holder.erab_textView.setText(entity.getErabspnabble())
            }
            //   holder.erab_textView.setText(entity.getAr_irab_two());
            //     holder.erab_textView.setText(erabentity.getErabspnabble());
            holder.erab_textView.setTextSize(translationfontsize.toFloat())
            holder.erab_textView.setTypeface(custom_font)
            //     holder.erab_textView.setVisibility(View.VISIBLE);
            holder.erab_textViewnote.setVisibility(View.VISIBLE)


            /*
if (SharedPref.themePreferences().equals("dark")) {
  holder.erab_textView.setTextColor(QuranGrammarApplication.getContext().getResources().getColor(R.color.white));

} else {
  holder.erab_textView.setTextColor(QuranGrammarApplication.getContext().getResources().getColor(R.color.burntamber));

}
*/
        } else {
            holder.erabexpand.setVisibility(View.GONE)
        }
    }

    private fun mafoolate(
        holder: FlowAyahWordAdapterPassage.ItemViewAdapter,
        custom_font: Typeface,
        entity: QuranEntity?,
        mafoolBihi: MafoolBihi?,
        mf: SpannableString ,
        halsb: String ,
        tameezsb: String ,
        badalsb: String ,
        ajlihisb: String ,
        mutlaqsb: String 
    ) {
        val spanhash: Map<String, ForegroundColorSpan> =
            CorpusUtilityorig.getStringForegroundColorSpanMap()
        var mfcharSequence: CharSequence? = ""
        if (mafoolBihi != null && mafoolBihi.getAyah() == entity!!.getAyah()) {
            setUpMafoolbihistring(mf)
        }
        for (ent: MafoolBihi in mafoolBihis) {
            assert(entity != null)
            if (ent.getAyah() == entity!!.getAyah()) {
                val b: Boolean = ent.getObjectpronoun() == null
                if (!b) {
                    val mafoolbihiverb: SpannableString  = SpannableString ()
                    var objectpronoun: SpannableString  = SpannableString ()
                    mafoolbihiverb.append(ent.getWord()).append(" ")
                    objectpronoun = SpannableString .valueOf(ent.getObjectpronoun())
                    //   objectpronoun.append("(").append("مفعول به").append(")");
                    val colorSpan: ForegroundColorSpan? = spanhash.get("V")
                    val proncolospan: ForegroundColorSpan? = spanhash.get("PRON")
                    mafoolbihiverb.setSpan(
                        ForegroundColorSpan(colorSpan!!.getForegroundColor()),
                        0,
                        mafoolbihiverb.length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    objectpronoun.setSpan(
                        ForegroundColorSpan(proncolospan!!.getForegroundColor()),
                        0,
                        objectpronoun.length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    mfcharSequence = TextUtils.concat(mafoolbihiverb, " ", objectpronoun)
                    mf.append(mfcharSequence).append("\n")
                } else {
                    val mafoolbihiverb: SpannableString  = SpannableString ()
                    val objectpronoun: SpannableString  = SpannableString ()
                    mafoolbihiverb.append(ent.getWord()).append(" ")
                    //      mafoolbihiverb.append("(").append("مفعول به").append(")");
                    mafoolbihiverb.setSpan(
                        spanhash.get("N"),
                        0,
                        mafoolbihiverb.length,
                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                    )
                    mfcharSequence = TextUtils.concat(mafoolbihiverb)
                    mf.append(mfcharSequence).append("\n")
                }
                //    mf.append(ent.getWord().trim()).append("\n");
            }
        }
        //   if(!jumlahaliya.isEmpty()) {
        for (ent: HalEnt in jumlahaliya) {
            if (entity != null && ent.getAyah() == entity.getAyah()) {
                halsb.append(ent.getText().trim({ it <= ' ' })).append("\n")
            }
        }
        for (ent: TameezEnt in tameezEnts) {
            if (entity != null && ent.getAyah() == entity.getAyah()) {
                tameezsb.append(ent.getWord().trim({ it <= ' ' })).append("\n")
            }
        }
        for (ent: LiajlihiEnt in liajlihient) {
            if (entity != null && ent.getAyah() == entity.getAyah()) {
                ajlihisb.append(ent.getWord().trim({ it <= ' ' })).append("\n")
            }
        }
        for (ent: BadalErabNotesEnt in badalErabNotesEnt) {
            if (entity != null && ent.getAyah() == entity.getAyah()) {
                badalsb.append(ent.getText().trim({ it <= ' ' })).append("\n")
            }
        }
        for (ent: MafoolMutlaqEnt in mutlaqent) {
            if (entity != null && ent.getAyah() == entity.getAyah()) {
                mutlaqsb.append(ent.getWord().trim({ it <= ' ' })).append("\n")
            }
        }
        var halspan: SpannableString  = SpannableString ()
        var tameezspan: SpannableString  = SpannableString ()
        var badalspan: SpannableString  = SpannableString ()
        var mutlaqspan: SpannableString  = SpannableString ()
        var ajlihispan: SpannableString  = SpannableString ()
        if (!halsb.toString().isEmpty()) {
            halsb.insert(0, Constant.HALHEADER)
            halspan = SpannableString .valueOf(SpannableString.valueOf(halsb.toString()))
            val indexOfbihi1: Int = halspan.toString().indexOf(Constant.HAL)
            halspan.setSpan(
                ForegroundColorSpan(headercolor),
                indexOfbihi1,
                Constant.HAL.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            halspan.setSpan(
                RelativeSizeSpan(1f),
                indexOfbihi1,
                Constant.HAL.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            halspan.setSpan(
                Typeface.DEFAULT_BOLD,
                indexOfbihi1,
                Constant.HAL.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (!tameezsb.toString().isEmpty()) {
            tameezsb.insert(0, Constant.TAMEEZHEADER)
            tameezspan =
                SpannableString .valueOf(SpannableString.valueOf(tameezsb.toString()))
            val indexOfbihi2: Int = tameezspan.toString().indexOf(Constant.TAMEEZ)
            tameezspan.setSpan(
                ForegroundColorSpan(headercolor),
                indexOfbihi2,
                Constant.TAMEEZ.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tameezspan.setSpan(
                RelativeSizeSpan(1f),
                indexOfbihi2,
                Constant.TAMEEZ.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            tameezspan.setSpan(
                Typeface.DEFAULT_BOLD,
                indexOfbihi2,
                Constant.TAMEEZ.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (!ajlihisb.toString().isEmpty()) {
            ajlihisb.insert(0, Constant.AJLIHIHEADER)
            ajlihispan =
                SpannableString .valueOf(SpannableString.valueOf(ajlihisb.toString()))
            val indexOfbihi3: Int = ajlihispan.toString().indexOf(Constant.AJLIHI)
            ajlihispan.setSpan(
                ForegroundColorSpan(headercolor),
                indexOfbihi3,
                Constant.AJLIHI.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            ajlihispan.setSpan(
                RelativeSizeSpan(1f),
                indexOfbihi3,
                Constant.AJLIHI.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            ajlihispan.setSpan(
                Typeface.DEFAULT_BOLD,
                indexOfbihi3,
                Constant.AJLIHI.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (!badalsb.toString().isEmpty()) {
            badalsb.insert(0, Constant.BADALHEADER)
            //  if(finalstring!=null) {
            //  }
            badalspan = SpannableString .valueOf(SpannableString.valueOf(badalsb.toString()))
            val indexOfbihi4: Int = badalspan.toString().indexOf(Constant.BADAL)
            badalspan.setSpan(
                ForegroundColorSpan(headercolor),
                indexOfbihi4,
                Constant.BADAL.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            badalspan.setSpan(
                RelativeSizeSpan(1f),
                indexOfbihi4,
                Constant.BADAL.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            badalspan.setSpan(
                Typeface.DEFAULT_BOLD,
                indexOfbihi4,
                Constant.BADAL.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        if (!mutlaqsb.toString().isEmpty()) {
            mutlaqsb.insert(0, Constant.MUTLAQHEADER)
            mutlaqspan =
                SpannableString .valueOf(SpannableString.valueOf(mutlaqsb.toString()))
            val indexOfbihi5: Int = mutlaqspan.toString().indexOf(Constant.MUTLAQ)
            mutlaqspan.setSpan(
                ForegroundColorSpan(headercolor),
                indexOfbihi5,
                Constant.MUTLAQ.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            mutlaqspan.setSpan(
                RelativeSizeSpan(1f),
                indexOfbihi5,
                Constant.MUTLAQ.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            mutlaqspan.setSpan(
                Typeface.DEFAULT_BOLD,
                indexOfbihi5,
                Constant.MUTLAQ.length,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        val charSequence: CharSequence = TextUtils.concat(
            mf, " ", halspan, " ", tameezspan, " ", ajlihispan, " ", badalspan, " ", mutlaqspan
        )
        if (charSequence.toString().length > 15) {
            holder.mafoolbihi.setText(charSequence)
            holder.mafoolbihi.setGravity(Gravity.CENTER)
            holder.base_cardview.setVisibility(View.VISIBLE)
            holder.mafoolbihi.setTextSize((arabicfontSize - 5).toFloat())
            holder.mafoolbihi.setTypeface(custom_font)
        } else {
            holder.erabnotescardView.setVisibility(View.GONE)
            holder.mafoolbihi.setVisibility(View.GONE)
        }
    }

    private fun setUpMafoolbihistring(mf: SpannableString ) {
        val mfspan: SpannableString 
        mf.append(Constant.BIHIHEADER)
        mfspan = SpannableString .valueOf(SpannableString.valueOf(mf.toString()))
        val indexOfbihi: Int = mfspan.toString().indexOf(Constant.BIHI)
        mfspan.setSpan(
            ForegroundColorSpan(headercolor),
            indexOfbihi,
            Constant.BIHI.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        mfspan.setSpan(
            RelativeSizeSpan(1f),
            indexOfbihi,
            Constant.BIHI.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        mfspan.setSpan(
            Typeface.DEFAULT_BOLD,
            indexOfbihi,
            Constant.BIHI.length,
            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
        )
        mfspan.append("\n")
    }

    private fun wordBywordWithTranslation(
        normalfont: Typeface,
        showrootkey: Boolean,
        holder: FlowAyahWordAdapterPassage.ItemViewAdapter,
        custom_font: Typeface,
        showWordColor: Boolean,
        wbw: String?,
        ayahWord: CorpusAyahWord,
        showWbwTranslation: Boolean,
        passageAyahworrd: ArrayList<CorpusWbwWord>
    ) {
        val inflater: LayoutInflater =
            context.getSystemService(Context.LAYOUT_INFLATER_SERVICE) as LayoutInflater
        holder.flow_word_by_word.removeAllViews()
        ayahWord.getPassage_no()
        val size: Int = ayahWordArrayList.size
        val sizes: Int = ayahWord.getWord().size
        //  for (CorpusAyahWord corpusAyahWord : ayahWordArrayList) {
        passageLinkedMap.entries
        for (word: CorpusWbwWord in passageAyahworrd) {
            //  for (final CorpusWbwWord word : ayahWord.getWord()) {
            val view: View = inflater.inflate(R.layout.word_by_word, null)
            //      arabic.setOnLongClickListener((OnLongClickListener) this);
            //   final TextView arabic = view.findViewById(R.id.word_arabic_textView);
            arabic = view.findViewById(id.word_arabic_textView)
            rootword = view.findViewById(id.root_word)
            //   wordno = view.findViewById(R.id.wordno);
            val translation: TextView = view.findViewById(id.word_trans_textView)
            var spannedroot: SpannableString? = null
            val sb: String  = String ()
            sb.append(word.getWordno())
            //  wordno.setText(sb.toString());
            //   wordno.setTextSize(arabicfontSize);
            //   wordno.setVisibility(View.VISIBLE);
            if (showrootkey) {
                if (!word.getRootword().isEmpty()) {
                    spannedroot = getSpannedRoots(word)
                    rootword.setText(spannedroot)
                    rootword.setTextSize(arabicfontSize.toFloat())
                    rootword.setVisibility(View.VISIBLE)
                } else {
                    spannedroot = SpannableString.valueOf(word.getRootword())
                    rootword.setText(spannedroot)
                    rootword.setTextSize(arabicfontSize.toFloat())
                    rootword.setVisibility(View.VISIBLE)
                }
            }
            if (showWordColor) {
                var spannedword: SpannableString
                word.getRootword()
                if (word.getWordno() == 3) {
                    System.out.printf("chck")
                }
                spannedword = getSpannedWords(word)
                spannedword.setSpan(
                    custom_font,
                    0,
                    spannedword.length,
                    Spannable.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                arabic.setTypeface(colorwordfont)
                //   spannedword= SpannableString.valueOf(spannedword.toString().replaceAll(" ", ""));
                arabic.setText(spannedword)
            } else {
                arabic.setText(word.getWordsAr())
                arabic.setTypeface(normalfont)
            }
            rootword.setText(spannedroot)
            rootword.setTextSize(arabicfontSize.toFloat())
            //   arabic.setTextSize(29);
            arabic.setTextSize(arabicfontSize.toFloat())
            if (showWbwTranslation) {
                when (wbw) {
                    "en" -> {
                        translation.setText(word.getTranslateEn())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }

                    "bn" -> {
                        translation.setText(word.getTranslateBn())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }

                    "in" -> {
                        translation.setText(word.getTranslateIndo())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }

                    "ur" -> {
                        translation.setText(word.getTranslationUrdu())
                        translation.setPaintFlags(translation.getPaintFlags() or Paint.UNDERLINE_TEXT_FLAG)
                    }
                }
                //  translation.setTextColor(context.getResources().getColor(R.color.neutral2));
            }
            //    translation.setTextSize(forntSize + 4);
            translation.setTextSize(arabicfontSize.toFloat())
            holder.flow_word_by_word.addView(view)
            view.setLongClickable(true)
            val textView: TextView = holder.flow_word_by_word.findViewById(id.word_arabic_textView)
            view.setOnLongClickListener(object : View.OnLongClickListener {
                public override fun onLongClick(v: View?): Boolean {
                    val utils: Utils = Utils(QuranGrammarApplication.getContext())
                    //
                    //  HashMap<String, String> vbdetail;
                    //     ArrayList<NewCorpusExpandWbwPOJO> corpusSurahWords = utils.getCorpusWbwBySurahAyahWordid(word.getSurahId(), word.getVerseId(), word.getWordno());
                    //     ArrayList<NounCorpus> corpusNounWords = utils.getQuranNouns(word.getSurahId(), word.getVerseId(), word.getWordno());
                    val verbCorpusRootWords: ArrayList<VerbCorpus> =
                        utils.getQuranRoot(word.getSurahId(), word.getVerseId(), word.getWordno())
                    //  QuranMorphologyDetails ams = new QuranMorphologyDetails(corpusSurahWords, corpusNounWords, verbCorpusRootWords, getContext());
                    //     HashMap<String, SpannableString > wordbdetail = ams.getWordDetails();
                    if (verbCorpusRootWords.size > 0 && (verbCorpusRootWords.get(0)
                            .getTag() == "V")
                    ) {
                        //    vbdetail = ams.getVerbDetails();
                        print("check")
                    }
                    //
                    //       WordAnalysisBottomSheet wb = new WordAnalysisBottomSheet();
                    //  ArrayList<NewCorpusExpandWbwPOJO> corpusSurahWord = utils.getCorpusWbwBySurahAyahWordid(word.getSurahId(), word.getVerseId(), word.getWordno());
                    val corpusNounWord: ArrayList<NounCorpus> =
                        utils.getQuranNouns(word.getSurahId(), word.getVerseId(), word.getWordno())
                    val verbCorpusRootWord: ArrayList<VerbCorpus> =
                        utils.getQuranRoot(word.getSurahId(), word.getVerseId(), word.getWordno())
                    //   QuranMorphologyDetails am = new QuranMorphologyDetails(corpusSurahWord, corpusNounWord, verbCorpusRootWord, getContext());
                    //   ArrayList<NounCorpus> corpusNounWord = utils.getQuranNouns(chapterid, ayanumber, wordno);
                    //  ArrayList<VerbCorpus> verbCorpusRootWord = utils.getQuranRoot(chapterid, ayanumber, wordno);
                    //      QuranMorphologyDetails am = new QuranMorphologyDetails(corpusSurahWord, corpusNounWord, verbCorpusRootWord, getContext());
                    val qm: WordMorphologyDetails =
                        WordMorphologyDetails(word, corpusNounWord, verbCorpusRootWord)
                    //   String ws= String.valueOf(qm.getWorkBreakDown());
                    //    HashMap<String, SpannableString > wordDetails = am.getWordDetails();
                    val workBreakDown: SpannableString = qm.getWorkBreakDown()
                    /*

        Utils utils=new Utils(getContext());
          ArrayList<NewCorpusExpandWbwPOJO> corpusSurahWord = utils.getCorpusWbwBySurahAyahWordid(word.getSurahId(), word.getVerseId(), word.getWordno());
            ArrayList<NounCorpus> corpusNounWord = utils.getQuranNouns(word.getSurahId(), word.getVerseId(), word.getWordno());
            ArrayList<VerbCorpus> verbCorpusRootWord = utils.getQuranRoot(word.getSurahId(), word.getVerseId(), word.getWordno());
            QuranMorphologyDetails am = new QuranMorphologyDetails(corpusSurahWord, corpusNounWord, verbCorpusRootWord, getContext());
          VerbWazan vb = new VerbWazan();
          HashMap<String, String> vbdetail=null;
          HashMap<String, SpannableString > wordbdetail = am.getWordDetails();
          SpannableString  s=    wordbdetail.get("noun");

       */
                    var color: Int =
                        context.getResources().getColor(color.background_color_light_brown)
                    when (isNightmode) {
                        "dark", "blue" -> color =
                            context.getResources().getColor(R.color.background_color)

                        "brown" -> color = context.getResources().getColor(R.color.neutral0)
                        "white" -> color =
                            context.getResources().getColor(R.color.background_color_light_brown)
                    }
                    val  : Tooltip.  = Tooltip. ((v)!!, style.ayah_translation)
                        .setCancelable(true)
                        .setDismissOnClick(false)
                        .setCornerRadius(20f)
                        .setGravity(Gravity.TOP)
                        .setArrowEnabled(true)
                        .setBackgroundColor(color)
                        .setText(workBreakDown)
                     .show()
                    return true
                }
            })
            view.setOnClickListener(object : View.OnClickListener {
                public override fun onClick(view: View?) {
                    val dialog: Dialog = Dialog(context)
                    //      dialog.setContentView(R.layout.corpus_layout);
                    //    dialog.setTitle(fixArabic(word.getWordsAr()));
                    dialog.setTitle(word.getWordsAr())
                    val dataBundle: Bundle = Bundle()
                    dataBundle.putInt(Constant.SURAH_ID, word.getSurahId())
                    dataBundle.putInt(
                        Constant.AYAHNUMBER,
                        Math.toIntExact(word.getVerseId().toLong())
                    )
                    dataBundle.putInt(
                        Constant.WORDNUMBER,
                        Math.toIntExact(word.getWordno().toLong())
                    )
                    dataBundle.putString(Constant.SURAH_ARABIC_NAME, SurahName)
                    LoadItemList(dataBundle)
                }

                private fun LoadItemList(dataBundle: Bundle) {
                    if (issentence) {
                        val item: SentenceAnalysisBottomSheet = SentenceAnalysisBottomSheet()
                        //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                        //      FragmentManager fragmentManager = ((AppCompatActivity) context).getSupportFragmentManager();
                        item.setArguments(dataBundle)
                        val data: Array<String> = arrayOf(
                            word.getSurahId().toString(),
                            word.getVerseId().toString(),
                            word.getTranslateEn(),
                            (word.getWordno()).toString()
                        )
                        //     FragmentTransaction transactions = fragmentManager.beginTransaction().setCustomAnimations(R.anim.abc_slide_in_top, android.R.anim.fade_out);
                        //   transactions.show(item);
                        SentenceAnalysisBottomSheet.Companion.newInstance(data).show(
                            (context as AppCompatActivity).getSupportFragmentManager(),
                            SentenceAnalysisBottomSheet.Companion.TAG
                        )
                    } else {
                        if (!word.getAraone().contains("﴿")) {
                            val item: WordAnalysisBottomSheet = WordAnalysisBottomSheet()

                            //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                            //    FragmentManager fragmentManager = ((AppCompatActivity) context).getSupportFragmentManager();
                            item.setArguments(dataBundle)
                            val data: Array<String> = arrayOf(
                                word.getSurahId().toString(),
                                word.getVerseId().toString(),
                                word.getTranslateEn(),
                                (word.getWordno()).toString(),
                                SurahName
                            )
                            //  FragmentTransaction transactions = fragmentManager.beginTransaction().setCustomAnimations(R.anim.abc_slide_in_top, android.R.anim.fade_out);
                            //   transactions.show(item);
                            WordAnalysisBottomSheet.Companion.newInstance(data).show(
                                (context as AppCompatActivity).getSupportFragmentManager(),
                                WordAnalysisBottomSheet.Companion.TAG
                            )
                        }
                    }
                }
            })
        }
        holder.flow_word_by_word.setVisibility(View.VISIBLE)
    }

    private fun getSpannedRoots(corpus: CorpusWbwWord): SpannableString {
        val b: Boolean =
            corpus.getVerseId() == 20 && (corpus.getWordno() == 2 || corpus.getWordno() == 9)
        if (b) {
            println("check")
        }
        return CorpusUtilityorig.ColorizeRootword(
            corpus.getTagone(),
            corpus.getTagtwo(),
            corpus.getTagthree(),
            corpus.getTagfour(),
            corpus.getTagfive(),
            corpus.getRootword()
        )
    }

    private fun getSpannedWords(corpus: CorpusWbwWord): SpannableString {
        val b: Boolean =
            corpus.getVerseId() == 20 && (corpus.getWordno() == 2 || corpus.getWordno() == 9)
        if (b) {
            println("check")
        }
        return CorpusUtilityorig.NewSetWordSpan(
            corpus.getTagone(),
            corpus.getTagtwo(),
            corpus.getTagthree(),
            corpus.getTagfour(),
            corpus.getTagfive(),
            corpus.getAraone(),
            corpus.getAratwo(),
            corpus.getArathree(),
            corpus.getArafour(),
            corpus.getArafive()
        )
    }

    private fun storepreferences(entity: QuranEntity) {
        val pref: SharedPreferences = context.getSharedPreferences("lastread", Context.MODE_PRIVATE)
        val editor: SharedPreferences.Editor = pref.edit()
        editor.putInt(Constant.CHAPTER, entity.getSurah())
        editor.putInt(Constant.AYAH_ID, entity.getAyah())
        editor.putString(Constant.SURAH_ARABIC_NAME, SurahName)
        editor.apply()
        editor.commit()
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    private fun setChapterInfo(
        holder: FlowAyahWordAdapterPassage.ItemViewAdapter,
        verse: CorpusAyahWord
    ) {
        val surahInfo: String  = String ()
        //        surahInfo.append(surahName+".");
        surahInfo.append(verse.getWord().get(0).getSurahId()).append(".")
        surahInfo.append(verse.getWord().get(0).getVerseId()).append("-")
        surahInfo.append(SurahName)
        val sharedPreferences: SharedPreferences =
            androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                context
            )
        val isNightmode: String? = sharedPreferences.getString("themepref", "dark")
        if (isMakkiMadani == 1) {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                drawable.ic_makkah_48,
                0,
                0,
                0
            )
            if ((isNightmode == "dark") || (isNightmode == "blue")) {
//TextViewCompat.setCompoundDrawableTintList()
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.WHITE))
            } else {
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.BLACK))
            }
        } else {
            holder.surah_info.setCompoundDrawablesWithIntrinsicBounds(
                drawable.ic_madinah_48,
                0,
                0,
                0
            )
            if ((isNightmode == "dark") || (isNightmode == "blue")) {
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.WHITE))
            } else {
                holder.surah_info.setCompoundDrawableTintList(ColorStateList.valueOf(Color.BLACK))
            }
        }
        holder.surah_info.setText(surahInfo)
        holder.surah_info.setTextSize(arabicfontSize.toFloat())
        //  holder.surah_info.setTextColor(context.getResources().getColor(R.color.colorOnPrimary));
    }

    public override fun onItemClick(v: View, position: Int) {}
    public override fun onItemLongClick(position: Int, v: View) {}
    inner class ItemViewAdapter internal constructor(view: View, viewType: Int) :
        RecyclerView.ViewHolder(view), View.OnClickListener, View.OnLongClickListener {
        var quran_jalalayn: TextView? = null
        var kathir_translation: TextView? = null
        var quran_transliteration: TextView? = null
        var translate_textView: TextView? = null

        //   public TextView erab_textView;
        var erab_textView: TextView? = null
        var surah_info: TextView? = null
        var mafoolbihi: TextView? = null
        var bismilla: TextView? = null
        var quran_textView: TextView? = null
        var erab_notes: TextView? = null
        var quran_transliterationnote: TextView? = null
        var quran_jalalaynnote: TextView? = null
        var erab_textViewnote: TextView? = null
        var translate_textViewnote: TextView? = null
        var bookmark: ImageView? = null
        var jumpto: ImageView? = null
        var makkimadaniicon: ImageView? = null
        var expandImageButton: ImageView? = null
        var ivBismillah: ImageView? = null
        var erabexpand: ImageView? = null
        var erab_notes_expand: ImageView? = null
        var tvSura: TextView? = null
        var tvRukus: TextView? = null
        var tvVerses: TextView? = null
        var ivSurahIcon: ImageView? = null
        var ivLocationmakki: ImageView? = null
        var ivLocationmadani: ImageView? = null
        var ivhelp: ImageView? = null
        var ivoverflow: ImageView? = null
        var arrowforward: ImageView? = null
        var arrowback: ImageView? = null
        var ivSummary: ImageView? = null
        var colorize: SwitchCompat? = null

        //  public   com.nex3z.flowlayout.FlowLayout  flow_word_by_word;
        var flow_word_by_word: FlowLayout? = null

        //    com.google.android.flexbox.FlexboxLayout flow_word_by_word;
        //   RelativeLayout colllayout;
        var erabnotescardView: CardView? = null
        var kahteercardview: CardView? = null
        var mafoolatarow: ImageView? = null
        var hiddenGroup: Group? = null
        var card_group: Group? = null
        var base_cardview: MaterialCardView? = null

        //  public MaterialCardView cardview;
        //public FlowLayout cardview;
        init {
            view.setTag(this)
            itemView.setOnClickListener(this)
            if (viewType == 0) {
                ivLocationmakki = view.findViewById(id.ivLocationmakki)
                ivLocationmadani = view.findViewById(id.ivLocationmadani)
                ivSurahIcon = view.findViewById(id.ivSurahIcon)
                tvVerses = view.findViewById<View>(id.tvVerses) as TextView?
                tvRukus = view.findViewById<View>(id.tvRukus) as TextView?
                tvSura = view.findViewById<View>(id.tvSura) as TextView?
                ivBismillah = view.findViewById(id.ivBismillah)
            } else {
                //     kathir_note = view.findViewById(R.id.kathir_note);
                kathir_translation = view.findViewById(id.katheer_textview)
                arrowforward = view.findViewById(id.arrowforward)
                arrowback = view.findViewById(id.arrowback)
                colorize = view.findViewById(id.colorized)
                bookmark = view.findViewById(id.bookmark)
                jumpto = view.findViewById(id.jumpto)
                ivhelp = view.findViewById(id.ivHelp)
                ivoverflow = view.findViewById(id.ivActionOverflow)
                ivhelp.setOnClickListener(this)
                ivoverflow.setOnClickListener(this)
                //     colllayout=view.findViewById(R.id.erablayout);
                jumpto.setOnClickListener(this)
                //     kathir_note = view.findViewById(R.id.kathir_note);
                kathir_translation = view.findViewById(id.katheer_textview)
                //    arrowforward = view.findViewById(R.id.arrowforward);
                //   arrowback = view.findViewById(R.id.arrowback);
                //   colorize = view.findViewById(R.id.colorized);
                //   bookmark = view.findViewById(R.id.bookmark);
                ivSummary = view.findViewById(id.ivSumarry)
                ivSummary.setTag("summary")
                ivSummary.setOnClickListener(this)
                jumpto = view.findViewById(id.jumpto)
                ivhelp = view.findViewById(id.ivHelp)
                ivoverflow = view.findViewById(id.ivActionOverflow)
                ivhelp.setOnClickListener(this)
                ivoverflow.setOnClickListener(this)
                //     colllayout=view.findViewById(R.id.erablayout);
                //   jumpto.setOnClickListener(this);
                //   bookmark.setOnClickListener(this);
                //   ivhelp.setTag("help_img");
                ivoverflow.setTag("overflow_img")
                //      bookmark.setTag("bookmark");
                //    colorize.setChecked(true);
                //   colorize.setOnClickListener(this);
                //   colorize.setTag("colorize");
                //  jumpto.setTag("jumpto");
                //  arrowforward.setOnClickListener(this);
                //  arrowback.setOnClickListener(this);
                //  arrowback.setTag("arrowback");
                //   arrowforward.setTag("arrowforward");
                makkimadaniicon = view.findViewById(id.makkimadaniicon)
                //    jumpto = view.findViewById(R.id.jumpto);
                bismilla = view.findViewById(id.bismillah)
                quran_transliterationnote = view.findViewById(id.quran_transliterationnote)
                quran_jalalaynnote = view.findViewById(id.quran_jalalaynnote)
                translate_textViewnote = view.findViewById(id.translate_textViewnote)
                erab_textViewnote = view.findViewById(id.erab_textViewnote)
                quran_transliteration = view.findViewById(id.quran_transliteration)
                quran_jalalayn = view.findViewById(id.quran_jalalayn)
                surah_info = view.findViewById(id.chaptername)
                //    verse_idTextView = view.findViewById(R.id.verse_id_textView);
                flow_word_by_word = view.findViewById(id.flow_word_by_word)
                translate_textView = view.findViewById(id.translate_textView)
                erab_textView = view.findViewById(id.erab_textView)
                //     erab_textView.setTextIsSelectable(true);
                quran_textView = view.findViewById(id.quran_textView)
                erab_notes = view.findViewById(id.erab_notes)
                //     bookmark = view.findViewById(R.id.bookmarkView);
                erabexpand = view.findViewById(id.erabexpand)
                erab_notes_expand = view.findViewById(id.erab_img)
                expandImageButton = view.findViewById(id.expandImageButton)
                quran_textView.setOnClickListener(this)
                quran_textView.setTag("qurantext")
                erab_notes_expand.setOnClickListener(this)
                erab_notes_expand.setTag("erab_notes")
                erabnotescardView = view.findViewById(id.base_cardview)
                mafoolatarow = view.findViewById(id.show)
                hiddenGroup = view.findViewById(id.card_group)
                mafoolatarow.setOnClickListener(this)
                mafoolbihi = view.findViewById(id.directobject)
                //    hal=view.findViewById(R.id.hal);
                //     badal=view.findViewById(R.id.badal);
                //   tameez=view.findViewById(R.id.tameez);
                // liajlihi=view.findViewById(R.id.ajlihi);
                base_cardview = view.findViewById(id.base_cardview)
                //    bookmark.setOnClickListener(this);
                //   jumpto.setOnClickListener(this);
                view.setOnClickListener(this)
                view.setOnLongClickListener(this)
                val shared: SharedPreferences =
                    androidx.preference.PreferenceManager.getDefaultSharedPreferences(
                        QuranGrammarApplication.getContext()
                    )
                val colortag: Boolean = shared.getBoolean("colortag", true)
                // Gets the layout params that will allow you to resize the layout
                //  ConstraintLayout.LayoutParams params = (ConstraintLayout.LayoutParams) colllayout.getLayoutParams();
// Changes the height and width to the specified *pixels*
                //   params.height = 100;
                //    params.width = 600;
                //   colllayout.setLayoutParams(params);
                mafoolatarow.setOnClickListener(View.OnClickListener({ view1: View? ->
                    TransitionManager.beginDelayedTransition(erabnotescardView, AutoTransition())
                    if (hiddenGroup.getVisibility() == View.VISIBLE) {
                        hiddenGroup.setVisibility(View.GONE)
                        //   params.width = 100;
                        //   colllayout.setLayoutParams(params);
                        mafoolatarow.setImageResource(android.R.drawable.arrow_down_float)
                    } else {
                        //     colllayout.setLayoutParams(params);
                        hiddenGroup.setVisibility(View.VISIBLE)
                        mafoolatarow.setImageResource(android.R.drawable.arrow_up_float)
                    }
                }))
                erabexpand.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (erab_textView.getVisibility() == View.GONE) {
                        erab_textView.setVisibility(View.VISIBLE)
                        //  AnimationUtility.slide_down(context, erabexpand);
                        AnimationUtility.AnimateArrow(90.0f, erabexpand)
                    } else {
                        erab_textView.setVisibility(View.GONE)
                        AnimationUtility.AnimateArrow(0.0f, erabexpand)
                        //   Fader.slide_down(context,expandImageButton);
                    }
                }))
                flow_word_by_word.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (translate_textView.getVisibility() == View.GONE) translate_textView.setVisibility(
                        View.VISIBLE
                    ) else translate_textView.setVisibility(View.VISIBLE)
                }))
                translate_textView.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (translate_textView.getVisibility() == View.VISIBLE) translate_textView.setVisibility(
                        View.GONE
                    ) else translate_textView.setVisibility(View.VISIBLE)
                }))
                erab_textView.setOnClickListener(View.OnClickListener({ view1: View? ->
                    if (erab_textView.getVisibility() == View.VISIBLE) erab_textView.setVisibility(
                        View.GONE
                    ) else erab_textView.setVisibility(View.VISIBLE)
                }))
            }
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }

        public override fun onLongClick(v: View): Boolean {
            mItemClickListener!!.onItemLongClick(getAdapterPosition(), v)
            return true
        }
    } //View.OnClickListener, View.OnLongClickListener

    companion object {
        private val TYPE_HEADER: Int = 0
        private val TYPE_ITEM: Int = 1
    }
}