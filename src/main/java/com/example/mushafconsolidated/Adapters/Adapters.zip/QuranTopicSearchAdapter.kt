package com.example.mushafconsolidated.Adapters

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.CompoundButton
import android.widget.Filterable
import android.widget.ImageView
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.intrfaceimport.OnItemClickListener
import qurandictionary
import quranexplorer


class QuranTopicSearchAdapter : RecyclerView.Adapter<QuranTopicSearchAdapter.MyViewHolder>,
    Filterable {
    var mItemClickListener: OnItemClickListener? = null
    private var qurandictionaryArrayList: ArrayList<quranexplorer>? = null
    private val olistener: View.OnClickListener? = null
    private val context: Context
    var list: List<quranexplorer>? = null
        private set
    private var listener: ContactsAdapterListener? = null
    private val downloadtype: Boolean = false
    private lateinit var mcheckedStatus: BooleanArray

    constructor(context: Context, listener: ContactsAdapterListener?) {
        this.context = context
        this.listener = listener
    }

    constructor(context: Context, qurandictionaryArrayList: ArrayList<quranexplorer>?, b: Boolean) {
        this.context = context
        this.qurandictionaryArrayList = qurandictionaryArrayList
        list = qurandictionaryArrayList
        mcheckedStatus = BooleanArray(list!!.size)
    }

    fun getItem(position: Int): Any {
        return list!!.get(position)
    }

    fun SetOnItemClickListener(mItemClickListener: OnItemClickListener?) {
        this.mItemClickListener = mItemClickListener
    }

    public override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): MyViewHolder {
        val itemView: View = LayoutInflater.from(parent.getContext())
            .inflate(R.layout.topic_row_item, parent, false)
        return MyViewHolder(itemView)
    }

    public override fun onBindViewHolder(
        holder: MyViewHolder,
        @SuppressLint("RecyclerView") position: Int
    ) {
        val entity: quranexplorer = list!!.get(position)
        val ayahref: String? = entity.ayahref
        if (ayahref != null) {
            val split: Array<String> =
                ayahref.split(",".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
            val length: Int = split.size
            holder.buckwaterroot.setText(Integer.toString(length))
        }
        /*
        holder.arabicroot.setText(entity.getTitle());
        holder.checkBox.setTag(qurandictionaryFiltered.get(position));
        holder.itemView.setSelected(entity.isSelected() ? true : false);
        holder.checkBox.setChecked(false);
 */
        val pos: Int = position
        holder.arabicroot.setText(list!!.get(position).title)
        holder.checkBox.setChecked(list!!.get(position).isSelected())
        holder.checkBox.setTag(list!!.get(position))
        holder.checkBox.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                val cb: CheckBox = v as CheckBox
                val contact: quranexplorer = cb.getTag() as quranexplorer
                contact.setSelected(cb.isChecked())
                list!!.get(pos).setSelected(cb.isChecked())
            }
        })
        holder.arabicroot.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(view: View) {
                entity.setSelected(!entity.isSelected())
                holder.checkBox.setOnCheckedChangeListener(object :
                    CompoundButton.OnCheckedChangeListener {
                    public override fun onCheckedChanged(
                        compoundButton: CompoundButton,
                        b: Boolean
                    ) {
                        holder.checkBox.setChecked(!holder.checkBox.isChecked())
                    }
                })
                //   holder.itemView.setBackgroundColor(entity.isSelected() ? Color.CYAN : Color.BLUE);
                //   holder.itemView.setSelected(entity.isSelected()) ? true.
            }
        })
        //  holder.englishname.setText(entity.getEnglish_name());
        //  holder.translationid.setText(entity.getTranslation_id());
    }

    /*
        @Override
        public int getItemCount() {
            return qurandictionaryFiltered.size();
        }

     */
    public override fun getItemCount(): Int {
        return if (list == null) 0 else list!!.size
    }

    public override fun getFilter(): Filter {
        return object : Filter() {
            override fun performFiltering(charSequence: CharSequence): FilterResults {
                val charString: String = charSequence.toString()
                if (charString.isEmpty()) {
                    list = qurandictionaryArrayList
                } else {
                    val filteredList: MutableList<quranexplorer> = ArrayList()
                    for (details: quranexplorer in qurandictionaryArrayList!!) {
                        // name match condition. this might differ depending on your requirement
                        // here we are looking for name or phone number match
                        if (details.getTitle().lowercase(Locale.getDefault()).contains(
                                charString.lowercase(
                                    Locale.getDefault()
                                )
                            )
                        ) {
                            filteredList.add(details)
                        }
                    }
                    list = filteredList
                }
                val filterResults: FilterResults = FilterResults()
                filterResults.values = list
                return filterResults
            }

            override fun publishResults(charSequence: CharSequence?, filterResults: FilterResults) {
                list = filterResults.values as ArrayList<quranexplorer>?
                notifyDataSetChanged()
            }
        }
    }

    open interface ContactsAdapterListener {
        fun onselected(translationEntity: qurandictionary?)
    }

    inner class MyViewHolder constructor(view: View) : RecyclerView.ViewHolder(view),
        View.OnClickListener {
        var arabicroot: TextView
        var buckwaterroot: TextView
        var translationid: TextView? = null
        var englishname: TextView? = null
        var downloadicon: ImageView? = null
        var deleteicon: ImageView? = null
        var checkBox: CheckBox

        init {
            arabicroot = view.findViewById(id.title)
            buckwaterroot = view.findViewById(id.count)
            checkBox = view.findViewById(id.selection)
            view.setOnClickListener(this)


            /*
               view.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View view) {
                    // send selected contact in callback
                    listener.onselected(translationEntitiesFiltered.get(getAdapterPosition()));
                }
            });
             */
        }

        public override fun onClick(v: View) {
            if (mItemClickListener != null) {
                mItemClickListener!!.onItemClick(v, getLayoutPosition())
            }
        }
    }
}