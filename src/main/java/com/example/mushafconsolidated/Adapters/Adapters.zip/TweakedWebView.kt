package com.example.mushafconsolidated.Adaptersimport

android.os.Buildimport android.util.AttributeSetimport android.view.MotionEventimport android.webkit.WebViewimport android.widget.ZoomButtonsControllerimport java.lang.reflect.Method

 

 

 






 

 

 

class TweakedWebView : WebView {
    private var zoomButtons: ZoomButtonsController? = null

    constructor(context: Context?) : super((context)!!) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?) : super((context)!!, attrs) {
        init()
    }

    constructor(context: Context?, attrs: AttributeSet?, defStyle: Int) : super(
        (context)!!, attrs, defStyle
    ) {
        init()
    }

    private fun init() {
        getSettings().setBuiltInZoomControls(true)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
            getSettings().setDisplayZoomControls(false)
        } else {
            try {
                val method: Method = javaClass
                    .getMethod("getZoomButtonsController")
                zoomButtons = method.invoke(this) as ZoomButtonsController?
            } catch (e: Exception) {
                // pass
            }
        }
    }

    public override fun onTouchEvent(ev: MotionEvent): Boolean {
        val result: Boolean = super.onTouchEvent(ev)
        if (zoomButtons != null) {
            zoomButtons!!.setVisible(false)
            zoomButtons!!.getZoomControls().setVisibility(GONE)
        }
        return result
    }
}