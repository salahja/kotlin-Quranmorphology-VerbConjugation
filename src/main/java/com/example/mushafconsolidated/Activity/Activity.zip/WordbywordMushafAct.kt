package com.example.mushafconsolidated.Activityimport

import com.example.mushafconsolidated.intrfaceimport.OnItemClickListenerOnLong


class WordbywordMushafAct constructor() : BaseActivity(), OnItemClickListenerOnLong,
    View.OnClickListener, FullscreenButtonClickListener {
    // private UpdateMafoolFlowAyahWordAdapter flowAyahWordAdapter;
    private val mausoof: Boolean = false
    private val mudhaf: Boolean = false
    private val harfnasb: Boolean = false
    private val shart: Boolean = false
    private val soraList: ArrayList<ChaptersAnaEntity>? = null
    private val ayahIndex: EditText? = null
    private val kana: Boolean = false
    private var allofQuran: List<QuranEntity>? = null
    private val shared: SharedPreferences? = null

    //  private OnClickListener onClickListener;
    private var corpusayahWordArrayList: ArrayList<CorpusAyahWord>? = null
    private var mafoolbihiwords: ArrayList<MafoolBihi>? = null
    private var Jumlahaliya: ArrayList<HalEnt>? = null
    private var Tammezent: ArrayList<TameezEnt>? = null
    private var Mutlaqent: ArrayList<MafoolMutlaqEnt>? = null
    private var Liajlihient: ArrayList<LiajlihiEnt>? = null
    private var BadalErabNotesEnt: ArrayList<BadalErabNotesEnt>? = null
    private var utils: Utils? = null
    private val isMakkiMadani: Int = 0
    private val chapterno: Int = 0
    private val parentRecyclerView: RecyclerView? = null
    private val surahRecView: RecyclerView? = null
    var exo_settings: ImageButton? = null
    var exo_close: ImageButton? = null
    var exo_bottom_bar: ImageButton? = null
    private var surahWheelDisplayData: Array<String>
    private var ayahWheelDisplayData: Array<String>
    var versestartrange: Int = 0
    var verseendrange: Int = 0
    private var currenttrack: Int = 0
    private var resumelastplayed: Int = 0
    private var onClickOrRange: Boolean = false
    var llStartRange: LinearLayout? = null
    var llEndRange: LinearLayout? = null

    //  private LinkedHashMap<Integer, Integer> hlights;
    private val Coordinates: ArrayList<AyahCoordinate> = ArrayList()
    private val hlights: LinkedHashMap<Int, ArrayList<AyahCoordinate>> = LinkedHashMap()
    var flow: Boolean = false
    var singleline: Boolean = false
    var rangeRecitation: Boolean = false
    private var fullQuranPages: ArrayList<Page>? = null
    private var resumetrackposition: Long = 0
    private var resume: Boolean = false
    var ayah: Int = 0
    var passageadapter: PageMushaAudioAdapter? = null
    private val passage: LinkedHashMap<Int, String> = LinkedHashMap()
    private val pages: LinkedHashMap<Int, String> = LinkedHashMap()
    var audioType: Int = 0
    var prevqari: String = ""
    private val handler: Handler = Handler()
    private var marray: MutableList<MediaItem>? = null
    private var marrayrange: List<MediaItem>? = ArrayList()
    private val singleverse: String? = null
    private var isSingle: Boolean = false
    private var isStartFrom: Boolean = false
    private var quranbySurahadapter: List<QuranEntity>? = null
    private val resetplayer: MaterialButton? = null
    private var sharedPreferences: SharedPreferences? = null
    private var selectedqari: String? = null
    var qariname: MaterialTextView? = null
    var ayaprogress: MaterialTextView? = null
    var buffering: ImageView? = null
    var canceldownload: MaterialButton? = null
    fun setPrevqari(prevqari: String) {
        this.prevqari = prevqari
    }

    //  FrameLayout eqContainer;
    fun setAudioType(audioType: Int) {
        this.audioType = audioType
    }

    // protected StyledPlayerView playerView;
    //    protected StyledPlayerControlView playerView;
    protected var playerView: PlayerControlView? = null
    protected var player: ExoPlayer? = null
    private var trackSelectionParameters: TrackSelectionParameters? = null
    private var lastSeenTracks: Tracks? = null
    private var startAutoPlay: Boolean = false
    private var startItemIndex: Int = 0
    private var startPosition: Long = 0
    private val ruku: LinkedHashMap<Int, ArrayList<CorpusWbwWord>> = LinkedHashMap()
    private var pausePlayFlag: Boolean = false
    var surahselected: Int = 0
    var verselected: Int = 0
    var versescount: Int = 0
    var surahNameEnglish: String? = null
    var surahNameArabic: String? = null
    private var isNightmode: String? = null

    // LinearLayout fabLayout1, fabLayout2,fabLayout3;
    //  FloatingActionButton fab, fab1, fab2, fab3;
    var playfb: MovableFloatingActionButton? = null

    // Use the ExtendedFloatingActionButton to handle the
    // These TextViews are taken to make visible and
    // invisible along with FABs except parent FAB's action
    // name
    var resetfbtxt: TextView? = null
    public override fun onBackPressed() {

        //unregister broadcast for download ayat
        LocalBroadcastManager.getInstance(this@WordbywordMushafAct)
            .unregisterReceiver(downloadPageAya)
        //stop flag of auto start
        WordbywordMushafAct.Companion.startBeforeDownload = false
        if (player != null) {
            player!!.release()
        }
        val pref: SharedPreferences = getSharedPreferences("lastaya", MODE_PRIVATE)
        val editor: SharedPreferences.Editor = pref.edit()
        //    editor.putInt("lastaya", currenttrack);
//        editor.putInt("trackposition", hlights.get(currenttrack).get(0).getPassage());
        editor.apply()
        super.onBackPressed()
    }

    var isMusicplaying: Boolean = false
    private var surah: Int = 0
    var recyclerView: RecyclerView? = null
    var repository: Utils? = null
    var lineMushaAudioAdapter: LineMushaAudioAdapter? = null
    var vtwoMushaAudioAdapter: vtwoMushaAudioAdapter? = null
    var typeface: Typeface? = null
    var txtView: TextView? = null
    private val translationBooks: Spinner? = null
    private var readers: Spinner? = null
    private var downloadFooter: RelativeLayout? = null
    private val normalFooter: LinearLayout? = null
    private var playerFooter: RelativeLayout? = null
    private var audio_settings_bottom: RelativeLayout? = null

    //  TextView startrange, startimage, endrange, endimage;
    var startrange: MaterialTextView? = null
    var endrange: MaterialTextView? = null
    fun setStartPosition(startPosition: Long) {
        this.startPosition = startPosition
    }

    //  private List<TranslationBook> booksInfo;
    private var readersList: List<Qari>? = null
    private var mediaPlayerDownloadProgress: ProgressBar? = null
    private var exoplayerBottomBehaviour: BottomSheetBehavior<*>? = null
    private var audioSettingBottomBehaviour: BottomSheetBehavior<*>? = null
    var resetfab: FloatingActionButton? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.vfour_expandable_newactivity_show_ayahs)
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        //    ButterKnife.bind(this);
        //    QuranGrammarApplication.appContext = ShowMushafActivity.this;
        //  intentmyservice = new Intent(this, AudioService.class);
        val intent: Intent = Intent(WordbywordMushafAct.Companion.BROADCAST_SEEKBAR)
        getpreferences()
        lastPlayed
        sharedPreferences = PreferenceManager.getDefaultSharedPreferences(this)
        isNightmode = sharedPreferences.getString("themepref", "dark")
        //  repository = Utils.getInstance(getApplication());
        repository = Utils(this)
        typeface = Typeface.createFromAsset(getAssets(), "me_quran.ttf")
        selectedqari = sharedPreferences.getString("qari", "35")

        //region Description
        if (getIntent().hasExtra(Constants.Companion.SURAH_INDEX)) {
            surah = getIntent().getIntExtra(Constants.Companion.SURAH_INDEX, 1)
            singleline = getIntent().getBooleanExtra(Constants.Companion.MUSHAFDISPLAY, false)
            surahselected = surah
            //   getIntent().getIntExtra(Constants.SURAH_GO_INDEX, 1);
            val ayahtrack: Int = getIntent().getIntExtra(Constants.Companion.AYAH_GO_INDEX, 0)
            if (ayahtrack > 0) {
                setStartPosition(ayahtrack.toLong())
            }
            Log.d(WordbywordMushafAct.Companion.TAG, "onCreate: ayah  " + ayah)

            //       showMessage(String.valueOf(pos));D
        }
        //endregion
        playerView = findViewById(id.player_view)
        playerView.requestFocus()
        if (savedInstanceState != null) {
            trackSelectionParameters = TrackSelectionParameters.fromBundle(
                (savedInstanceState.getBundle(WordbywordMushafAct.Companion.KEY_TRACK_SELECTION_PARAMETERS))!!
            )
            startAutoPlay =
                savedInstanceState.getBoolean(WordbywordMushafAct.Companion.KEY_AUTO_PLAY)
            startItemIndex = savedInstanceState.getInt(WordbywordMushafAct.Companion.KEY_ITEM_INDEX)
            startPosition = savedInstanceState.getLong(WordbywordMushafAct.Companion.KEY_POSITION)
        } else {
            trackSelectionParameters = TrackSelectionParameters. ( /* context= */this).build()
            clearStartPosition()
        }
        val bottomsheetexoplayer: RelativeLayout = findViewById(id.footerplayer)
        exoplayerBottomBehaviour = BottomSheetBehavior.from(bottomsheetexoplayer)
        exoplayerBottomBehaviour.setState(BottomSheetBehavior.STATE_EXPANDED)
        val playerbottomsheet: RelativeLayout = findViewById(id.audio_settings_bottom)
        audioSettingBottomBehaviour = BottomSheetBehavior.from(playerbottomsheet)
        audioSettingBottomBehaviour.setState(BottomSheetBehavior.STATE_EXPANDED)
        recyclerView = findViewById<View>(id.rvAyahsPages) as RecyclerView?
        initSpinner()
        if (!singleline) {
            loadFullQuran()
            prepares()
            println("check")
        }
        initRV()
    }

    private fun getpreferences() {
        val pref: SharedPreferences =
            getApplicationContext().getSharedPreferences("lastreadmushaf", MODE_PRIVATE)
        surah = pref.getInt(Constant.CHAPTER, 20)
        val pagenum: Int = pref.getInt("page", 1)
        surahselected = surah
    }

    private val lastPlayed: Unit
        private get() {
            val aplayed: AudioPositionSaved? =
                ConfigPreferences.getLastPlayedAudio(this, surah.toString())
            if (aplayed != null) {
                resumelastplayed = aplayed.getAudiopsaved().get(0).getAyah()
                resumetrackposition = aplayed.getAudiopsaved().get(0).getTrackposition().toLong()
            }
        }

    private fun loadFullQuran() {
        val pages: MutableList<Page> = ArrayList()
        val quranEntities: List<QuranEntity> = Utils.Companion.getQuranbySurah(surah)
        val firstpage: Int = quranEntities.get(0).getPage()
        var page: Page
        var ayahItems: List<QuranEntity>
        for (i in firstpage..quranEntities.get(quranEntities.size - 1).getPage()) {
            ayahItems = Utils.Companion.getAyahsByPageQuran(surah, i)
            if (ayahItems.size > 0) {
                page = Page()
                page.setAyahItemsquran(ayahItems)
                //    page.se(ayahItems);
                page.setPageNum(i)
                page.setJuz(ayahItems.get(0).getJuz())
                pages.add(page)
            }
        }
        fullQuranPages = ArrayList(pages)
    }

    private fun prepares() {
        var counter: Int = 1
        for (i in fullQuranPages!!.indices) {
            val page: Page = fullQuranPages!!.get(i)
            var aya: String? = ""
            var  : String  = String ()
            var ayahmat: ArrayList<Int> = ArrayList()
            for (ayahItem: QuranEntity in page.getAyahItemsquran()) {
                aya = ayahItem.getQurantext()
                 .append(MessageFormat.format("{0} ﴿ {1} ﴾ ", aya, ayahItem.getAyah()))
                ayahmat.add(ayahItem.getAyah())
            }
            preparehighlightsNew(counter,  , ayahmat)
            ayahmat = ArrayList()
              = String ()
            counter++
        }
    }

    private fun initSpinner() {
        readers = findViewById<View>(id.selectReaders) as Spinner?
        readers!!.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            public override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View,
                position: Int,
                id: Long
            ) {
                WordbywordMushafAct.Companion.readerName = readers!!.getSelectedItem().toString()
                getReaderAudioLink(WordbywordMushafAct.Companion.readerName)
            }

            public override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        readers!!.setOnItemSelectedListener(object : AdapterView.OnItemSelectedListener {
            public override fun onItemSelected(
                parent: AdapterView<*>?,
                view: View,
                position: Int,
                id: Long
            ) {
                WordbywordMushafAct.Companion.readerName = readers!!.getSelectedItem().toString()
                getReaderAudioLink(WordbywordMushafAct.Companion.readerName)
            }

            public override fun onNothingSelected(parent: AdapterView<*>?) {}
        })
        runOnUiThread(object : Runnable {
            public override fun run() {

                //check language to load readers arabic or english
                val readersNames: MutableList<String> = ArrayList()
                readersList = repository!!.getQaris()
                for (reader: Qari in readersList) {
                    if (reader.getAudiotype() == 0 || reader.getAudiotype() == 2) {
                        readersNames.add(reader.getName_english())
                    } /*else {
                        readersNames.add(reader.getName_english());


                    }*/
                }

                //add custom spinner adapter for readers
                val spinnerReaderAdapter: ArrayAdapter<String> = ArrayAdapter(
                    this@WordbywordMushafAct,
                    layout.spinner_layout_larg,
                    id.spinnerText,
                    readersNames
                )
                readers!!.setAdapter(spinnerReaderAdapter)
                for (counter in readersNames.indices) {
                    if ((readersNames.get(counter)
                            .trim({ it <= ' ' }) == selectedqari!!.trim({ it <= ' ' }))
                    ) {
                        readers!!.setSelection(counter)
                        break
                    }
                }
            }
        })
    }

    private fun initpassage() {
        val quranEntities: List<QuranEntity> = Utils.Companion.getQuranbySurah(surah)
        var  : String  = String ()
        var ayahmat: ArrayList<Int> = ArrayList()
        var counter: Int = 1
        for (quranEntity: QuranEntity in quranEntities) {
            if (quranEntity.getPassage_no() == 0) {
                val aya: String = quranEntity.getQurantext()
                 .append(aya).append("﴿ { ").append(quranEntity.getAyah()).append("} ﴾")
                ayahmat.add(quranEntity.getAyah())
            } else if (quranEntity.getPassage_no() != 0) {
                val aya: String = quranEntity.getQurantext()
                 .append(aya).append("﴿ { ").append(quranEntity.getAyah()).append("} ﴾")
                passage.put(counter,  .toString())
                val ayah: Int = quranEntity.getAyah()
                ayahmat.add(ayah + 1)
                preparehighlightsNew(quranEntity.getPassage_no(),  , ayahmat)
                ayahmat = ArrayList()
                  = String ()
                counter++
            }
        }
        println("CHECK")
    }

    fun SurahAyahPicker(isrefresh: Boolean, starttrue: Boolean) {
        val mTextView: TextView
        val chapterWheel: WheelView
        val verseWheel: WheelView
        var wvDay: WheelView?
        val utils: Utils = Utils(this@WordbywordMushafAct)
        val mYear: Array<Array<String?>> = arrayOf(arrayOfNulls(1))
        val mMonth: Array<String?> = arrayOfNulls(1)
        surahWheelDisplayData = arrayOf("")
        ayahWheelDisplayData = arrayOf("")
        val current: Array<ArrayList<String>> = arrayOf<ArrayList<*>>(ArrayList<Any>())
        var mDay: Int
        val chapterno: IntArray = IntArray(1)
        val verseno: IntArray = IntArray(1)
        val surahArrays: Array<String> = getResources().getStringArray(R.array.surahdetails)
        val versearrays: Array<String> = getResources().getStringArray(R.array.versescounts)
        val intarrays: IntArray = getResources().getIntArray(R.array.versescount)
        //     final AlertDialog.  dialogPicker = new AlertDialog. (this);
        val dialogPicker: AlertDialog.  = AlertDialog. (this@WordbywordMushafAct)
        val dlg: Dialog = Dialog(this@WordbywordMushafAct)
        //  AlertDialog dialog =  .create();
        val soraList: ArrayList<ChaptersAnaEntity> = utils.getAllAnaChapters()
        val inflater: LayoutInflater = getLayoutInflater()
        val view: View = inflater.inflate(R.layout.activity_wheel_t, null)
        //  View view = inflater.inflate(R.layout.activity_wheel, null);
        dialogPicker.setView(view)
        mTextView = view.findViewById(id.textView2)
        chapterWheel = view.findViewById(id.wv_year)
        verseWheel = view.findViewById(id.wv_month)
        chapterWheel.setEntries(*surahArrays)
        chapterWheel.setCurrentIndex(surahselected - 1)
        //set wheel initial state
        val initial: Boolean = true
        if (initial) {
            val text: String = chapterWheel.getItem(surahselected - 1) as String
            surahWheelDisplayData.get(0) = (text)
            val chapno: Array<String> =
                text.split(" ".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
            chapterno.get(0) = chapno.get(0).toInt()
            verseno.get(0) = 1
            current.get(0) = ArrayList()
            val intarray: Int
            if (surahselected != 0) {
                intarray = intarrays.get(surahselected - 1)
            } else {
                intarray = 7
            }
            for (i in 1..intarray) {
                current.get(0).add(i.toString())
            }
            verseWheel.setEntries(current.get(0))
            val texts: String = surahWheelDisplayData.get(0) + "/" + ayahWheelDisplayData.get(0)
            //   = mYear[0]+ mMonth[0];
            mTextView.setText(texts)
        }

//        wvDay = (WheelView) view.findViewById(R.id.wv_day);
        val currentsurahVersescount: Array<String>? = null
        val vcount: Int = versearrays.get(surahselected - 1).toInt()
        for (i in 1..vcount) {
            current.get(0).add(i.toString())
        }
        verseWheel.setEntries(current.get(0))
        verseWheel.setCurrentIndex(ayah)
        dialogPicker.setPositiveButton(
            "Done",
            DialogInterface.OnClickListener({ dialogInterface: DialogInterface?, i: Int ->
                var sura: String = ""

                //   setSurahArabicName(suraNumber + "-" + soraList.get(suraNumber - 1).getNameenglish() + "-" + soraList.get(suraNumber - 1).getAbjadname());
                if (chapterno.get(0) == 0) {
                    surahselected = surah
                } else {
                    sura = soraList.get(chapterno.get(0) - 1).getChapterid().toString()
                    surahselected = soraList.get(chapterno.get(0) - 1).getChapterid()
                    surahNameEnglish = soraList.get(chapterno.get(0) - 1).getNameenglish()
                    surahNameArabic = soraList.get(chapterno.get(0) - 1).getNamearabic()
                    val pref: SharedPreferences =
                        getSharedPreferences("lastreadmushaf", MODE_PRIVATE)
                    val editor: SharedPreferences.Editor = pref.edit()
                    editor.putInt(Constant.CHAPTER, sura.toInt())
                    //  editor.putInt("page", page.getAyahItemsquran().get(0).getPage());
                    editor.putString(
                        Constant.SURAH_ARABIC_NAME,
                        soraList.get(chapterno.get(0) - 1).getNamearabic()
                    )
                    editor.apply()
                }
                val verse: Int = verseno.get(0)

                // setSurahselected(Integer.parseInt(sura));
                ayah = verse
                val aya: String = verseno.get(0).toString()
                if (isrefresh && starttrue) {
                    releasePlayer()
                    RefreshActivity(sura, aya, false)
                } else if (starttrue) {
                    updateStartRange(verse)
                } else {
                    updateEndRange(verse)
                }
            })
        )
        dialogPicker.setNegativeButton(
            "Cancel",
            DialogInterface.OnClickListener({ dialogInterface: DialogInterface?, i: Int -> })
        )
        val alertDialog: AlertDialog = dialogPicker.create()
        val preferences: String? = sharedPreferences!!.getString("themepref", "dark")
        val db: Int = ContextCompat.getColor(this, color.odd_item_bg_dark_blue_light)
        if ((preferences == "light")) {
            //    alertDialog.getWindow().setBackgroundDrawableResource(R.color.md_theme_dark_onSecondary);
            alertDialog.getWindow()!!
                .setBackgroundDrawableResource(color.background_color_light_brown)
            //   alertDialog.getWindow().setBackgroundDrawableResource(R.color.md_theme_dark_onTertiary);

            //
        } else if ((preferences == "brown")) {
            alertDialog.getWindow()!!
                .setBackgroundDrawableResource(color.background_color_light_brown)
            //  cardview.setCardBackgroundColor(ORANGE100);
        } else if ((preferences == "blue")) {
            alertDialog.getWindow()!!.setBackgroundDrawableResource(color.prussianblue)
            //  cardview.setCardBackgroundColor(db);
        } else if ((preferences == "green")) {
            alertDialog.getWindow()!!
                .setBackgroundDrawableResource(color.mdgreen_theme_dark_onPrimary)
            //  cardview.setCardBackgroundColor(MUSLIMMATE);
        }
        val lp: WindowManager.LayoutParams = WindowManager.LayoutParams()
        lp.copyFrom(alertDialog.getWindow()!!.getAttributes())
        lp.width = WindowManager.LayoutParams.MATCH_PARENT
        lp.height = WindowManager.LayoutParams.WRAP_CONTENT

        //   alertDialog.show();
        alertDialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
        val wmlp: WindowManager.LayoutParams = alertDialog.getWindow()!!.getAttributes()
        alertDialog.show()
        val buttonPositive: Button = alertDialog.getButton(DialogInterface.BUTTON_POSITIVE)
        buttonPositive.setTextColor(ContextCompat.getColor(this@WordbywordMushafAct, color.green))
        val buttonNegative: Button = alertDialog.getButton(DialogInterface.BUTTON_NEGATIVE)
        buttonNegative.setTextColor(ContextCompat.getColor(this@WordbywordMushafAct, color.red))
        if ((preferences == "light")) {
            buttonPositive.setTextColor(
                ContextCompat.getColor(
                    this@WordbywordMushafAct,
                    color.colorMuslimMate
                )
            )
            buttonNegative.setTextColor(ContextCompat.getColor(this@WordbywordMushafAct, color.red))
        } else if ((preferences == "brown")) {
            buttonPositive.setTextColor(
                ContextCompat.getColor(
                    this@WordbywordMushafAct,
                    color.colorMuslimMate
                )
            )
            buttonNegative.setTextColor(ContextCompat.getColor(this@WordbywordMushafAct, color.red))
            //  cardview.setCardBackgroundColor(ORANGE100);
        } else if ((preferences == "blue")) {
            buttonPositive.setTextColor(
                ContextCompat.getColor(
                    this@WordbywordMushafAct,
                    color.yellow
                )
            )
            buttonNegative.setTextColor(
                ContextCompat.getColor(
                    this@WordbywordMushafAct,
                    color.Goldenrod
                )
            )
            //  cardview.setCardBackgroundColor(db);
        } else if ((preferences == "green")) {
            buttonPositive.setTextColor(
                ContextCompat.getColor(
                    this@WordbywordMushafAct,
                    color.yellow
                )
            )
            buttonNegative.setTextColor(
                ContextCompat.getColor(
                    this@WordbywordMushafAct,
                    color.cyan_light
                )
            )
            //  cardview.setCardBackgroundColor(MUSLIMMATE);
        }

        //  wmlp.gravity = Gravity.TOP | Gravity.CENTER;
        alertDialog.getWindow()!!.setAttributes(lp)
        alertDialog.getWindow()!!.setGravity(Gravity.TOP)
        chapterWheel.setOnWheelChangedListener(object : OnWheelChangedListener {
            public override fun onChanged(wheel: WheelView, oldIndex: Int, newIndex: Int) {
                val text: String = chapterWheel.getItem(newIndex) as String
                surahWheelDisplayData.get(0) = (text)
                val chapno: Array<String> =
                    text.split(" ".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
                chapterno.get(0) = chapno.get(0).toInt()
                verseno.get(0) = 1
                updateVerses(newIndex)
                updateTextView()
                //    updateTextView();
            }

            private fun updateVerses(newIndex: Int) {
                current.get(0) = ArrayList()
                val intarray: Int
                if (newIndex != 0) {
                    intarray = intarrays.get(newIndex)
                } else {
                    intarray = 7
                }
                for (i in 1..intarray) {
                    current.get(0).add(i.toString())
                }
                verseWheel.setEntries(current.get(0))
                updateTextView()
            }

            private fun updateTextView() {
                val text: String = surahWheelDisplayData.get(0) + "/" + ayahWheelDisplayData.get(0)
                //   = mYear[0]+ mMonth[0];
                mTextView.setText(text)
            }
        })
        verseWheel.setOnWheelChangedListener(object : OnWheelChangedListener {
            public override fun onChanged(wheel: WheelView, oldIndex: Int, newIndex: Int) {
                val text: String = verseWheel.getItem(newIndex) as String
                ayahWheelDisplayData.get(0) = (text)
                verseno.get(0) = text.toInt()
            }
        })
    }

    private fun updateEndRange(verse: Int) {
        val st: String  = String ()
        st.append(surahNameEnglish).append("-").append(surahselected).append(":").append(
            ayah
        )
        verseendrange = verse
        endrange!!.setText(st.toString())
        rangeRecitation = true
    }

    private fun updateStartRange(verse: Int) {
        val st: String  = String ()
        val stt: String  = String ()
        st.append(surahNameEnglish).append("-").append(surahselected).append(":").append(
            ayah
        )
        versestartrange = verse
        startrange!!.setText(st.toString())
        rangeRecitation = true
    }

    private fun RefreshActivity(s: String, aya: String, b: Boolean) {
        Log.e(WordbywordMushafAct.Companion.TAG, "onClick called")
        val intent: Intent = getIntent()
        //  surah = getIntent().getIntExtra(Constants.SURAH_INDEX, 1);
        val parentActivityRef: String? = intent.getStringExtra("PARENT_ACTIVITY_REF")
        if (b) {
            intent.putExtra(Constants.Companion.MUSHAFDISPLAY, true)
            intent.putExtra(Constants.Companion.SURAH_INDEX, surah)
        } else if (s.isEmpty() && !b) {
            intent.putExtra(Constants.Companion.MUSHAFDISPLAY, false)
            intent.putExtra(Constants.Companion.SURAH_INDEX, surah)
        } else if (s.isEmpty()) {
            intent.putExtra(Constants.Companion.SURAH_INDEX, surah)
        } else {
            intent.putExtra(Constants.Companion.SURAH_INDEX, s.toInt())
            intent.putExtra(Constants.Companion.AYAH_GO_INDEX, aya.toInt())
        }
        this.overridePendingTransition(0, 0)
        startActivity(intent)
        finish()
        this.overridePendingTransition(android.R.anim.slide_out_right, android.R.anim.slide_in_left)
    }

    private val SinglesendUpdatesToUI: Runnable = object : Runnable {
        val trackchange: Boolean = false
        public override fun run() {
            var holder: RecyclerView.ViewHolder? = null
            holder = recyclerView!!.findViewHolderForAdapterPosition(currenttrack)
            recyclerView!!.post(Runnable({ recyclerView!!.scrollToPosition(currenttrack) }))
            val ab: String  = String ()
            ab.append("Aya").append(":").append(currenttrack).append(" ").append("of").append(
                versescount
            )
            ayaprogress!!.setText(ab.toString())
            if (null != holder) {
                try {
                    if (holder.itemView.findViewById<View?>(id.flow_word_by_word) != null) {
                        if ((isNightmode == "light")) {
                            val textViews: TextView =
                                holder.itemView.findViewById<View>(id.flow_word_by_word)
                                    .findViewById(
                                        id.word_arabic_textView
                                    )
                            holder.itemView.findViewById<View>(id.flow_word_by_word)
                                .setBackgroundColor(
                                    ContextCompat.getColor(
                                        this@WordbywordMushafAct,
                                        color.horizontalview_color_ab
                                    )
                                )
                        } else if ((isNightmode == "brown")) {
                            val textViews: TextView =
                                holder.itemView.findViewById<View>(id.flow_word_by_word)
                                    .findViewById(
                                        id.word_arabic_textView
                                    )
                            holder.itemView.findViewById<View>(id.flow_word_by_word)
                                .setBackgroundColor(
                                    ContextCompat.getColor(
                                        this@WordbywordMushafAct,
                                        color.bg_surface_brown
                                    )
                                )
                        } else {
                            val textViews: TextView =
                                holder.itemView.findViewById<View>(id.flow_word_by_word)
                                    .findViewById(
                                        id.word_arabic_textView
                                    )
                            holder.itemView.findViewById<View>(id.flow_word_by_word)
                                .setBackgroundColor(
                                    ContextCompat.getColor(
                                        this@WordbywordMushafAct,
                                        color.bg_surface_dark_blue
                                    )
                                )
                            //   holder.itemView.findViewById(R.id.quran_textView).setBackgroundColor(Constant.MUSLIMMATE);
                        }
                    } else if (holder.itemView.findViewById<View?>(id.rukuview) != null) {
                        println("rukuvue")
                    }
                } catch (exception: NullPointerException) {
                    Toast.makeText(
                        this@WordbywordMushafAct,
                        "null pointer udapte",
                        Toast.LENGTH_SHORT
                    ).show()
                }
            }
            val temp: Int = 2
            if (currenttrack > 1) {
                val holderp: RecyclerView.ViewHolder? =
                    recyclerView!!.findViewHolderForAdapterPosition(currenttrack - 1)
                if (null != holderp) {
                    try {
                        val drawingCacheBackgroundColor: Int = holderp.itemView.findViewById<View>(
                            id.flow_word_by_word
                        ).getDrawingCacheBackgroundColor()
                        if (holderp.itemView.findViewById<View?>(id.flow_word_by_word) != null) {
                            //    holder.itemView.findViewById(R.id.quran_textView).setBackgroundColor(Color.CYAN);
                            holderp.itemView.findViewById<View>(id.flow_word_by_word)
                                .setBackgroundColor(drawingCacheBackgroundColor)
                        }
                    } catch (exception: NullPointerException) {
                        Toast.makeText(
                            this@WordbywordMushafAct,
                            "UPDATE HIGHLIGHTED",
                            Toast.LENGTH_SHORT
                        ).show()
                    }
                }
            }

            //  rvAyahsPages.post(() -> rvAyahsPages.scrollToPosition((ayah)));
            handler.postDelayed(this, 1500)
        }

        private fun setVerseHighLight(textView: TextView, foreGroundcoloer: Int) {
            val str: String = textView.getText().toString()
            val span: SpannableString  = SpannableString (str)
            try {
                span.setSpan(
                    ForegroundColorSpan(foreGroundcoloer),
                    hlights.get(currenttrack)!!.get(0).getStart(),
                    hlights.get(currenttrack)!!
                        .get(0).getEnd(),
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                textView.setText(span)
                val split: Array<String> =
                    str.split("\n".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
            } catch (exception: IndexOutOfBoundsException) {
                println(exception)
            }
        }

        private fun Highlightverse(textView: TextView) {
            val start: Int
            val end: Int
            val starta: String
            val endb: String
            val str: String = textView.getText().toString()
            val split1: Array<String> =
                str.split("﴿".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
            val span: SpannableString  = SpannableString (str)
            if (currenttrack == 1) {
                start = 0
                endb = currenttrack.toString()
                end = str.indexOf(endb)
            } else {
                starta = currenttrack.toString()
                start = str.indexOf(starta)
                endb = (currenttrack + 1).toString()
                end = str.indexOf(endb)
            }
            try {
                println(span.subSequence(start, end))
                span.setSpan(
                    ForegroundColorSpan(Color.CYAN),
                    start,
                    end,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                textView.setText(span)
                val split: Array<String> =
                    str.split("\n".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
            } catch (exception: IndexOutOfBoundsException) {
                println(exception)
            }
        }
    }

    private fun setupHandlerSingle() {
        handler.removeCallbacks(SinglesendUpdatesToUI)
        handler.postDelayed(SinglesendUpdatesToUI, 1000)
    }

    protected fun releasePlayer() {
        if (player != null) {
            updateTrackSelectorParameters()
            updateStartPosition()
            player!!.release()
            player = null
            playerView!!.setPlayer( /* player= */null)
            val mediaItems: List<MediaItem> = emptyList()
        }
    }

    public override fun onStop() {
        super.onStop()
        if (Util.SDK_INT > 23) {
            //      this.releasePlayer();
        }
    }

    protected fun initializePlayer(): Boolean {
        if (audioSettingBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_EXPANDED) {
            audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
            exoplayerBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
            playerFooter!!.setVisibility(View.VISIBLE)
            audio_settings_bottom!!.setVisibility(View.GONE)
        }
        if (isMusicplaying) {
            releasePlayer()
        }
        if (player == null) {
            playerFooter!!.setVisibility(View.VISIBLE)
            //  normalFooter.setVisibility(View.GONE);
            downloadFooter!!.setVisibility(View.GONE)
            val stream: Boolean = false
            val playbackPosition: Long = 0L
            if (stream) {
                val streamUrl: String =
                    "https://ia800204.us.archive.org/17/items/AbdAlrahman-Al3osy/009.mp3"
                player = ExoPlayer. (this@WordbywordMushafAct)
                    .setMediaSourceFactory(
                        DefaultMediaSourceFactory(this@WordbywordMushafAct).setLiveTargetOffsetMs(
                            5000
                        )
                    )
                    .build()

// Per MediaItem settings.
                val mediaItem: MediaItem = MediaItem.fromUri(streamUrl)
                player!!.addMediaItem(mediaItem)
                //  player = new ExoPlayer. (this).build();
                lastSeenTracks = Tracks.EMPTY
                player!!.addListener(WordbywordMushafAct.PlayerEventListener())
                player!!.setTrackSelectionParameters((trackSelectionParameters)!!)
                player!!.addListener(WordbywordMushafAct.PlayerEventListener())
                player!!.addAnalyticsListener(EventLogger())
                player!!.setAudioAttributes(AudioAttributes.DEFAULT,  /* handleAudioFocus= */true)
                player!!.setPlayWhenReady(startAutoPlay)
                player!!.setRepeatMode(Player.REPEAT_MODE_ALL)
                player!!.getBufferedPercentage()
                playerView!!.setRepeatToggleModes(RepeatModeUtil.REPEAT_TOGGLE_MODE_ONE)
                player!!.seekTo(ayah, playbackPosition)
                if (versestartrange != 0) {
                    ayah = versestartrange
                }
                playerView!!.setPlayer(player)
                player!!.prepare()
                val str: String = surahNameEnglish + ":" + WordbywordMushafAct.Companion.readerName
                qariname!!.setText(str)
                player!!.play()
            } else {
                //      myPlayer mp=new myPlayer(ShowMushafActivity.this,surah);
                marray = createMediaItems()
                if (marray!!.isEmpty()) {
                    return false
                }
                player = ExoPlayer. (this).build()
                lastSeenTracks = Tracks.EMPTY
                player!!.addListener(WordbywordMushafAct.PlayerEventListener())
                player!!.setTrackSelectionParameters((trackSelectionParameters)!!)
                player!!.addListener(WordbywordMushafAct.PlayerEventListener())
                player!!.addAnalyticsListener(EventLogger())
                player!!.setAudioAttributes(AudioAttributes.DEFAULT,  /* handleAudioFocus= */true)
                player!!.setPlayWhenReady(startAutoPlay)
                player!!.setRepeatMode(Player.REPEAT_MODE_ALL)
                playerView!!.setRepeatToggleModes(RepeatModeUtil.REPEAT_TOGGLE_MODE_ONE)
                player!!.seekTo(ayah, playbackPosition)
                if (versestartrange != 0) {
                    ayah = versestartrange
                }
                playerView!!.setPlayer(player)
                player!!.addListener(object : Player.Listener {
                    public override fun onPlaybackStateChanged(playbackState: Int) {
                        if (player!!.getPlayWhenReady() && playbackState == Player.STATE_READY) {
                            isMusicplaying = true // media actually playing
                        } else if (player!!.getPlayWhenReady()) {
                            isMusicplaying = false
                            // might be idle (plays after prepare()),
                            // buffering (plays when data available)
                            // or ended (plays when seek away from end)
                        } else {
                            pausePlayFlag = true
                            // player paused in any state
                        }
                        super@Listener.onPlaybackStateChanged(playbackState)
                    }
                })
                val haveStartPosition: Boolean = startItemIndex != C.INDEX_UNSET
                if (haveStartPosition) {
                    //    player.seekTo(startItemIndex, startPosition);
                }
                if (rangeRecitation) {
                    marrayrange = marray!!.subList(versestartrange, verseendrange)
                    player!!.setMediaItems(marrayrange,  /* resetPosition= */!haveStartPosition)
                } else {
                    player!!.setMediaItems(marray!!,  /* resetPosition= */!haveStartPosition)
                }
                val str: String =
                    ("(") + surahNameArabic + ")" + "(" + surahNameEnglish + ")" + ":" + WordbywordMushafAct.Companion.readerName
                qariname!!.setText(str)
                //   qariname.setText(readerName);
                player!!.prepare()
                if (resume) {
                    player!!.seekToDefaultPosition(resumelastplayed)
                }
                if (audioSettingBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_EXPANDED) {
                    audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
                }
                if (exoplayerBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
                    player!!.play()
                }

                /*  player.getCurrentAdGroupIndex();
                player.setTrackSelectionParameters(
                        player.getTrackSelectionParameters()
                                .buildUpon()
                                .setOverrideForType(
                                        new TrackSelectionOverride(
                                                audioTrackGroup.getMediaTrackGroup(),
                                                */
                /* trackIndex= */ /* 0))
                                .build());*/
            }
        }
        //updateButtonVisibility();
        return true
    }

    private fun createMediaItems(): MutableList<MediaItem> {
        val repository: Utils = Utils(this)
        val chap: List<ChaptersAnaEntity> = repository.getSingleChapter(
            surahselected
        )
        println(versestartrange.toString() + " " + verseendrange)
        val ayaLocations: MutableList<String> = ArrayList()
        marray = ArrayList()
        /*     if (getVersestartrange() != 0 && getVerseendrange() != 0) {
            onClickOrRange = true;
            List<QuranEntity> quranbySurah = Utils.getQuranbySurahAyahrange(surah, getVersestartrange(), getVerseendrange());
            for (QuranEntity ayaItem : quranbySurah) {
                ayaLocations.add(FileManager.createAyaAudioLinkLocation(this, readerID, ayaItem.getAyah(), ayaItem.getSurah()));
                String location = FileManager.createAyaAudioLinkLocation(this, readerID, ayaItem.getAyah(), ayaItem.getSurah());
                marray.add(MediaItem.fromUri(location));

            }
        } else */if (isSingle) {
            val sngleverseplay: List<QuranEntity> = Utils.Companion.getsurahayahVerses(
                surahselected, verselected
            )
            //Create files locations for the all page ayas
            for (ayaItem: QuranEntity in sngleverseplay) {
                ayaLocations.add(
                    FileManager.createAyaAudioLinkLocation(
                        this,
                        WordbywordMushafAct.Companion.readerID,
                        ayaItem.getAyah(),
                        ayaItem.getSurah()
                    )
                )
                val location: String = FileManager.createAyaAudioLinkLocation(
                    this,
                    WordbywordMushafAct.Companion.readerID,
                    ayaItem.getAyah(),
                    ayaItem.getSurah()
                )
                marray.add(MediaItem.fromUri(location))
            }
        } else if (isStartFrom) {
            onClickOrRange = true
            val fromrange: List<QuranEntity> = Utils.Companion.getQuranbySurahAyahrange(
                surahselected, verselected, chap.get(0).getVersescount()
            )
            for (ayaItem: QuranEntity in fromrange) {
                ayaLocations.add(
                    FileManager.createAyaAudioLinkLocation(
                        this,
                        WordbywordMushafAct.Companion.readerID,
                        ayaItem.getAyah(),
                        ayaItem.getSurah()
                    )
                )
                val location: String = FileManager.createAyaAudioLinkLocation(
                    this,
                    WordbywordMushafAct.Companion.readerID,
                    ayaItem.getAyah(),
                    ayaItem.getSurah()
                )
                marray.add(MediaItem.fromUri(location))
            }
        } else {
            val quranbySurah: List<QuranEntity> = Utils.Companion.getQuranbySurah(
                surahselected
            )
            for (ayaItem: QuranEntity in quranbySurah) {
                ayaLocations.add(
                    FileManager.createAyaAudioLinkLocation(
                        this,
                        WordbywordMushafAct.Companion.readerID,
                        ayaItem.getAyah(),
                        ayaItem.getSurah()
                    )
                )
                val location: String = FileManager.createAyaAudioLinkLocation(
                    this,
                    WordbywordMushafAct.Companion.readerID,
                    ayaItem.getAyah(),
                    ayaItem.getSurah()
                )
                marray.add(MediaItem.fromUri(location))
            }
        }
        return marray
    }

    private fun updateTrackSelectorParameters() {
        if (player != null) {
            trackSelectionParameters = player!!.getTrackSelectionParameters()
        }
    }

    private fun updateStartPosition() {
        if (player != null) {
            startAutoPlay = player!!.getPlayWhenReady()
            startItemIndex = player!!.getCurrentMediaItemIndex()
            startPosition = Math.max(0, player!!.getContentPosition())
        }
    }

    public override fun onFullscreenButtonClick(isFullScreen: Boolean) {}
    fun pauseplay() {
        if (player != null) {
            player!!.pause()
        }
    }

    private inner class PlayerEventListener constructor() : Player.Listener {
        public override fun onPlaybackStateChanged(playbackState: @Player.State Int) {
            if (playbackState == Player.STATE_ENDED) {
                println("playbackstate")
            }
            //     updateButtonVisibility();
        }

        public override fun onPlayerError(error: PlaybackException) {
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                assert(player != null)
                player!!.seekToDefaultPosition()
                player!!.prepare()
            } else {
            }
        }

        public override fun onMediaItemTransition(
            mediaItem: MediaItem?, reason: @MediaItemTransitionReason Int
        ) {
            //  listener.onMediaItemTransition(mediaItem, reason);
            println("check")
        }

        public override fun onPositionDiscontinuity(
            oldPosition: PositionInfo, newPosition: PositionInfo, reason: @DiscontinuityReason Int
        ) {
            println("oldpostion" + " " + oldPosition + "newpostion " + " " + newPosition + "reason" + " " + reason)
            println("check")
        }

        public override fun onTracksChanged(tracks: Tracks) {
            //   updateButtonVisibility();
            val currentTracks: Tracks = player!!.getCurrentTracks()
            currenttrack = player!!.getCurrentMediaItemIndex()
            //     currenttrack=resumelastplayed;
            val resume: Boolean = true
            println("Ayah" + "" + ayah)
            if (rangeRecitation) {
                currenttrack += versestartrange
                currenttrack++
            } else if (onClickOrRange) {
                currenttrack += ayah
            } else {
                currenttrack++
            }
            singleline = true
            //    NewsendUpdatesToUIPassage.run();
            if (player!!.isPlaying() || player!!.getPlayWhenReady()) {
                SinglesendUpdatesToUI.run()
                //   sendUpdatesToUI.run();
            } else {
                handler.removeCallbacks(SinglesendUpdatesToUI)
            }
            if (tracks === lastSeenTracks) {
                return
            }
            if ((tracks.containsType(C.TRACK_TYPE_AUDIO)
                        && !tracks.isTypeSupported(
                    C.TRACK_TYPE_AUDIO,  /* allowExceedsCapabilities= */
                    true
                ))
            ) {
                //showToast(R.string.error_unsupported_audio);
            }
            lastSeenTracks = tracks
        }
    }

    private fun preparehighlightsNew(passageno: Int, str: String , ayahmat: ArrayList<Int>) {
        val holder: RecyclerView.ViewHolder? = recyclerView!!.findViewHolderForAdapterPosition(1)
        var ayahindex: Int = ayahmat.get(0)
        val ayahmaz: Int = ayahmat.size
        val split1: Array<String> =
            str.toString().split("﴿".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val start: Int = 0
        //  = str.indexOf("1");
        val end: Int = str.indexOf(ayahindex.toString())
        val acf: AyahCoordinate = AyahCoordinate(0, end, passageno)
        val Coordinatesf: ArrayList<AyahCoordinate> = ArrayList()
        Coordinatesf.add(acf)
        hlights.put(ayahindex, Coordinatesf)
        //  ayahindex++;
        for (i in split1.indices) {
            val s: Int = str.indexOf(ayahindex.toString())
            val e: Int = str.indexOf((ayahindex + 1).toString())
            if (s != -1 && e != -1) {
                val ac: AyahCoordinate = AyahCoordinate(s, e, passageno)
                val Coordinates: ArrayList<AyahCoordinate> = ArrayList()
                Coordinates.add(ac)
                hlights.put(++ayahindex, Coordinates)
            } else {
                println(s.toString() + " " + e)
            }
        }
        println("check")
    }

    private fun preparehighlights(passageno: Int, str: String , ayahmat: ArrayList<Int>) {
        val holder: RecyclerView.ViewHolder? = recyclerView!!.findViewHolderForAdapterPosition(1)
        var ayahindex: Int = ayahmat.get(0)
        val split1: Array<String> =
            str.toString().split("﴿".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        if (ayahindex == 1) {
            val start: Int = 0
            val end: Int = str.indexOf("1")
            val ac: AyahCoordinate = AyahCoordinate(0, end, passageno)
            val Coordinates: ArrayList<AyahCoordinate> = ArrayList()
            Coordinates.add(ac)
            hlights.put(ayahindex, Coordinates)
            ayahindex++
        }
        for (i in split1.indices) {
            val s: Int = str.indexOf(ayahindex.toString())
            val e: Int = str.indexOf((ayahindex + 1).toString())
            if (s != -1 && e != -1) {
                val ac: AyahCoordinate = AyahCoordinate(s, e, passageno)
                val Coordinates: ArrayList<AyahCoordinate> = ArrayList()
                Coordinates.add(ac)
                hlights.put(ayahindex++, Coordinates)
            }
        }
        println("check")
    }

    protected fun clearStartPosition() {
        startAutoPlay = true
        startItemIndex = C.INDEX_UNSET
        startPosition = C.TIME_UNSET
    }

    @SuppressLint("WrongViewCast")
    private fun initRV() {
        ExecuteSurahWordByWord()
        canceldownload = findViewById<View>(id.canceldownload) as MaterialButton?
        canceldownload!!.setOnClickListener(this)
        ayaprogress = findViewById<View>(id.ayaprogress) as MaterialTextView?
        qariname = findViewById<View>(id.lqari) as MaterialTextView?
        buffering = findViewById<View>(id.exo_buffering) as ImageView?
        val chooseDisplaytype: SwitchCompat = findViewById(id.chooseDisplaytype)
        chooseDisplaytype.setOnClickListener(this)
        playfb = findViewById<View>(id.playfb) as MovableFloatingActionButton?
        playfb!!.setOnClickListener(this)
        exo_settings = findViewById(id.exo_settings)
        exo_settings.setOnClickListener(this)
        exo_close = findViewById<View>(id.exo_close) as ImageButton?
        exo_bottom_bar = findViewById<View>(id.exo_bottom_bar) as ImageButton?
        //  private ImageView playbutton;
        val playbutton: MaterialButton = findViewById(id.playbutton)
        val playresume: MaterialButton = findViewById<View>(id.playresume) as MaterialButton
        playresume.setOnClickListener(this)
        val surahselection: MaterialButton = findViewById<View>(id.surahselection) as MaterialButton
        surahselection.setOnClickListener(this)
        exo_close!!.setOnClickListener(this)
        playbutton.setOnClickListener(this)
        exo_bottom_bar!!.setOnClickListener(this)
        chooseDisplaytype.setChecked(singleline)
        startrange = findViewById(id.start_range)
        endrange = findViewById(id.endrange)
        startrange.setOnClickListener(this)
        llStartRange = findViewById<View>(id.llStartRange) as LinearLayout?
        llStartRange!!.setOnClickListener(this)
        endrange.setOnClickListener(this)
        llEndRange = findViewById<View>(id.llEndRange) as LinearLayout?
        llEndRange!!.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                val starttrue: Boolean = false
                SurahAyahPicker(false, starttrue)
            }
        })
        llStartRange!!.setOnClickListener(object : View.OnClickListener {
            val starttrue: Boolean = true
            public override fun onClick(v: View) {
                marrayrange = null
                SurahAyahPicker(false, starttrue)
            }
        })
        val listView: ListView = findViewById<View>(id.ayahlist) as ListView
        val seekBar: SeekBar = findViewById(id.SeekBar01)
        val footerContainer: RelativeLayout = findViewById<View>(id.footerbar) as RelativeLayout
        audio_settings_bottom = findViewById(id.audio_settings_bottom)
        //  normalFooter = (LinearLayout) findViewById(R.id.normalfooter);
        downloadFooter = findViewById<View>(id.footerdownload) as RelativeLayout?
        playerFooter = findViewById<View>(id.footerplayer) as RelativeLayout?
        mediaPlayerDownloadProgress = findViewById<View>(id.downloadProgress) as ProgressBar?
        chooseDisplaytype.setOnCheckedChangeListener(object :
            CompoundButton.OnCheckedChangeListener {
            public override fun onCheckedChanged(buttonView: CompoundButton, isChecked: Boolean) {
                if (isChecked) {
                    singleline = true
                    RefreshActivity("", "", true)
                } else {
                    singleline = false
                    RefreshActivity("", "", false)
                }
            }
        })
        startrange.setOnClickListener(object : View.OnClickListener {
            val starttrue: Boolean = true
            public override fun onClick(v: View) {
                SurahAyahPicker(false, starttrue)
            }
        })
        endrange.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                val starttrue: Boolean = false
                SurahAyahPicker(false, starttrue)
            }
        })
        surahselection.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                SurahAyahPicker(true, true)
            }
        })
        playfb!!.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                if (audioSettingBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
                    audio_settings_bottom.setVisibility(View.VISIBLE)
                } else {
                    audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
                    //    audio_settings_bottom.setVisibility(View.GONE);
                }
                if (exoplayerBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    exoplayerBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
                    if (player != null) player!!.play()
                } else {
                    if (player != null) player!!.pause()
                    exoplayerBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
                }
                val st: String  = String ()
                val stt: String  = String ()
                st.append(surahNameEnglish).append("-").append(surahselected).append(":")
                    .append("1")
                stt.append(surahNameEnglish).append("-").append(surahselected).append(":").append(
                    versescount
                )
                startrange.setText(st.toString())
                startrange.setText(stt.toString())
            }
        })
        val manager: LinearLayoutManager = LinearLayoutManager(this)
        manager.setOrientation(LinearLayoutManager.VERTICAL)
        quranbySurahadapter = Utils.Companion.getQuranbySurah(surah)
        var sb: String  = String ()
        for (entity: QuranEntity in quranbySurahadapter!!) {
            if (entity.getPassage_no() != 0) {
                sb.append(entity.getQurantext()).append("﴿").append(entity.getAyah()).append("﴾")
            } else {
                passage.put(entity.getPassage_no(), sb.toString())
                sb = String ()
            }
        }
        exo_bottom_bar!!.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                SurahAyahPicker(true, true)
            }
        })
        exo_close!!.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                //reset player
                verselected = 1
                versestartrange = 0
                verseendrange = 0
                ayah = 0
                marrayrange = null
                resume = false
                rangeRecitation = false
                handler.removeCallbacks(SinglesendUpdatesToUI)
                recyclerView!!.post(Runnable({ recyclerView!!.scrollToPosition((0)) }))
                releasePlayer()
                initializePlayer()

                //    RefreshActivity("", " ", false);
            }
        })
        exo_settings.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                if (audioSettingBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
                    audio_settings_bottom.setVisibility(View.VISIBLE)
                } else {
                    audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
                    //    audio_settings_bottom.setVisibility(View.GONE);
                }
                if (exoplayerBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
                    exoplayerBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
                    assert(player != null)
                    player!!.play()
                } else {
                    if (null != player) {
                        player!!.pause()
                        exoplayerBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
                    }
                }
            }
        })
        playbutton.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                DownloadIfnotPlay()
            }
        })
        playresume.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                resume = true
                DownloadIfnotPlay()
            }
        })
        canceldownload!!.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View) {
                downloadFooter!!.setVisibility(View.GONE)
                //  normalFooter.setVisibility(View.VISIBLE);
                //stop flag of auto start audio after download
                WordbywordMushafAct.Companion.startBeforeDownload = false
                //stop download service
                stopService(Intent(this@WordbywordMushafAct, DownloadService::class.java))
            }
        })

        // to preserver quran direction from right to left
        recyclerView!!.setLayoutDirection(View.LAYOUT_DIRECTION_RTL)
    }

    fun ExecuteSurahWordByWord() {
        utils = Utils(this)
        val  : AlertDialog.  =
            AlertDialog. (this, style.ThemeOverlay_Material3_Dialog)
         .setCancelable(false) // if you want user to wait for some process to finish,
         .setView(R.layout.layout_loading_dialog)
        val dialog: AlertDialog =  .create()
        corpusayahWordArrayList = ArrayList()
        mafoolbihiwords = ArrayList()
        Jumlahaliya = ArrayList()
        Tammezent = ArrayList()
        Liajlihient = ArrayList()
        Jumlahaliya = utils!!.getHaliaErabBysurah(surah)
        Liajlihient = utils!!.getMafoolLiajlihisurah(surah)
        //  mafoolbihiwords =utils.getMafoolBihiErabSurah(surah);
        mafoolbihiwords = utils!!.getMafoolBySurah(surah)
        Tammezent = utils!!.getTameezsurah(surah)
        Mutlaqent = utils!!.getMutlaqsurah(surah)
        BadalErabNotesEnt = utils!!.getBadalrabSurah(surah)
        val ex: ExecutorService = Executors.newSingleThreadExecutor()
        ex.execute(Runnable({
            //do inbackground
            bysurah(dialog, ex)
        }))
    }

    @SuppressLint("NotifyDataSetChanged")
    private fun bysurah(dialog: AlertDialog, ex: ExecutorService) {
        runOnUiThread(Runnable({ dialog.show() }))
        val wbwSurah: WbwSurah =
            WbwSurah(this@WordbywordMushafAct, surah, corpusayahWordArrayList, ruku)
        wbwSurah.getWordbyword()
        val corpus: CorpusUtilityorig = CorpusUtilityorig(this)
        //      corpus.highLightVerbs(corpusayahWordArrayList,surah_id);
        if (kana) {
            corpus.setKana(corpusayahWordArrayList, surah)
        }
        if (shart) {
            corpus.setShart(corpusayahWordArrayList, surah)
        }
        if (mudhaf) {
            corpus.setMudhafFromDB(corpusayahWordArrayList, surah)
        }
        if (mausoof) {
            corpus.SetMousufSifaDB(corpusayahWordArrayList, surah)
            //  corpus.NewMAOUSOOFSIFA(corpusayahWordArrayList);
        }
        if (harfnasb) {
            corpus.newnewHarfNasbDb(corpusayahWordArrayList, surah)
        }
        //     corpus.highLightVerbs(corpusayahWordArrayList,surah_id);
        //post
        runOnUiThread(Runnable({
            dialog.dismiss()
            ex.shutdown()
            recyclerView = findViewById(id.rvAyahsPages)
            allofQuran = Utils.Companion.getQuranbySurah(surah)
            val chapter: ArrayList<ChaptersAnaEntity> = repository!!.getSingleChapter(surah)
            //  initlistview(quranbySurah, chapter);
            val listener: OnItemClickListenerOnLong = this
            val header: ArrayList<String> = ArrayList()
            header.add(chapter.get(0).getRukucount().toString())
            header.add(chapter.get(0).getVersescount().toString())
            header.add(chapter.get(0).getChapterid().toString())
            header.add(chapter.get(0).getAbjadname())
            header.add(chapter.get(0).getNameenglish())
            versescount = chapter.get(0).getVersescount()
            surahNameEnglish = chapter.get(0).getNameenglish()
            surahNameArabic = chapter.get(0).getNamearabic()
            val manager: LinearLayoutManager = LinearLayoutManager(this)
            manager.setOrientation(LinearLayoutManager.VERTICAL)
            val mLayoutManager: GridLayoutManager = GridLayoutManager(this, 2)
            recyclerView.setHasFixedSize(true)
            manager.setOrientation(LinearLayoutManager.VERTICAL)

            /*
            recyclerView.setLayoutManager(manager);
            flowAyahWordAdapterpassage = new FlowAyahWordAdapterPassage(ruku, Mutlaqent, Tammezent, BadalErabNotesEnt, Liajlihient, Jumlahaliya, mafoolbihiwords, header, allofQuran, corpusayahWordArrayList, WordbywordMushafAct.this, surah, getSurahNameEnglish(), isMakkiMadani, listener);
            flowAyahWordAdapterpassage.addContext(WordbywordMushafAct.this);
            recyclerView.setHasFixedSize(true);
            recyclerView.setAdapter(flowAyahWordAdapterpassage);
            flowAyahWordAdapterpassage.notifyDataSetChanged();
*/


            // recyclerView.setItemAnimator(new DefaultItemAnimator());
            recyclerView.setLayoutManager(manager)
            val flowAyahWordAdapter: FlowAyahWordAdapter = FlowAyahWordAdapter(
                true,
                ruku,
                Mutlaqent,
                Tammezent,
                BadalErabNotesEnt,
                Liajlihient,
                Jumlahaliya,
                mafoolbihiwords,
                header,
                allofQuran,
                corpusayahWordArrayList,
                this@WordbywordMushafAct,
                surah.toLong(),
                surahNameArabic,
                isMakkiMadani,
                listener
            )
            flowAyahWordAdapter.addContext(this@WordbywordMushafAct)
            recyclerView.setHasFixedSize(true)
            recyclerView.setAdapter(flowAyahWordAdapter)
            flowAyahWordAdapter.notifyDataSetChanged()
            recyclerView.setItemAnimator(DefaultItemAnimator())
        }))
    }

    fun getReaderAudioLink(readerName: String) {
        for (reader: Qari in readersList!!) {
            if ((reader.getName_english() == readerName) && (Locale.getDefault()
                    .getDisplayLanguage() == "العربية")
            ) {
                WordbywordMushafAct.Companion.downloadLink = reader.getUrl()
                WordbywordMushafAct.Companion.readerID = reader.getId()
                audioType = reader.getAudiotype()
                break
            } else if ((reader.getName_english() == readerName)) {
                WordbywordMushafAct.Companion.downloadLink = reader.getUrl()
                WordbywordMushafAct.Companion.readerID = reader.getId()
                break
            }
        }
    }

    override fun onPause() {
//        mSensorManager.unregisterListener(this);
        super.onPause()
        audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
        playerFooter!!.setVisibility(View.VISIBLE)
        if (player != null) {
            player!!.pause()
        }
        // player.play();
        //unregister broadcast for download ayat
        LocalBroadcastManager.getInstance(this).unregisterReceiver(downloadPageAya)
        //stop flag of auto start
        WordbywordMushafAct.Companion.startBeforeDownload = false
    }

    override fun onResume() {
        super.onResume()

        //register broadcast for download ayat
        LocalBroadcastManager.getInstance(this).registerReceiver(
            downloadPageAya, IntentFilter(
                AudioAppConstants.Download.Companion.INTENT
            )
        )

        //make footer change to normal if audio end in pause
        if (!Settingsss.isMyServiceRunning(this, DownloadService::class.java)) {
            playerFooter!!.setVisibility(View.GONE)
            //    normalFooter.setVisibility(View.GONE);
        } else {
            if (downloadFooter!!.getVisibility() != View.VISIBLE) {
                playerFooter!!.setVisibility(View.VISIBLE)
            } else {
                playerFooter!!.setVisibility(View.GONE)
            }
            //   normalFooter.setVisibility(View.GONE);
        }

        //  if (audioSettingBottomBehaviour.getState() == BottomSheetBehavior.STATE_EXPANDED) {
        //   audioSettingBottomBehaviour.setState(BottomSheetBehavior.STATE_COLLAPSED);
        // }
        if (exoplayerBottomBehaviour!!.getState() == BottomSheetBehavior.STATE_COLLAPSED) {
            audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_EXPANDED)
            playerFooter!!.setVisibility(View.VISIBLE)
            player!!.play()
        }
        if (playerFooter!!.getVisibility() == View.GONE) {
            playerFooter!!.setVisibility(View.VISIBLE)
            if (player != null) {
                player!!.play()
            }
        }
        //loadPagesReadLoge();
    }

    private val downloadPageAya: BroadcastReceiver = object : BroadcastReceiver() {
        public override fun onReceive(context: Context, intent: Intent) {
            val value: Int =
                intent.getLongExtra(AudioAppConstants.Download.Companion.NUMBER, 0).toInt()
            val max: Int = intent.getLongExtra(AudioAppConstants.Download.Companion.MAX, 0).toInt()
            val status: String? =
                intent.getStringExtra(AudioAppConstants.Download.Companion.DOWNLOAD)
            if (status != null) {
                if ((status == AudioAppConstants.Download.Companion.IN_DOWNLOAD)) {
                    downloadFooter!!.setVisibility(View.VISIBLE)
                    //  normalFooter.setVisibility(View.GONE);
                    playerFooter!!.setVisibility(View.GONE)
                    mediaPlayerDownloadProgress!!.setMax(max)
                    mediaPlayerDownloadProgress!!.setProgress(value)
                } else if ((status == AudioAppConstants.Download.Companion.FAILED)) {
                    mediaPlayerDownloadProgress!!.setMax(1)
                    mediaPlayerDownloadProgress!!.setProgress(1)
                } else if ((status == AudioAppConstants.Download.Companion.SUCCESS)) {
                    mediaPlayerDownloadProgress!!.setMax(1)
                    mediaPlayerDownloadProgress!!.setProgress(1)
                    //check if you auto play after download
                    if (WordbywordMushafAct.Companion.startBeforeDownload) {
                        //change views
                        downloadFooter!!.setVisibility(View.GONE)
                        //    normalFooter.setVisibility(View.GONE);
                        playerFooter!!.setVisibility(View.VISIBLE)
                        initializePlayer()
                    } else {
                        downloadFooter!!.setVisibility(View.GONE)
                        //   normalFooter.setVisibility(View.GONE);
                        playerFooter!!.setVisibility(View.GONE)
                    }
                }
            }
        }
    }

    fun createDownloadLink(): List<String> {
        val chap: List<ChaptersAnaEntity> = repository!!.getSingleChapter(surah)
        surahselected = surah
        //   int ayaID=0;
        var counter: Int = 0
        //   quranbySurah.add(0, new QuranEntity(1, 1, 1));
        val downloadLin: MutableList<String> = ArrayList()

        //validate if aya download or not
        if (!QuranValidateSources.validateSurahAudio(
                this,
                WordbywordMushafAct.Companion.readerID,
                surahselected
            )
        ) {

            //create aya link
            val suraLength: Int = chap.get(0).getChapterid().toString().trim({ it <= ' ' }).length
            var suraID: String = chap.get(0).getChapterid().toString() + ""

            //   int ayaLength = String.valueOf(ayaItem.ayaID).trim().length();
            if (suraLength == 1) suraID =
                "00" + chap.get(0).getChapterid() else if (suraLength == 2) suraID =
                "0" + chap.get(0).getChapterid()
            counter++
            val s: String = WordbywordMushafAct.Companion.downloadLink + chap.get(0)
                .getChapterid() + AudioAppConstants.Extensions.Companion.MP3
            downloadLin.add(s)
            Log.d(
                "DownloadLinks",
                WordbywordMushafAct.Companion.downloadLink + suraID + AudioAppConstants.Extensions.Companion.MP3
            )
        }
        return downloadLin
    }

    fun createDownloadLinks(): List<String> {
        val quranbySurah: List<QuranEntity> = Utils.Companion.getQuranbySurah(surah)
        surahselected = surah
        //   int ayaID=0;
        var counter: Int = 0
        //   quranbySurah.add(0, new QuranEntity(1, 1, 1));
        val downloadLinks: MutableList<String> = ArrayList()
        //   ayaList.add(0, new Aya(1, 1, 1));
        //loop for all page ayat
//check if readerID is 0
        if (WordbywordMushafAct.Companion.readerID == 0) {
            for (qari: Qari in readersList!!) {
                if ((qari.getName_english() == selectedqari)) {
                    WordbywordMushafAct.Companion.readerID = qari.getId()
                    WordbywordMushafAct.Companion.downloadLink = qari.getUrl()
                    break
                }
            }
        }
        for (ayaItem: QuranEntity in quranbySurah) {
            //validate if aya download or not
            if (!QuranValidateSources.validateAyaAudio(
                    this,
                    WordbywordMushafAct.Companion.readerID,
                    ayaItem.getAyah(),
                    ayaItem.getSurah()
                )
            ) {

                //create aya link
                val suraLength: Int = ayaItem.getSurah().toString().trim({ it <= ' ' }).length
                var suraID: String = ayaItem.getSurah().toString() + ""
                val ayaLength: Int = ayaItem.getAyah().toString().trim({ it <= ' ' }).length
                //   int ayaLength = String.valueOf(ayaItem.ayaID).trim().length();
                var ayaID: String  =
                    String (String ().append(ayaItem.getAyah()).append("").toString())
                if (suraLength == 1) suraID =
                    "00" + ayaItem.getSurah() else if (suraLength == 2) suraID =
                    "0" + ayaItem.getSurah()
                if (ayaLength == 1) {
                    ayaID = String ("00" + ayaItem.getAyah())
                } else if (ayaLength == 2) {
                    ayaID = String ("0" + ayaItem.getAyah())
                }
                counter++
                //add aya link to list
                //chec
                downloadLinks.add(WordbywordMushafAct.Companion.downloadLink + suraID + ayaID + AudioAppConstants.Extensions.Companion.MP3)
                Log.d(
                    "DownloadLinks",
                    WordbywordMushafAct.Companion.downloadLink + suraID + ayaID + AudioAppConstants.Extensions.Companion.MP3
                )
            }
        }
        return downloadLinks
    }

    public override fun onClick(v: View) {
        if (v === findViewById<View>(id.play)) {
            DownloadIfnotPlay()
        } else if (v === findViewById<View>(id.canceldownload)) {
            downloadFooter!!.setVisibility(View.GONE)
            //    normalFooter.setVisibility(View.VISIBLE);
            //stop flag of auto start audio after download
            WordbywordMushafAct.Companion.startBeforeDownload = false
            //stop download service
            stopService(Intent(this, DownloadService::class.java))
        }
    }

    private fun DownloadIfnotPlay() {
        val filePath: String = ""
        val internetStatus: Int = Settingsss.checkInternetStatus(this)

//https://cdn.islamic.network/quran/audio-surah/128/ar.alafasy/
        //check if there is other download in progress
        if (!Settingsss.isMyServiceRunning(this, DownloadService::class.java)) {
            //internal media play
            val Links: List<String>
            val everyayah: Boolean = true
            if (everyayah && !(audioType == 2)) {
                Links = createDownloadLinks()
            } else {
                Links = createDownloadLink()
            }
            if (Links.size != 0) {
                //check if the internet is opened
                DownLoadIfNot(internetStatus, Links as ArrayList<String>)
            } else {
                initializePlayer()
            }
        } else {
            //Other thing in download
            Toast.makeText(this, getString(string.download_busy), Toast.LENGTH_SHORT).show()
        }
    }

    private fun DownLoadIfNot(internetStatus: Int, Links: ArrayList<String>) {
        if (internetStatus <= 0) {
            val  : AlertDialog.  = AlertDialog. (this, style.MyAlertDialogStyle)
             .setCancelable(false)
             .setTitle(getResources().getString(string.Alert))
             .setMessage(getResources().getString(string.no_internet_alert))
             .setPositiveButton(
                getResources().getString(string.ok),
                object : DialogInterface.OnClickListener {
                    public override fun onClick(dialog: DialogInterface, id: Int) {
                        dialog.cancel()
                    }
                })
             .show()
        } else {
            //change view of footer to media
            //      footerContainer.setVisibility(View.VISIBLE);
            playerFooter!!.setVisibility(View.GONE)
            audioSettingBottomBehaviour!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
            //  mBottomSheetBehavior.setState(BottomSheetBehavior.STATE_EXPANDED);
            downloadFooter!!.setVisibility(View.VISIBLE)

            //check audio folders

            // String app_folder_path = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES).toString() + "/Audio/" + readerID;
            val app_folder_path: String = Environment.getExternalStoragePublicDirectory(
                Environment.DIRECTORY_DOCUMENTS
            ).toString() + "/audio/" + WordbywordMushafAct.Companion.readerID
            val f: File = File(app_folder_path)
            val path: String = f.getAbsolutePath()
            val file: File = File(path)
            if (!file.exists()) file.mkdirs()
            WordbywordMushafAct.Companion.startBeforeDownload = true
            val intent: Intent = Intent(this@WordbywordMushafAct, DownloadService::class.java)
            intent.putStringArrayListExtra(
                AudioAppConstants.Download.Companion.DOWNLOAD_LINKS,
                Links
            )
            intent.putExtra(AudioAppConstants.Download.Companion.DOWNLOAD_LOCATION, app_folder_path)
            startService(intent)
        }
    }

    public override fun onItemClick(v: View, position: Int) {
        val istag: Any = v.getTag()
        if ((istag == "verse") && singleline) {
            onClickOrRange = true
            val ayah1: Int = quranbySurahadapter!!.get(position).getAyah()
            isSingle = true
            verselected = ayah1 - 1
            ayah = ayah1 - 1
            DownloadIfnotPlay()
            isSingle = false
        }
    }

    override fun onDestroy() {
        super.onDestroy()
        releasePlayer()
        handler.removeCallbacks(SinglesendUpdatesToUI)
        if (currenttrack != 0) {
            val pref: SharedPreferences = getSharedPreferences("lastaya", MODE_PRIVATE)
            val editor: SharedPreferences.Editor = pref.edit()
            editor.putInt("lastaya", currenttrack)
            editor.putInt("trackposition", hlights.get(currenttrack)!!.get(0).getPassage())
            val ap: ArrayList<AudioPlayed> = ArrayList()
            val audioPlayed: AudioPlayed = AudioPlayed()
            audioPlayed.setSurah(surah)
            audioPlayed.setAyah(currenttrack)
            audioPlayed.setTrackposition(hlights.get(currenttrack)!!.get(0).getPassage())
            ap.add(audioPlayed)
            editor.apply()
            ConfigPreferences.setLastPlayedAudio(this, ap, surah.toString())
        }
        //unregister broadcast for download ayat
        LocalBroadcastManager.getInstance(this@WordbywordMushafAct)
            .unregisterReceiver(downloadPageAya)
        //stop flag of auto start
        WordbywordMushafAct.Companion.startBeforeDownload = false
        if (player != null) {
            player!!.release()
        }

        // finish();
    }

    public override fun onItemLongClick(position: Int, v: View) {
        val istag: Any = v.getTag()
        if ((istag == "verse") && singleline) {
            onClickOrRange = true
            val ayah1: Int = quranbySurahadapter!!.get(position).getAyah()
            ayah = ayah1
            isStartFrom = true
            verselected = ayah1 - 1
            ayah = ayah1 - 1
            DownloadIfnotPlay()
            isStartFrom = false
        }
    }

    public override fun onStart() {
        super.onStart()
        if (Util.SDK_INT > 23) {
            //   this.initializePlayer();
        }
    }

    companion object {
        private val KEY_TRACK_SELECTION_PARAMETERS: String = "track_selection_parameters"
        private val KEY_SERVER_SIDE_ADS_LOADER_STATE: String = "server_side_ads_loader_state"
        private val KEY_ITEM_INDEX: String = "item_index"
        private val KEY_POSITION: String = "position"
        private val KEY_AUTO_PLAY: String = "auto_play"

        // For ad playback only.
        val BROADCAST_SEEKBAR: String = "com.example.mushafconsolidated.Activity.sendseekbar"
        var readerID: Int = 0
        var downloadLink: String? = null
        var readerName: String? = null
        var startBeforeDownload: Boolean = false
        private val TAG: String = "ShowMushafActivity"

        //   int pos;
        private val songEnded: Int = 0
    }
}