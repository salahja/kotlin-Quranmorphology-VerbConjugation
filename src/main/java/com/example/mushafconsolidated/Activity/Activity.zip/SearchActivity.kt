package com.example.mushafconsolidated.Activity

import com.example.mushafconsolidated.Adapters.SearchAdapter


class SearchActivity : BaseActivity(), OnItemClickListener {
    private var recyclerView: RecyclerView? = null
    private var searchDownloadAdapter: SearchAdapter? = null
    private var searchView: SearchView? = null
    private val readytodownload: View? = null
    private val downloadedtranslation: View? = null
    private val backbutton: View? = null
    private var qurandictionaryArrayList: ArrayList<qurandictionary>? = null

    //  private DownloadSearchAdapter.ContactsAdapterListener contactsAdapterListener;
    private val translationDownloaded: View? = null
    private val translationReadytoDownload: View? = null
    private val view2: View? = null
    private val view1: View? = null
    private val view3: View? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == LAUNCH_SECOND_ACTIVITY) {
            if (resultCode == RESULT_OK) {
                val result = data!!.getStringExtra("result")
                if (result != null) {
                    val split =
                        result.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                    //       File file=new File(split[0]);
                    //    new InsertingTranslationFetch(TranslationActivitySearch.this).execute(split[0], split[1]);
                }
            }
            if (resultCode == RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_main)
        val toolbar = findViewById<Toolbar>(id.toolbar)
        //setSupportActionBar(toolbar);
        val display = windowManager.defaultDisplay
        val outMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density = resources.displayMetrics.density
        val dpHeight = outMetrics.heightPixels / density
        val dpWidth = outMetrics.widthPixels / density
        // toolbar fancy stuff
        supportActionBar!!.setDisplayHomeAsUpEnabled(true)
        supportActionBar!!.setTitle(string.toolbar_title)
        val utils = Utils(this)
        //   view2 = findViewById(R.id.translationReadytoDownload);
        view2!!.layoutParams.width = (dpWidth / 2).toInt()
        //   view1 = findViewById(R.id.translationDownloaded);
        //  view3 = findViewById(R.id.backButtonView);
        view1!!.layoutParams.width = (dpWidth / 2).toInt()
        view1.x = -1.0f
        //     searchDownloadAdapter = new DownloadSearchAdapter(this,translationEntity -> {});
        qurandictionaryArrayList = utils.quranDictionary
        recyclerView = findViewById(id.recycler_view)
        searchDownloadAdapter = SearchAdapter(this@SearchActivity, qurandictionaryArrayList, false)
        searchDownloadAdapter!!.SetOnItemClickListener { v, position ->
            // TranslationEntity entity = loadedTranslation.get(position);
            val entity = searchDownloadAdapter!!.getItem(position) as qurandictionary
            // View id1 =       v.findViewById(R.id.translationid);
            // View id2 =       v.findViewById(R.id.authorname);
            // View id3 =      v.findViewById(R.id.languagename);
            val bundle = Bundle()
            //   Intent intent = new Intent(getActivity(), NounOccuranceAsynKAct.class);
            val intent = Intent(this@SearchActivity, SearchResult::class.java)
            bundle.putString(Constant.QURAN_VERB_ROOT, entity.rootarabic)
            intent.putExtras(bundle)
            //   intent.putExtra(QURAN_VERB_ROOT,vb.getRoot());
            startActivity(intent)
            //   Toast.makeText(SearchActivity.this, "tobe downloaded click", Toast.LENGTH_SHORT).show();
        }
        // white background notification bar
        whiteNotificationBar(recyclerView)
        val mLayoutManager: RecyclerView.LayoutManager = LinearLayoutManager(applicationContext)
        recyclerView.setLayoutManager(mLayoutManager)
        recyclerView.setItemAnimator(DefaultItemAnimator())
        //   recyclerView.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 36));
        recyclerView.setAdapter(searchDownloadAdapter)
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        // Associate searchable configuration with the SearchView
        val searchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        searchView = menu.findItem(id.action_search)
            .actionView as SearchView?
        searchView!!.setSearchableInfo(
            searchManager
                .getSearchableInfo(componentName)
        )
        searchView!!.maxWidth = Int.MAX_VALUE
        val sear = ContextCompat.getDrawable(this, drawable.custom_search_box)
        searchView!!.clipToOutline = true
        searchView!!.setBackgroundDrawable(sear)
        searchView!!.gravity = View.TEXT_ALIGNMENT_CENTER
        searchView!!.maxWidth = Int.MAX_VALUE

        // listening to search query text change
        searchView!!.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            override fun onQueryTextSubmit(query: String): Boolean {
                // filter recycler view when query submitted
                searchDownloadAdapter!!.filter.filter(query)
                return false
            }

            override fun onQueryTextChange(query: String): Boolean {
                // filter recycler view when text is changed
                searchDownloadAdapter!!.filter.filter(query)
                return false
            }
        })
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id = item.itemId
        if (id == R.id.action_search) {
            return true
        }
        if (id == R.id.backButtonView) {
            val rintent = Intent(this@SearchActivity, QuranGrammarAct::class.java)
            startActivity(rintent)
            finish()
        }
        val rintent = Intent(this@SearchActivity, QuranGrammarAct::class.java)
        startActivity(rintent)
        finish()
        //return super.onOptionsItemSelected(item);
        return true
    }

    override fun onBackPressed() {
        finish()
        if (!searchView!!.isIconified) {
            searchView!!.isIconified = true
            return
        }
        super.onBackPressed()
    }

    private fun whiteNotificationBar(view: View?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var flags = view!!.systemUiVisibility
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            view.systemUiVisibility = flags
            window.statusBarColor = Color.WHITE
        }
    }

    override fun onItemClick(v: View?, position: Int) {
        Toast.makeText(this, "back", Toast.LENGTH_SHORT).show()
        // Toast.makeText(getApplicationContext(), "Selected: " + translationEntity.getLanguage_name()+ ", " + translationEntity.getLanguage_name(), Toast.LENGTH_LONG).show();
    }

    companion object {
        private const val LAUNCH_SECOND_ACTIVITY = 1
        private val TAG = MainActivity::class.java.simpleName

        // url to fetch contacts json
        private const val URL = "https://api.androidhive.info/json/contacts.json"
    }
}