package com.example.mushafconsolidated.Activity

import QuranEntity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.util.Pair
import android.view.KeyEvent
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

import com.example.mushafconsolidated.R

import com.example.mushafconsolidated.receiversimport.FileManager
import com.example.mushafconsolidatedimport.Utils
import com.google.android.exoplayer2.C
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.PlaybackException
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.Tracks
import com.google.android.exoplayer2.audio.AudioAttributes
import com.google.android.exoplayer2.mediacodec.MediaCodecRenderer.DecoderInitializationException
import com.google.android.exoplayer2.mediacodec.MediaCodecUtil.DecoderQueryException
import com.google.android.exoplayer2.source.ads.AdsLoader
import com.google.android.exoplayer2.trackselection.TrackSelectionParameters
import com.google.android.exoplayer2.ui.StyledPlayerView
import com.google.android.exoplayer2.ui.StyledPlayerView.ControllerVisibilityListener
import com.google.android.exoplayer2.ui.StyledPlayerView.FullscreenButtonClickListener
import com.google.android.exoplayer2.util.DebugTextViewHelper
import com.google.android.exoplayer2.util.ErrorMessageProvider
import com.google.android.exoplayer2.util.EventLogger
import java.util.Objects



/** An activity that plays media using [ExoPlayer].  */
class PlayerActivity : AppCompatActivity(), View.OnClickListener,
    ControllerVisibilityListener, FullscreenButtonClickListener {
    protected lateinit var playerView: StyledPlayerView
    protected var debugRootView: LinearLayout? = null
    protected var debugTextView: TextView? = null
    protected var player: ExoPlayer? = null
    private var trackSelectionParameters: TrackSelectionParameters? = null
    private var debugViewHelper: DebugTextViewHelper? = null
    private var lastSeenTracks: Tracks? = null
    private var startAutoPlay = false
    private var startItemIndex = 0
    private var startPosition: Long = 0

    // For ad playback only.
    private var clientSideAdsLoader: AdsLoader? = null
    private var marray: MutableList<MediaItem>? = null

    // TODO: Annotate this and serverSideAdsLoaderState below with @OptIn when it can be applied to
    // fields (needs http://r.android.com/2004032 to be released into a version of
    // androidx.annotation:annotation-experimental).
    // Activity lifecycle.
    public override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //  dataSourceFactory = DemoUtil.getDataSourceFactory(/* context= */ this);
        setContentView()
        debugRootView = findViewById(R.id.controls_root)
        debugTextView = findViewById(R.id.debug_text_view)
        val selectTracksButton = findViewById<Button>(R.id.select_tracks_button)
        selectTracksButton.setOnClickListener(this)
        playerView = findViewById(R.id.player_view)
        playerView.setControllerVisibilityListener(this)
        playerView.setErrorMessageProvider(PlayerErrorMessageProvider())
        playerView.requestFocus()
        if (savedInstanceState != null) {
            trackSelectionParameters = TrackSelectionParameters.fromBundle(
                savedInstanceState.getBundle(KEY_TRACK_SELECTION_PARAMETERS)!!
            )
            startAutoPlay = savedInstanceState.getBoolean(KEY_AUTO_PLAY)
            startItemIndex = savedInstanceState.getInt(KEY_ITEM_INDEX)
            startPosition = savedInstanceState.getLong(KEY_POSITION)
        } else {
            trackSelectionParameters = TrackSelectionParameters.Builder( /* context= */this).build()
            clearStartPosition()
        }
    }

    public override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        releasePlayer()
        releaseClientSideAdsLoader()
        clearStartPosition()
        setIntent(intent)
    }

    public override fun onStart() {
        super.onStart()
        initializePlayer()
        if (playerView != null) {
            playerView!!.onResume()
        }
    }

    public override fun onResume() {
        super.onResume()
        if (player == null) {
            initializePlayer()
            if (playerView != null) {
                playerView!!.onResume()
            }
        }
    }

    public override fun onPause() {
        super.onPause()
    }

    public override fun onStop() {
        super.onStop()
        if (playerView != null) {
            playerView!!.onPause()
        }
        releasePlayer()
    }

    public override fun onDestroy() {
        super.onDestroy()
        releaseClientSideAdsLoader()
    }

    override fun onRequestPermissionsResult(
        requestCode: Int, permissions: Array<String>, grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (grantResults.size == 0) {
            // Empty results are triggered if a permission is requested while another request was already
            // pending and can be safely ignored in this case.
            return
        }
        if (grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            initializePlayer()
        } else {
            showToast(R.string.storage_permission_denied)
            finish()
        }
    }

    public override fun onSaveInstanceState(outState: Bundle) {
        super.onSaveInstanceState(outState)
        updateTrackSelectorParameters()
        updateStartPosition()
        outState.putBundle(KEY_TRACK_SELECTION_PARAMETERS, trackSelectionParameters!!.toBundle())
        outState.putBoolean(KEY_AUTO_PLAY, startAutoPlay)
        outState.putInt(KEY_ITEM_INDEX, startItemIndex)
        outState.putLong(KEY_POSITION, startPosition)
    }

    // Activity input
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        // See whether the player view wants to handle media or DPAD keys events.
        return playerView!!.dispatchKeyEvent(event) || super.dispatchKeyEvent(event)
    }

    // OnClickListener methods
    // StyledPlayerView.ControllerVisibilityListener implementation
    override fun onVisibilityChanged(visibility: Int) {
        debugRootView!!.visibility = visibility
    }

    // Internal methods
    protected fun setContentView() {
        setContentView(R.layout.ex_player_vtwo)
    }

    /**
     * @return Whether initialization was successful.
     */
    protected fun initializePlayer(): Boolean {
        if (player == null) {
            createPlaylist()
            marray = createMediaItems()
            if (marray!!.isEmpty()) {
                return false
            }
            player = ExoPlayer.Builder(this).build()
            lastSeenTracks = Tracks.EMPTY
            //     ExoPlayer.Builder playerBuilder=new ExoPlayer.Builder((Context) this);
            /*     ExoPlayer.Builder playerBuilder =new ExoPlayer.Builder(*/ /* context= */ /* this)
                            .setMediaSourceFactory(createMediaSourceFactory());
            setRenderersFactory(
                    playerBuilder, intent.getBooleanExtra(IntentUtil.PREFER_EXTENSION_DECODERS_EXTRA, false));*/
            //     player = playerBuilder.build();
            player!!.addListener(PlayerEventListener())
            player!!.trackSelectionParameters = trackSelectionParameters!!
            player!!.addListener(PlayerEventListener())
            player!!.addAnalyticsListener(EventLogger())
            player!!.setAudioAttributes(AudioAttributes.DEFAULT,  /* handleAudioFocus= */true)
            player!!.playWhenReady = startAutoPlay
            val currentItem = 0
            val playbackPosition = 0L
            player!!.seekTo(currentItem, playbackPosition)
            playerView!!.player = player
            debugViewHelper = DebugTextViewHelper(player!!, debugTextView!!)
            debugViewHelper!!.start()
        }
        val haveStartPosition = startItemIndex != C.INDEX_UNSET
        if (haveStartPosition) {
            player!!.seekTo(startItemIndex, startPosition)
        }
        player!!.setMediaItems(marray!!,  /* resetPosition= */!haveStartPosition)
        player!!.prepare()
        //updateButtonVisibility();
        return true
    }

    fun createPlaylist(): List<String> {
        val quranbySurah: List<QuranEntity?>? = Utils.getQuranbySurah(9)
        val downloadLinks: List<String> = ArrayList()
        //   ayaList.add(0, new Aya(1, 1, 1));
        //loop for all page ayat
        val ayaLocations: MutableList<String> = ArrayList()
        val marray = ArrayList<MediaItem>()
        //Create files locations for the all page ayas
        if (quranbySurah != null) {
            for (ayaItem in quranbySurah) {
                if (ayaItem != null) {
                    ayaLocations.add(
                        FileManager.createAyaAudioLinkLocation(
                            this,
                            20,
                            ayaItem.ayah,
                            ayaItem.surah
                        )
                    )
                }
                val location: String = ayaItem?.let {
                    FileManager.createAyaAudioLinkLocation(
                        this,
                        20,
                        ayaItem.ayah,
                        it.surah
                    )
                }.toString()
                marray.add(MediaItem.fromUri(location))
            }
        }
        return downloadLinks
    }

    protected fun releasePlayer() {
        if (player != null) {
            updateTrackSelectorParameters()
            updateStartPosition()
            //   releaseServerSideAdsLoader();
            debugViewHelper!!.stop()
            debugViewHelper = null
            player!!.release()
            player = null
            playerView!!.player = null
        }
        if (clientSideAdsLoader != null) {
            clientSideAdsLoader!!.setPlayer(null)
        } else {
            Objects.requireNonNull(playerView!!.adViewGroup).removeAllViews()
        }
    }

    private fun releaseClientSideAdsLoader() {
        if (clientSideAdsLoader != null) {
            clientSideAdsLoader!!.release()
            clientSideAdsLoader = null
            Objects.requireNonNull(playerView!!.adViewGroup).removeAllViews()
        }
    }

    private fun updateTrackSelectorParameters() {
        if (player != null) {
            trackSelectionParameters = player!!.trackSelectionParameters
        }
    }

    private fun updateStartPosition() {
        if (player != null) {
            startAutoPlay = player!!.playWhenReady
            startItemIndex = player!!.currentMediaItemIndex
            startPosition = Math.max(0, player!!.contentPosition)
        }
    }

    protected fun clearStartPosition() {
        startAutoPlay = true
        startItemIndex = C.INDEX_UNSET
        startPosition = C.TIME_UNSET
    }

    // User controls
    private fun showControls() {
        debugRootView!!.visibility = View.VISIBLE
    }

    override fun onTitleChanged(title: CharSequence, color: Int) {
        super.onTitleChanged(title, color)
    }

    private fun showToast(messageId: Int) {
        showToast(getString(messageId))
    }

    private fun showToast(message: String) {
        Toast.makeText(applicationContext, message, Toast.LENGTH_LONG).show()
    }

    override fun onClick(v: View) {}
    override fun onFullscreenButtonClick(isFullScreen: Boolean) {}
    private inner class PlayerEventListener : Player.Listener {
        override fun onPlaybackStateChanged(playbackState: @Player.State Int) {
            if (playbackState == Player.STATE_ENDED) {
                showControls()
            }
            //     updateButtonVisibility();
        }

        override fun onPlayerError(error: PlaybackException) {
            if (error.errorCode == PlaybackException.ERROR_CODE_BEHIND_LIVE_WINDOW) {
                assert(player != null)
                player!!.seekToDefaultPosition()
                player!!.prepare()
            } else {
                //     updateButtonVisibility();
                showControls()
            }
        }

        override fun onTracksChanged(tracks: Tracks) {
            //   updateButtonVisibility();
            assert(player != null)
            val ayah = player!!.currentMediaItemIndex
            println("Ayah$ayah")
            if (tracks === lastSeenTracks) {
                return
            }
            if (tracks.containsType(C.TRACK_TYPE_AUDIO)
                && !tracks.isTypeSupported(C.TRACK_TYPE_AUDIO,  /* allowExceedsCapabilities= */true)
            ) {
                showToast(R.string.error_unsupported_audio)
            }
            lastSeenTracks = tracks
        }
    }

    private inner class PlayerErrorMessageProvider :
        ErrorMessageProvider<PlaybackException> {
        override fun getErrorMessage(e: PlaybackException): Pair<Int, String> {
            var errorString = getString(R.string.error_generic)
            val cause = e.cause
            if (cause is DecoderInitializationException) {
                // Special case for decoder initialization failures.
                val decoderInitializationException = cause
                errorString = if (decoderInitializationException.codecInfo == null) {
                    if (decoderInitializationException.cause is DecoderQueryException) {
                        getString(R.string.error_querying_decoders)
                    } else if (decoderInitializationException.secureDecoderRequired) {
                        getString(
                            R.string.error_no_secure_decoder,
                            decoderInitializationException.mimeType
                        )
                    } else {
                        getString(
                            R.string.error_no_decoder,
                            decoderInitializationException.mimeType
                        )
                    }
                } else {
                    getString(
                        R.string.error_instantiating_decoder,
                        decoderInitializationException.codecInfo!!.name
                    )
                }
            }
            return Pair.create(0, errorString)
        }
    }

    private fun createMediaItems(): MutableList<MediaItem> {
        val quranbySurah: List<QuranEntity?>? = Utils.getQuranbySurah(9)

        //   int ayaID=0;
        //   quranbySurah.add(0, new QuranEntity(1, 1, 1));
        //   ayaList.add(0, new Aya(1, 1, 1));
        //loop for all page ayat
        val ayaLocations: MutableList<String> = ArrayList()
        marray = ArrayList()
        //Create files locations for the all page ayas
        if (quranbySurah != null) {
            for (ayaItem in quranbySurah) {
                ayaLocations.add(
                    FileManager.createAyaAudioLinkLocation(
                        this,
                        20,
                        ayaItem!!.ayah,
                        ayaItem.surah
                    )
                )
                val location: String = FileManager.createAyaAudioLinkLocation(
                    this,
                    20,
                    ayaItem.ayah,
                    ayaItem.surah
                )
                (marray as ArrayList<MediaItem>).add(MediaItem.fromUri(location))
            }
        }
        return marray as ArrayList<MediaItem>
    }

    companion object {
        // Saved instance state keys.
        private const val KEY_TRACK_SELECTION_PARAMETERS = "track_selection_parameters"
        private const val KEY_ITEM_INDEX = "item_index"
        private const val KEY_POSITION = "position"
        private const val KEY_AUTO_PLAY = "auto_play"
    }
}