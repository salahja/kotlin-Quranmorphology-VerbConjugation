package com.example.mushafconsolidated.Activityimport

import CorpusNounWbwOccurance


class WordDictionaryAct constructor() : BaseActivity() {
    private val languages: Array<String?> = arrayOfNulls(10)
    var corpusNounWbwOccurances: ArrayList<CorpusNounWbwOccurance>? = null
    var expandableListView: ExpandableListView? = null
    var viewPager2: ViewPager2? = null
    var isHarf: Boolean = false
    var expandNounTitles: MutableList<String>? = null
    var expandVerbTitles: List<String>? = null
    var mPageNo: Int = 0
    var expandableListDetail: LinkedHashMap<String, List<String>>? = null
    var imgPg: ImageView? = null
    var link: TextView? = null
    var root: String? = null
    var counter: Int = 0
    var dialog: AlertDialog? = null
    var isarabicword: Boolean = false
    var islanes: Boolean = false
    var ishans: Boolean = false
    var updatechild: LinkedHashMap<String, List<SpannableString>> = LinkedHashMap()
    var expandNounVerses: LinkedHashMap<String, List<SpannableString>> = LinkedHashMap()
    var expandVerbVerses: LinkedHashMap<String, List<SpannableString>> = LinkedHashMap()
    var utils: Utils? = null
    var tv: TextView? = null
    var progressBar: ProgressBar? = null
    var firstcolortat: Int = 0
    var maincolortag: Int = 0
    var pronouncolortag: Int = 0
    var fourcolortag: Int = 0
    private val str2: String? = null
    private val LL: RelativeLayout? = null
    private var dataBundle: Bundle? = null
    private val materialToolbar: MaterialToolbar? = null
    private val jumpto: MenuItem? = null
    private val progressBar1: ProgressBar? = null
    private val childfile: File? = null
    private val databasepath: String? = null
    private val mainDatabasesZIP: File? = null
    private val targetDirectory: File? = null
    private val `is`: FileInputStream? = null
    private val zis: ZipInputStream? = null
    private val ze: ZipEntry? = null
    private val filename: String? = null
    private var verbCorpusArrayList: ArrayList<VerbCorpusBreakup>? = null
    private var occurances: ArrayList<CorpusNounWbwOccurance>? = null
    private var nounCorpusArrayList: ArrayList<NounCorpusBreakup>? = null
    private var isUnaugmentedWazan: Boolean = false
    private var isAugmentedWazan: Boolean = false
    private var isnoconjugation: Boolean = false
    private var isonlyarabicword: Boolean = false
    private var isMajzoom: Boolean = false
    private var isMansub: Boolean = false
    private var isnoun: Boolean = false
    private var isrelative: Boolean = false
    private var isdem: Boolean = false
    private var isprep: Boolean = false
    private var isharfnasab: Boolean = false
    private var isShart: Boolean = false
    private var isHarf: Boolean = false
    private var nouncase: String? = null
    private var isIsmMarfu: Boolean = false
    private var isIsmMansub: Boolean = false
    private var isIsmMajroor: Boolean = false
    private var ismujarrad: Boolean = false
    private var ismazeed: Boolean = false
    private val parentLayoutManager: LinearLayoutManager? = null
    private var shared: SharedPreferences? = null
    private val recview: RecyclerView? = null
    private val progressBarDD: ProgressDialog? = null
    private val progressBarStatus: Int = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.expand_list)
        //   recview=findViewById(R.id.recyclerView);
        //  parentLayoutManager = new LinearLayoutManager(WordOccuranceAsynKAct.this);
        val bundle: Bundle? = getIntent().getExtras()
        expandableListView = findViewById<View>(id.expandableListView) as ExpandableListView?
        root = bundle!!.getString(Constant.QURAN_VERB_ROOT)
        utils = Utils(this@WordDictionaryAct)
        //
        dataBundle = Bundle()
        bundle.getParcelableArray("dictionary")
        var conjugationroot: String? = bundle.getString(Constant.QURAN_VERB_ROOT)
        val vocubaluryroot: String? = bundle.getString(Constant.QURAN_VERB_ROOT)
        val verbformthulathi: String? = bundle.getString(Constant.QURAN_VERB_WAZAN)
        var verbtype: String? = bundle.getString(Constant.VERBTYPE)
        val ss: String = conjugationroot!!.replace("[\\[\\]]".toRegex(), "")
        var verbroot: String = ss.replace("[,;\\s]".toRegex(), "")
        val starts: Int = conjugationroot.indexOf(ArabicLiterals.LALIF)
        val hamza: String = "ء"
        if (starts != -1) {
            conjugationroot =
                conjugationroot.replace(ArabicLiterals.LALIF, hamza.trim({ it <= ' ' }))
        }
        var verbform: String? = null
        var verbmood: String? = null
        var arabicword: String? = null
        if (bundle.getString("nouncase") != null) {
            nouncase = bundle.getString(Constant.NOUNCASE)
            isnoun = true
            when (nouncase) {
                "NOM" -> isIsmMarfu = true
                "ACC" -> isIsmMansub = true
                "GEN" -> isIsmMajroor = true
            }
        }
        verbform = bundle.getString(Constant.QURAN_VERB_WAZAN)
        verbmood = bundle.getString(Constant.VERBMOOD)
        verbtype = bundle.getString(Constant.VERBTYPE)
        arabicword = bundle.getString("arabicword")
        if (arabicword!!.isEmpty()) {
            arabicword = bundle.getString("root")
        }
        isharfnasab = bundle.getBoolean(Constant.ACCUSATIVE, false)
        isdem = bundle.getBoolean(Constant.DEMONSTRATIVE, false)
        isrelative = bundle.getBoolean(Constant.RELATIVE, false)
        isShart = bundle.getBoolean(Constant.CONDITIONAL, false)
        isprep = bundle.getBoolean(Constant.PREPOSITION, false)
        isHarf = isShart == isrelative == isharfnasab == isprep == isdem
        try {
            if ((verbmood == "Jussive")) {
                isMajzoom = true
            } else if ((verbmood == "Subjunctive")) {
                isMansub = true
            }
        } catch (e: NullPointerException) {
            println(e.message)
        }
        if ((verbtype == "mujarrad")) {
            ismujarrad = true
        } else if ((verbtype == "mazeed")) {
            ismazeed = true
        } else {
            ismujarrad = false
            ismazeed = false
        }
        if (arabicword!!.length == 0) {
            try {
                if ((verbtype == "mujarrad")) {
                    isUnaugmentedWazan = true
                    //    setLanguage("lanes");
                } else if ((verbtype == "mazeed")) {
                    isAugmentedWazan = true
                    //   setLanguage("lanes");
                } else {
                    isnoconjugation = true
                    //     setLanguage("english");
                }
            } catch (e: Exception) {
                // dataBundle.putString(QURAN_VOCUBALORY_ROOT, vocubaluryroot);
                //  dataBundle.putString(QURAN_VERB_WAZAN, verbformthulathi);
                //    dataBundle.putSerializable(QURAN_VERB_ROOT, conjugationroot);
                isUnaugmentedWazan = true
                //    setLanguage("lanes");
            }
        } else {
            isonlyarabicword = true
            //   dataBundle.putString("arabicword", arabicword);
            //  dataBundle.putString(QURAN_VERB_WAZAN, "");
            // dataBundle.putSerializable(QURAN_VERB_ROOT, "");
            isnoconjugation = false
            //    setLanguage("english");
        }
        if (isIsmMarfu) {
            languages.get(0) = "lanes"
            languages.get(1) = "hans"
            languages.get(2) = "english"
            languages.get(3) = "urdu"
            languages.get(4) = "genetivenoun"
            expandableListDetail = LinkedHashMap()
            val indexOfHamza: Int = verbroot.indexOf(ArabicLiterals.Hamza)
            if (indexOfHamza != -1) {
                verbroot = verbroot.replace(ArabicLiterals.Hamza.toRegex(), ArabicLiterals.LALIF)
            }
            //lanes dictionary
            getLanes(verbroot)
            getHans(verbroot)
            var dictionary: ArrayList<lughat> = ArrayList()
            dictionary = utils!!.getRootDictionary(arabicword)
            if (!dictionary.isEmpty()) {
                isarabicword = true
                val en_lughat: String = dictionary.get(0).getEn_lughat()
                val ur_lughat: String = dictionary.get(0).getUr_lughat()
                expandableListDetail!!.put("english", listOf(en_lughat))
                expandableListDetail!!.put("Urdu", listOf(ur_lughat))
            }
            //nominativenouns/mansubism
            selectedIsm
            displayAdapter()
        } else if (isIsmMansub) {
            languages.get(0) = "lanes"
            languages.get(1) = "hans"
            languages.get(2) = "english"
            languages.get(3) = "urdu"
            languages.get(4) = "accusativenoun"
            expandableListDetail = LinkedHashMap()
            val indexOfHamza: Int = verbroot.indexOf(ArabicLiterals.Hamza)
            if (indexOfHamza != -1) {
                verbroot = verbroot.replace(ArabicLiterals.Hamza.toRegex(), ArabicLiterals.LALIF)
            }
            //lanes dictionary
            getLanes(verbroot)
            getHans(verbroot)
            var dictionary: ArrayList<lughat> = ArrayList()
            dictionary = utils!!.getRootDictionary(arabicword)
            if (!dictionary.isEmpty()) {
                isarabicword = true
                val en_lughat: String = dictionary.get(0).getEn_lughat()
                val ur_lughat: String = dictionary.get(0).getUr_lughat()
                expandableListDetail!!.put("english", listOf(en_lughat))
                expandableListDetail!!.put("Urdu", listOf(ur_lughat))
            }
            //nominativenouns/mansubism
            selectedIsm
            displayAdapter()
        } else if (isIsmMajroor) {
            languages.get(0) = "lanes"
            languages.get(1) = "hans"
            languages.get(2) = "english"
            languages.get(3) = "urdu"
            languages.get(4) = "nominativenoun"
            expandableListDetail = LinkedHashMap()
            val indexOfHamza: Int = verbroot.indexOf(ArabicLiterals.Hamza)
            if (indexOfHamza != -1) {
                verbroot = verbroot.replace(ArabicLiterals.Hamza.toRegex(), ArabicLiterals.LALIF)
            }
            //lanes dictionary
            getLanes(verbroot)
            getHans(verbroot)
            var dictionary: ArrayList<lughat> = ArrayList()
            dictionary = utils!!.getRootDictionary(arabicword)
            if (!dictionary.isEmpty()) {
                isarabicword = true
                val en_lughat: String = dictionary.get(0).getEn_lughat()
                val ur_lughat: String = dictionary.get(0).getUr_lughat()
                expandableListDetail!!.put("english", listOf(en_lughat))
                expandableListDetail!!.put("Urdu", listOf(ur_lughat))
            }
            //nominativenouns/mansubism
            selectedIsm
            displayAdapter()
        } else if (ismujarrad) {
            if ((SharedPref.getLanguage() == "en") && (verbmood == "Jussive")) {
                languages.get(0) = "lanes"
                languages.get(1) = "hans"
                languages.get(2) = "english"
                languages.get(3) = "urdu"
                languages.get(4) = "Jussive"
                expandableListDetail = LinkedHashMap()
                val indexOfHamza: Int = verbroot.indexOf(ArabicLiterals.Hamza)
                if (indexOfHamza != -1) {
                    verbroot =
                        verbroot.replace(ArabicLiterals.Hamza.toRegex(), ArabicLiterals.LALIF)
                }
                //lanes dictionary
                getLanes(verbroot)
                getHans(verbroot)
                var dictionary: ArrayList<lughat> = ArrayList()
                dictionary = utils!!.getRootDictionary(arabicword)
                if (!dictionary.isEmpty()) {
                    isarabicword = true
                    val en_lughat: String = dictionary.get(0).getEn_lughat()
                    val ur_lughat: String = dictionary.get(0).getUr_lughat()
                    expandableListDetail!!.put("english", listOf(en_lughat))
                    expandableListDetail!!.put("Urdu", listOf(ur_lughat))
                }
                //nominativenouns/mansubism
                val jazam: ArrayList<GrammarRules> = utils!!.getGrammarRulesByRules("jazam")
                val jussiveverb: String = jazam.get(0).getDetailsrules()
                expandableListDetail!!.put("Majzuum", listOf(jussiveverb))
                displayAdapter()
            } else if ((SharedPref.getLanguage() == "en") && (verbmood == "Subjunctive")) {
                languages.get(0) = "lanes"
                languages.get(1) = "hans"
                languages.get(2) = "english"
                languages.get(3) = "urdu"
                languages.get(4) = "Subjunctive"
                expandableListDetail = LinkedHashMap()
                val indexOfHamza: Int = verbroot.indexOf(ArabicLiterals.Hamza)
                if (indexOfHamza != -1) {
                    verbroot =
                        verbroot.replace(ArabicLiterals.Hamza.toRegex(), ArabicLiterals.LALIF)
                }
                //lanes dictionary
                getLanes(verbroot)
                getHans(verbroot)
                var dictionary: ArrayList<lughat> = ArrayList()
                dictionary = utils!!.getRootDictionary(arabicword)
                if (!dictionary.isEmpty()) {
                    isarabicword = true
                    val en_lughat: String = dictionary.get(0).getEn_lughat()
                    val ur_lughat: String = dictionary.get(0).getUr_lughat()
                    expandableListDetail!!.put("english", listOf(en_lughat))
                    expandableListDetail!!.put("Urdu", listOf(ur_lughat))
                }
                //nominativenouns/mansubism
                val nasab: ArrayList<GrammarRules> = utils!!.getGrammarRulesByRules("nasab")
                val nasabverb: String = nasab.get(0).getDetailsrules()
                expandableListDetail!!.put("MansUB", listOf(nasabverb))
                displayAdapter()
            } else if ((SharedPref.getLanguage() == "en") && (verbmood == "Indicative")) {
                languages.get(0) = "lanes"
                languages.get(1) = "hans"
                languages.get(2) = "english"
                languages.get(3) = "urdu"
                expandableListDetail = LinkedHashMap()
                val indexOfHamza: Int = verbroot.indexOf(ArabicLiterals.Hamza)
                if (indexOfHamza != -1) {
                    verbroot =
                        verbroot.replace(ArabicLiterals.Hamza.toRegex(), ArabicLiterals.LALIF)
                }
                //lanes dictionary
                getLanes(verbroot)
                getHans(verbroot)
                var dictionary: ArrayList<lughat> = ArrayList()
                dictionary = utils!!.getRootDictionary(arabicword)
                if (!dictionary.isEmpty()) {
                    isarabicword = true
                    val en_lughat: String = dictionary.get(0).getEn_lughat()
                    val ur_lughat: String = dictionary.get(0).getUr_lughat()
                    expandableListDetail!!.put("english", listOf(en_lughat))
                    expandableListDetail!!.put("Urdu", listOf(ur_lughat))
                }
                //nominativenouns/mansubism
                displayAdapter()
            }
        } else if (isAugmentedWazan) {
            if ((SharedPref.getLanguage() == "en") && (verbmood == "Jussive")) {
                languages.get(0) = "lanes"
                languages.get(1) = "hans"
                languages.get(2) = "english"
                languages.get(3) = "urdu"
                languages.get(4) = "Jussive"
            } else if ((SharedPref.getLanguage() == "en") && (verbmood == "Subjunctive")) {
                languages.get(0) = "lanes"
                languages.get(1) = "hans"
                languages.get(2) = "english"
                languages.get(3) = "urdu"
                languages.get(4) = "Subjunctive"
            } else {
                languages.get(0) = "lanes"
                languages.get(1) = "hans"
                languages.get(2) = "english"
                languages.get(3) = "urdu"
            }
        } else if (isonlyarabicword && isrelative) {
            languages.get(0) = "english"
            languages.get(1) = "urdu"
            languages.get(2) = "relative"
        } else if (isonlyarabicword && isdem) {
            languages.get(0) = "english"
            languages.get(1) = "urdu"
            languages.get(2) = "demonstrative"
        } else if (isonlyarabicword && isharfnasab) {
            languages.get(0) = "english"
            languages.get(1) = "urdu"
            languages.get(2) = "accusative"
        } else if (isonlyarabicword && isShart) {
            languages.get(0) = "english"
            languages.get(1) = "urdu"
            languages.get(2) = "conditonal"
        } else if (isonlyarabicword && isprep) {
            languages.get(0) = "english"
            languages.get(1) = "urdu"
            languages.get(2) = "preposition"
        } else if (isnoconjugation) {
            languages.get(0) = "lanes"
            languages.get(1) = "hans"
            languages.get(2) = "english"
            languages.get(3) = "urdu"
        }
        // String preferences = SharedPref.themePreferences();
        val  : AlertDialog.  = AlertDialog. (this)
         .setCancelable(false) // if you want user to wait for some process to finish,
         .setView(R.layout.layout_loading_dialog)
        dialog =  .create()
        shared = PreferenceManager.getDefaultSharedPreferences(this)
        val whichtranslation: String? = shared.getString("selecttranslation", "en_sahih")
        val showtranslation: Boolean = shared.getBoolean("prefs_show_translation", true)
        expandableListView = findViewById<View>(id.expandableListView) as ExpandableListView?
        val prefs: SharedPreferences =
            android.preference.PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
        val preferences: String? = prefs.getString("theme", "dark")
        if ((preferences == "dark")) {
            firstcolortat = Constant.BCYAN
            maincolortag = Constant.BYELLOW
            pronouncolortag = Constant.BBLUE
            fourcolortag = Constant.BWHITE
        } else {
            firstcolortat = Constant.WBURNTUMBER
            maincolortag =
                ContextCompat.getColor(QuranGrammarApplication.getContext(), color.prussianblue)
            pronouncolortag = Constant.WMIDNIHTBLUE
            fourcolortag = Constant.GREENDARK
        }
        val callBackbutton: FloatingTextButton = findViewById(id.action_button)
        val pref: String = "dark"
        if ((pref == "dark")) {
            val color: Int = getResources().getColor(color.color_background_overlay)
            callBackbutton.setBackgroundColor(color)
        } else {
            callBackbutton.setBackgroundColor(getResources().getColor(color.color_background))
        }
        callBackbutton.setOnClickListener(View.OnClickListener({ view: View? ->
            //  Intent quranintnt = new Intent(VerbOccuranceAsynKAct.this, ReadingSurahPartActivity.class);
            finish()
        }))
        if ((root == "ACC") || (root == "LOC") || (root == "T")) {
            occurances = utils!!.getnounoccuranceHarfNasbZarf(root)
            this.isHarf = true
            ExecuteNounOcurrance()
        } else {
            this.isHarf = false
            //    ExecuteNounOcurrance();
        }
    }

    private fun displayAdapter() {
        val wordAnalysisListAdapter: WordAnalysisListAdapter
        val expandableListTitle: ArrayList<String> = ArrayList(
            expandableListDetail!!.keys
        )
        wordAnalysisListAdapter =
            WordAnalysisListAdapter(this, expandableListTitle, expandableListDetail)
        expandableListView!!.setAdapter(wordAnalysisListAdapter)
        for (i in 0 until wordAnalysisListAdapter.getGroupCount()) {
            expandableListView!!.expandGroup(i)
        }
    }

    private val selectedIsm: Unit
        private get() {
            if (isIsmMarfu) {
                val ismmarfu: ArrayList<GrammarRules> = utils!!.getGrammarRulesByRules("nomnouns")
                val ismmarfustr: String = ismmarfu.get(0).getDetailsrules()
                expandableListDetail!!.put("IsmMarfu", listOf(ismmarfustr))
            } else if (isIsmMansub) {
                val ismmansub: ArrayList<GrammarRules> =
                    utils!!.getGrammarRulesByRules("accusativenoun")
                val ismmarfustr: String = ismmansub.get(0).getDetailsrules()
                expandableListDetail!!.put("IsmMansub", listOf(ismmarfustr))
            } else if (isIsmMajroor) {
                val ismmansub: ArrayList<GrammarRules> =
                    utils!!.getGrammarRulesByRules("genetivenoun")
                val ismmarfustr: String = ismmansub.get(0).getDetailsrules()
                expandableListDetail!!.put("IsmMajroor", listOf(ismmarfustr))
            }
        }

    private fun getHans(verbroot: String) {
        var verbroot: String = verbroot
        val probableRoot: String = verbroot
        val hanesDefinition: MutableList<String> = ArrayList()
        val C2: Char = verbroot.get(1)
        val C3: Char = verbroot.get(2)
        val c1: Char = verbroot.get(0)
        if ((verbroot == "يدي")) {
            verbroot = verbroot.substring(0, 2)
        } else if ((verbroot == "ايي")) {
            verbroot = "آي"
        } else if ((Character.toString(C3) == ArabicLiterals.Ya)) {
            verbroot = verbroot.replace(ArabicLiterals.Ya, ArabicLiterals.AlifMaksuraString)
        } else if ((Character.toString(C3) == ArabicLiterals.LALIF)) {
            verbroot =
                verbroot.replace(ArabicLiterals.LALIF, ArabicLiterals.Hamza) //change alif to hamza
        } else if ((Character.toString(C2) == Character.toString(C3))) {
            verbroot = verbroot.substring(0, 2) //contract the double at end
        }
        if ((Character.toString(c1) == ArabicLiterals.Hamza)) {
            verbroot = verbroot.replace(ArabicLiterals.Hamza, ArabicLiterals.LALIF)
        }
        val hanssb: String  = String ()
        var hansdictionary: ArrayList<hanslexicon> = utils!!.getHansDifinition(verbroot)
        if (hansdictionary.isEmpty()) {
            hansdictionary = utils!!.getHansDifinition(probableRoot)
        }
        if (!hansdictionary.isEmpty()) ishans = true
        hanssb.append(Constant.html)
        for (lanes: hanslexicon in hansdictionary) {
            //  <p style="margin-left:200px; margin-right:50px;">
            hanssb.append("<p style=\"margin-left:10px; margin-right:10px;\">")
            hanssb.append(lanes.getDefinition()).append("</p>")
            hanssb.append("<hr size=\"1\" width=\"100%\" color=\"red\">  ")
        }
        hanssb.append("</html")
        hanesDefinition.add(hanssb.toString())
        expandableListDetail!!.put("hans", hanesDefinition)
    }

    private fun getLanes(verbroot: String) {
        var verbroot: String = verbroot
        val lanesDefinition: MutableList<String> = ArrayList()
        val difinition : String  = String ()
        val C2: Char = verbroot.get(1)
        val C3: Char = verbroot.get(2)
        if ((verbroot == "يدي")) {
            verbroot = verbroot.substring(0, 2)
        } else if ((verbroot == "حيي")) {
        } else if ((verbroot == "ايي")) {
            verbroot = "اى"
        } else if ((C3.toString() == ArabicLiterals.Ya)) {
            verbroot = verbroot.replace(ArabicLiterals.Ya, ArabicLiterals.AlifMaksuraString)
        } else if ((C3.toString() == ArabicLiterals.LALIF)) {
            verbroot = verbroot.replace(ArabicLiterals.LALIF, ArabicLiterals.AlifHamzaAbove)
        } else if ((C2.toString() == C3.toString())) {
            verbroot = verbroot.substring(0, 2)
        }
        val lanesdictionary: ArrayList<lanelexicon> = utils!!.getLanesDifinition(verbroot)
        if (!lanesdictionary.isEmpty()) islanes = true
        //  <p style="margin-left:200px; margin-right:50px;">
        difinition .append(Constant.html)
        var replaced: String
        for (lanes: lanelexicon in lanesdictionary) {
            //  replaced = getLanes(lanes);
            replaced = lanes.getDefinition()
            val indexOf: Int = replaced.indexOf("<orth extent=\"full\" lang=\"ar\">ذ</orth>")
            val indexofForm: Int = replaced.indexOf("<form>")
            val indexofFormclose: Int = replaced.indexOf("</form>")
            val indexofforminfl: Int = replaced.indexOf("<form n=\"infl\">")
            difinition .append("<p dir='ltr' style=\" margin-top:0px; margin-bottom:0px; margin-left:0px; margin-right:0px; -qt-block-indent:0; text-indent:0px;\">")
            if (indexOf != -1) {
                replaced =
                    replaced.replace("<orth extent=\"full\" lang=\"ar\">ذ</orth>".toRegex(), "")
                //     difinition .append(replaced);
            }
            if (indexofForm != -1) {
                replaced = replaced.replace("<form>".toRegex(), "")
                //     difinition .append(replaced);
            }
            if (indexofFormclose != -1) {
                replaced = replaced.replace("</form>".toRegex(), "")
                //    difinition .append(replaced);
            }
            if (indexofforminfl != -1) {
                replaced = replaced.replace("<form n=\"infl\">".toRegex(), "")
                //    difinition .append(replaced);
            }
            difinition .append(replaced)
            difinition .append("</p>")
            difinition .append("<hr size=\"1\" width=\"100%\" color=\"red\">  ")
        }
        lanesDefinition.add(difinition .toString())
        expandableListDetail!!.put("lanes", lanesDefinition)
        //  return verbroot;
    }

    fun ExecuteNounOcurrance() {
        val ex: ExecutorService = Executors.newSingleThreadExecutor()
        ex.execute(object : Runnable {
            public override fun run() {
                runOnUiThread(object : Runnable {
                    public override fun run() {
                        dialog!!.show()
                    }
                })
                //  occurances = utils.getNounOccuranceBreakVerses(root);
                nounCorpusArrayList = utils!!.getNounBreakup(root)
                verbCorpusArrayList = utils!!.getVerbBreakUp(root)
                var Lemma: String? = ""
                val incexofgroup: Int = 0
                val alist: MutableList<*> = ArrayList<Any?>()
                if (this.isHarf) {
                    for (vers: CorpusNounWbwOccurance in occurances!!) {
                        //    alist.add("");
                        val sb: String  = String ()
                        val spanDark: SpannableString = SpannableString(vers.getQurantext())
                        val spannableVerses: Spannable = CorpusUtilityorig.getSpannableVerses(
                            vers.getAraone() + vers.getAratwo() + vers.getArathree() + vers.getArafour() + vers.getArafive(),
                            vers.getQurantext()
                        )
                        sb.append(vers.getSurah()).append(":").append(vers.getAyah()).append(":")
                            .append(vers.getWordno()).append("-").append(vers.getEn()).append("-")
                        val ref: SpannableString = SpannableString(sb.toString())
                        ref.setSpan(
                            Constant.particlespanDark,
                            0,
                            sb.length,
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                        )
                        val which: String? = shared!!.getString("selecttranslation", "en_sahih")
                        var trans: SpannableString? = null
                        if ((which == "en_sahih")) {
                            trans = SpannableString.valueOf(vers.getTranslation())
                        } else if ((which == "ur_jalalayn")) {
                            trans = SpannableString.valueOf(vers.getUr_jalalayn())
                        } else if ((which == "en_jalalayn")) {
                            trans = SpannableString.valueOf(vers.getEn_jalalayn())
                        }
                        val charSequence: CharSequence =
                            TextUtils.concat(ref, "\n ", spannableVerses)
                        alist.add(charSequence)
                        alist.add(trans)
                        expandNounVerses.put(sb.toString(), alist)
                    }
                }
                for (noun: NounCorpusBreakup in nounCorpusArrayList) {
                    val list: MutableList<*> = ArrayList<Any?>()
                    list.add("")
                    Lemma = noun.getLemma_a()
                    if ((noun.getForm() == "null")) {
                        val sb: String  = String ()
                        val nounexpand: String =
                            QuranMorphologyDetails.Companion.expandTags(noun.getTag())
                        var times: String? = ""
                        if (noun.getCount() == 1) {
                            times = "Once"
                        } else {
                            val count: Int = noun.getCount()
                            val timess: String = count.toString()
                            times = timess + "-" + "times"
                        }
                        sb.append(times).append(" ").append(noun.getLemma_a()).append(" ")
                            .append("occurs as the").append(" ").append(nounexpand)
                        expandNounVerses.put(sb.toString(), list)
                    } else {
                        val sb: String  = String ()
                        val s: String =
                            QuranMorphologyDetails.Companion.expandTags(noun.getPropone() + noun.getProptwo())
                        //  String s1 = QuranMorphologyDetails.expandTags(noun.getProptwo());
                        val s2: String = QuranMorphologyDetails.Companion.expandTags(noun.getTag())
                        var times: String? = ""
                        if (noun.getCount() == 1) {
                            times = "Once"
                        } else {
                            val count: Int = noun.getCount()
                            val timess: String = count.toString()
                            times = timess + "-" + "times"
                        }
                        sb.append(times).append(" ").append(noun.getLemma_a()).append(" ")
                            .append("occurs as the").append(" ").append(noun.getForm())
                            .append(" ")
                        if (!(s == "null")) {
                            sb.append(s).append(" ").append(" ")
                        }
                        sb.append(s2)
                        expandNounVerses.put(sb.toString(), list)
                    }
                }
                for (verbCorpusBreakup: VerbCorpusBreakup in verbCorpusArrayList) {
                    val list: MutableList<*> = ArrayList<Any?>()
                    list.add("")
                    Lemma = verbCorpusBreakup.getLemma_a()
                    if ((verbCorpusBreakup.getForm() == "I")) {
                        val sb: String  = String ()
                        val mujarrad: String =
                            QuranMorphologyDetails.Companion.getThulathiName(verbCorpusBreakup.getThulathibab())
                                .toString()
                        sb.append(verbCorpusBreakup.getCount()).append("-").append("times")
                            .append(" ").append(verbCorpusBreakup.getLemma_a()).append(" ")
                            .append("occurs as the").append(" ").append(mujarrad)
                        expandVerbVerses.put(sb.toString(), list)
                    } else {
                        val sb: String  = String ()
                        val s: String =
                            QuranMorphologyDetails.Companion.expandTags(verbCorpusBreakup.getTense())
                        val s1: String =
                            QuranMorphologyDetails.Companion.expandTags(verbCorpusBreakup.getVoice())
                        //  String s1 = QuranMorphologyDetails.expandTags(noun.getProptwo());
                        //   String s2 = QuranMorphologyDetails.expandTags(noun.get);
                        val mazeed: String =
                            QuranMorphologyDetails.Companion.getFormName(verbCorpusBreakup.getForm())
                                .toString()
                        sb.append(verbCorpusBreakup.getCount()).append("-").append("times")
                            .append(" ").append(verbCorpusBreakup.getLemma_a()).append(" ")
                            .append("occurs as the").append(" ").append(mazeed)
                            .append(" ").append(s).append(" ").append(" ").append(s1)
                        expandVerbVerses.put(sb.toString(), list)
                    }
                }
                expandNounTitles = ArrayList(expandNounVerses.keys)
                expandVerbTitles = ArrayList(expandVerbVerses.keys)
                expandNounVerses.putAll(expandVerbVerses)
                expandNounTitles.addAll(expandVerbTitles)
                //post
                runOnUiThread(object : Runnable {
                    public override fun run() {
                        dialog!!.dismiss()
                        // Intent intent = new Intent();
                        // intent.putExtra("result", 1);
                        //  setResult(RESULT_OK, intent);
                        val listAdapter: NounVerbOccuranceListAdapter
                        listAdapter = NounVerbOccuranceListAdapter(
                            this@WordDictionaryAct,
                            expandNounTitles,
                            expandNounVerses,
                            expandVerbVerses,
                            expandVerbTitles
                        )
                        expandableListView!!.setAdapter(listAdapter)
                        expandableListView!!.setOnGroupExpandListener(object :
                            OnGroupExpandListener {
                            public override fun onGroupExpand(groupPosition: Int) {
                                val split: Array<String> =
                                    expandNounTitles.get(groupPosition).split("\\s".toRegex())
                                        .dropLastWhile({ it.isEmpty() }).toTypedArray()
                                if (!this.isHarf) {
                                    if (expandNounTitles.get(groupPosition).contains("Hans")) {
                                        val ex: ExecutorService =
                                            Executors.newSingleThreadExecutor()
                                        ex.execute(object : Runnable {
                                            public override fun run() {
                                                runOnUiThread(Runnable({ dialog!!.show() }))
                                                var verbroot: String? = ""
                                                val indexOfHamza: Int = root!!.indexOf(
                                                    ArabicLiterals.Hamza
                                                )
                                                val indexofAlifMaksura: Int = root!!.indexOf(
                                                    ArabicLiterals.Ya
                                                )
                                                if (indexOfHamza != -1) {
                                                    verbroot = root!!.replace(
                                                        ArabicLiterals.Hamza.toRegex(),
                                                        ArabicLiterals.LALIF
                                                    )
                                                } else {
                                                    verbroot = root
                                                }
                                                if (indexofAlifMaksura != -1) {
                                                    verbroot = verbroot!!.replace(
                                                        ArabicLiterals.Ya.toRegex(),
                                                        ArabicLiterals.AlifMaksuraString
                                                    )
                                                }
                                                var list: MutableList<*> = ArrayList<Any?>()
                                                //   ArrayList<CorpusNounWbwOccurance> verses = utils.getNounOccuranceBreakVerses(split[1]);
                                                val lanesDifinition: ArrayList<hanslexicon> =
                                                    utils!!.getHansDifinition(verbroot)
                                                //    ArrayList<SpannableString> lanesdifinition;
                                                //   String  lanessb = new String ();
                                                for (hans: hanslexicon in lanesDifinition) {
                                                    //  <p style="margin-left:200px; margin-right:50px;">
                                                    //    list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    //  list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    list.add(hans.getDefinition())
                                                    //
                                                }
                                                list = highLightParadigm(list)
                                                val finalList: List<*> = list
                                                runOnUiThread(object : Runnable {
                                                    public override fun run() {
                                                        ex.shutdown()
                                                        dialog!!.dismiss()
                                                        expandNounVerses.put(
                                                            expandNounTitles.get(
                                                                groupPosition
                                                            ), finalList
                                                        )
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }

                                            private fun highLightParadigm(list: List<*>): MutableList<*> {
                                                val lists: MutableList<*> = ArrayList<Any?>()
                                                val REGEX: String = "aor.([\\s\\S]){3}"
                                                val pattern: Pattern = Pattern.compile(REGEX)
                                                for (l: Any in list) {
                                                    val replaceAll: String = l.toString()
                                                        .replace("<br></br>".toRegex(), "")
                                                    val m: Matcher = pattern.matcher(replaceAll)
                                                    var sb: SpannableString? = null
                                                    var indexof: Int = 0
                                                    if (m.find()) {
                                                        println("Found value: " + m.group(0))
                                                        println("Found value: " + m.group(1))
                                                        indexof = l.toString().indexOf(m.group(0))
                                                        sb = SpannableString(l.toString())
                                                        sb.setSpan(
                                                            Constant.particlespanDark,
                                                            indexof,
                                                            m.group(0).length + indexof,
                                                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                        )
                                                        lists.add(sb)
                                                        //   System.out.println("Found value: " + m.group(2) );
                                                    } else {
                                                        lists.add(replaceAll)
                                                    }
                                                }
                                                return lists
                                            }
                                        })
                                    } else if (expandNounTitles.get(groupPosition)
                                            .contains("lanes")
                                    ) {
                                        val ex: ExecutorService =
                                            Executors.newSingleThreadExecutor()
                                        ex.execute(object : Runnable {
                                            public override fun run() {
                                                runOnUiThread(Runnable({ dialog!!.show() }))
                                                var list: MutableList<*> = ArrayList<Any?>()
                                                val lanesDifinition: ArrayList<lanelexicon> =
                                                    utils!!.getLanesDifinition(root)
                                                for (lanes: lanelexicon in lanesDifinition) {
                                                    //  <p style="margin-left:200px; margin-right:50px;">
                                                    //    list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    //  list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    list.add(lanes.getDefinition())
                                                    //
                                                }
                                                list = highLightParadigm(list)
                                                val finalList: List<*> = list
                                                runOnUiThread(object : Runnable {
                                                    public override fun run() {
                                                        ex.shutdown()
                                                        dialog!!.dismiss()
                                                        expandNounVerses.put(
                                                            expandNounTitles.get(
                                                                groupPosition
                                                            ), finalList
                                                        )
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }

                                            private fun highLightParadigm(list: List<*>): MutableList<*> {
                                                val lists: MutableList<*> = ArrayList<Any?>()
                                                val REGEX: String = "aor.([\\s\\S]){3}"
                                                val pattern: Pattern = Pattern.compile(REGEX)
                                                for (l: Any in list) {
                                                    val replaceAll: String = l.toString()
                                                        .replace("<br></br>".toRegex(), "")
                                                    val m: Matcher = pattern.matcher(replaceAll)
                                                    var sb: SpannableString? = null
                                                    var indexof: Int = 0
                                                    if (m.find()) {
                                                        println("Found value: " + m.group(0))
                                                        println("Found value: " + m.group(1))
                                                        indexof = l.toString().indexOf(m.group(0))
                                                        sb = SpannableString(l.toString())
                                                        sb!!.setSpan(
                                                            Constant.particlespanDark,
                                                            indexof,
                                                            m.group(0).length + indexof,
                                                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                        )
                                                        lists.add(sb)
                                                        //   System.out.println("Found value: " + m.group(2) );
                                                    } else {
                                                        lists.add(replaceAll)
                                                    }
                                                }
                                                return lists
                                            }
                                        })
                                    } else if (expandNounTitles.get(groupPosition)
                                            .contains("Noun") || expandNounTitles.get(groupPosition)
                                            .contains("Adverb") || expandNounTitles.get(
                                            groupPosition
                                        ).contains("Adjective")
                                    ) {
                                        val ex: ExecutorService =
                                            Executors.newSingleThreadExecutor()
                                        val  : AlertDialog.  =
                                            AlertDialog. (this@WordDictionaryAct)
                                         .setCancelable(false) // if you want user to wait for some process to finish,
                                         .setView(R.layout.layout_loading_dialog)
                                        val dialog: AlertDialog =  .create()
                                        ex.execute(object : Runnable {
                                            public override fun run() {
                                                runOnUiThread(Runnable({ dialog.show() }))
                                                val list: MutableList<*> = ArrayList<Any?>()
                                                val verses: ArrayList<CorpusNounWbwOccurance> =
                                                    utils!!.getNounOccuranceBreakVerses(split.get(1))
                                                for (vers: CorpusNounWbwOccurance in verses) {
                                                    val sb: String  = String ()
                                                    val spanDark: SpannableString =
                                                        SpannableString(vers.getQurantext())
                                                    val spannableVerses: Spannable =
                                                        CorpusUtilityorig.getSpannableVerses(
                                                            vers.getAraone() + vers.getAratwo() + vers.getArathree() + vers.getArafour() + vers.getArafive(),
                                                            vers.getQurantext()
                                                        )
                                                    sb.append(vers.getSurah()).append(":")
                                                        .append(vers.getAyah()).append(":")
                                                        .append(vers.getWordno()).append("-")
                                                        .append(vers.getEn()).append("-")
                                                    val ref: SpannableString =
                                                        SpannableString(sb.toString())
                                                    ref.setSpan(
                                                        Constant.particlespanDark,
                                                        0,
                                                        sb.length,
                                                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                    )
                                                    val which: String? = shared!!.getString(
                                                        "selecttranslation",
                                                        "en_sahih"
                                                    )
                                                    var trans: SpannableString? = null
                                                    if ((which == "en_sahih")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.getTranslation())
                                                    } else if ((which == "ur_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.getUr_jalalayn())
                                                    } else if ((which == "en_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.getEn_jalalayn())
                                                    }
                                                    val charSequence: CharSequence =
                                                        TextUtils.concat(
                                                            ref,
                                                            "\n ",
                                                            spannableVerses
                                                        )
                                                    list.add(charSequence)
                                                    list.add(trans)
                                                }
                                                runOnUiThread(object : Runnable {
                                                    public override fun run() {
                                                        ex.shutdown()
                                                        dialog.dismiss()
                                                        expandNounVerses.put(
                                                            expandNounTitles.get(
                                                                groupPosition
                                                            ), list
                                                        )
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }
                                        })
                                    } else {
                                        val ex: ExecutorService =
                                            Executors.newSingleThreadExecutor()
                                        ex.execute(object : Runnable {
                                            public override fun run() {
                                                runOnUiThread(object : Runnable {
                                                    public override fun run() {
                                                        dialog!!.show()
                                                    }
                                                })
                                                val list: MutableList<*> = ArrayList<Any?>()
                                                val verses: ArrayList<CorpusVerbWbwOccurance> =
                                                    utils!!.getVerbOccuranceBreakVerses((split.get(1)))
                                                for (vers: CorpusVerbWbwOccurance in verses) {
                                                    val sb: String  = String ()
                                                    val spanDark: SpannableString =
                                                        SpannableString(vers.getQurantext())
                                                    val spannableVerses: Spannable =
                                                        CorpusUtilityorig.getSpannableVerses(
                                                            vers.getAraone() + vers.getAratwo() + vers.getArathree() + vers.getArafour() + vers.getArafive(),
                                                            vers.getQurantext()
                                                        )
                                                    //  SpannableString spannableString = CorpusUtilityorig.SetWordSpanNew(vers.getTagone(), vers.getTagtwo(), vers.getTagthree(), vers.getTagfour(), vers.getTagfive(),
                                                    //     vers.getAraone(), vers.getAratwo(), vers.getArathree(), vers.getArafour(), vers.getArafive());
                                                    sb.append(vers.getSurah()).append(":")
                                                        .append(vers.getAyah()).append(":")
                                                        .append(vers.getWordno()).append("-")
                                                        .append(vers.getEn()).append("-")
                                                    //       sb.append(vers.getSurah()).append(":").append(vers.getAyah()).append(":").append(vers.getWordno()).append("-");
                                                    vers.getWordno()
                                                    val ref: SpannableString =
                                                        SpannableString(sb.toString())
                                                    ref.setSpan(
                                                        maincolortag,
                                                        0,
                                                        sb.length,
                                                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                    )
                                                    val which: String? = shared!!.getString(
                                                        "selecttranslation",
                                                        "en_sahih"
                                                    )
                                                    var trans: SpannableString? = null
                                                    if ((which == "en_sahih")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.getTranslation())
                                                    } else if ((which == "ur_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.getUr_jalalayn())
                                                    } else if ((which == "en_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.getEn_jalalayn())
                                                    }
                                                    val charSequence: CharSequence =
                                                        TextUtils.concat(
                                                            ref,
                                                            "\n ",
                                                            spannableVerses
                                                        )
                                                    list.add(charSequence)
                                                    list.add(trans)
                                                }
                                                runOnUiThread(object : Runnable {
                                                    public override fun run() {
                                                        ex.shutdown()
                                                        dialog!!.dismiss()
                                                        expandNounVerses.put(
                                                            expandNounTitles.get(
                                                                groupPosition
                                                            ), list
                                                        )
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }
                                        })
                                    }
                                }
                            }
                        })
                        expandableListView!!.setOnChildClickListener(object : OnChildClickListener {
                            public override fun onChildClick(
                                parent: ExpandableListView, v: View,
                                groupPosition: Int, childPosition: Int, id: Long
                            ): Boolean {
                                //   final String selected = String.valueOf((SpannableString) listAdapter.getChild(
                                //      groupPosition, childPosition));
                                val child: CharSequence = listAdapter.getChild(
                                    groupPosition,
                                    childPosition
                                ) as CharSequence
                                val split: Array<String> = child.toString().split("-".toRegex())
                                    .dropLastWhile({ it.isEmpty() }).toTypedArray()
                                val surahaya: Array<String> = split.get(0).split(":".toRegex())
                                    .dropLastWhile({ it.isEmpty() }).toTypedArray()
                                if (surahaya.size > 1) {
                                    try {
                                        Integer.valueOf(surahaya.get(2))
                                    } catch (e: NumberFormatException) {
                                        return false
                                    }
                                    try {
                                        Integer.valueOf(surahaya.get(1))
                                    } catch (e: NumberFormatException) {
                                        return false
                                    }
                                    try {
                                        Integer.valueOf(surahaya.get(0))
                                    } catch (e: NumberFormatException) {
                                        return false
                                    }
                                    val wordno: String = surahaya.get(2)
                                    val ayah: String = surahaya.get(1)
                                    val surah: String = surahaya.get(0)
                                    val dataBundle: Bundle = Bundle()
                                    dataBundle.putInt(Constant.SURAH_ID, surah.toInt())
                                    dataBundle.putInt(Constant.AYAHNUMBER, ayah.toInt())
                                    dataBundle.putInt(Constant.WORDNUMBER, wordno.toInt())
                                    dataBundle.putString(Constant.SURAH_ARABIC_NAME, "SurahName")
                                    LoadItemList(dataBundle, surah, ayah, wordno)
                                    return true
                                } else {
                                    return false
                                }
                            }

                            private fun LoadItemList(
                                dataBundle: Bundle,
                                surah: String,
                                ayah: String,
                                wordno: String
                            ) {
                                val item: WordAnalysisBottomSheet = WordAnalysisBottomSheet()
                                //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                                val fragmentManager: FragmentManager = getSupportFragmentManager()
                                item.setArguments(dataBundle)
                                val data: Array<String> = arrayOf(surah, ayah, "", wordno)
                                val transactions: FragmentTransaction =
                                    fragmentManager.beginTransaction().setCustomAnimations(
                                        anim.abc_slide_in_top, android.R.anim.fade_out
                                    )
                                //     transactions.show(item);
                                WordAnalysisBottomSheet.Companion.newInstance(data).show(
                                    getSupportFragmentManager(),
                                    WordAnalysisBottomSheet.Companion.TAG
                                )
                                //   WordAnalysisBottomSheet.newInstance(data).show(WordOccuranceAsynKAct.this).getSupportFragmentManager(), WordAnalysisBottomSheet.TAG);
                            }
                        })
                    }
                })
            }
        })
        //  ExpandableRecAdapter expandableRecAdapter=new ExpandableRecAdapter(WordOccuranceAsynKAct.this,expandNounVerses,expandNounTitles);
        //  recview.setAdapter(expandableRecAdapter);
    }

    companion object {
        private val REQUEST_WRITE_STORAGE: Int = 112
        private val REQUEST_WRITE_Settings: Int = 113
    }
}