package com.example.mushafconsolidated.Activityimportimportimport

import CorpusAyahWord
import android.app.SearchManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.annotation.RequiresApi
import androidx.appcompat.widget.SearchView
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.mushafconsolidated.Activity.BaseActivity
import com.example.mushafconsolidated.Activity.QuranGrammarAct
import com.example.mushafconsolidated.Activity.TopicDetailAct
import com.example.mushafconsolidated.Adapters.QuranTopicSearchAdapter
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.intrfaceimport.OnItemClickListenerOnLong
import com.example.mushafconsolidatedimport.Utils
import com.google.android.material.floatingactionbutton.FloatingActionButton
import org.sj.conjugator.MainActivity
import quranexplorer

class QuranTopicSearchActivity constructor() : BaseActivity(), OnItemClickListenerOnLong {
    lateinit var btnSelection: FloatingActionButton
    private lateinit var recyclerView: RecyclerView
    private val corpusayahWordArrayList: ArrayList<CorpusAyahWord>? = null
    private var searchDownloadAdapter: QuranTopicSearchAdapter? = null
    private var searchView: SearchView? = null
    private val readytodownload: View? = null
    private val downloadedtranslation: View? = null
    private val backbutton: View? = null
    private var qurandictionaryArrayList: ArrayList<quranexplorer>? = null

    //  private DownloadSearchAdapter.ContactsAdapterListener contactsAdapterListener;
    private val translationDownloaded: View? = null
    private val translationReadytoDownload: View? = null
    private val view2: View? = null
    private val view1: View? = null
    private val view3: View? = null

    @RequiresApi(api = Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        //setSupportActionBar(toolbar);
        setSupportActionBar(toolbar)
        getSupportActionBar()!!.setDisplayHomeAsUpEnabled(true)
        getSupportActionBar()!!.setTitle(R.string.toolbar_title)
        /*      SharedPreferences shared = PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext());
        String isNightmode = shared.getString("theme", "dark");
        final int color = ContextCompat.getColor(this, R.color.color_background_overlay);
        final int colorsurface = ContextCompat.getColor(this, R.color.colorAccent);
        final int coloronbackground = ContextCompat.getColor(this, R.color.neutral0);
        if (isNightmode.equals("dark") || isNightmode.equals("blue")) {
            toolbar.setBackgroundColor(coloronbackground);
            toolbar.setBackgroundColor(color);+
        } else {
            toolbar.setBackgroundColor(colorsurface);
        }*/
        val utils: Utils = Utils(this)
        btnSelection = findViewById(R.id.btnShow)
        //     searchDownloadAdapter = new DownloadSearchAdapter(this,translationEntity -> {});
        qurandictionaryArrayList = utils.topicSearchAll as ArrayList<quranexplorer>?
        recyclerView = findViewById(R.id.recycler_view)
        searchDownloadAdapter =
            QuranTopicSearchAdapter(this@QuranTopicSearchActivity, qurandictionaryArrayList, false)
        whiteNotificationBar(recyclerView)
        val mLayoutManager: RecyclerView.LayoutManager =
            LinearLayoutManager(getApplicationContext())
        recyclerView.setLayoutManager(mLayoutManager)
        recyclerView.setItemAnimator(DefaultItemAnimator())
        //   recyclerView.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 36));
        recyclerView.setAdapter(searchDownloadAdapter)
        btnSelection.setOnClickListener(object : View.OnClickListener {
            public override fun onClick(v: View?) {
                var data: String = ""
                var titles: String = ""
                val stList: List<quranexplorer>? =
                    (searchDownloadAdapter as QuranTopicSearchAdapter).list
                val datas: HashMap<String, String> = HashMap()
                if (stList != null) {
                    for (i in stList.indices) {
                        val selectedlist: quranexplorer = stList.get(i)
                        if (selectedlist.isSelected) {
                            datas.put(selectedlist.title, selectedlist.ayahref)
                            data = data + selectedlist.ayahref + ","
                            titles = titles + selectedlist.title + ","
                        }
                    }
                }
                //  extracted(data, titles);
                val dataBundle: Bundle = Bundle()
                if (!data.contains("null")) {
                    if (datas.size > 0) {
                        dataBundle.putSerializable("map", datas)
                        val intents: Intent =
                            Intent(this@QuranTopicSearchActivity, TopicDetailAct::class.java)
                        intents.putExtras(dataBundle)
                        startActivity(intents)
                    }
                } else {
                    Toast.makeText(this@QuranTopicSearchActivity, "Not found", Toast.LENGTH_SHORT)
                        .show()
                }
            }
        })
    }

    private fun extracted(data: String, titles: String) {
        var data: String = data
        if (data.contains("null")) {
            val split: Array<String> =
                titles.split("-".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
            val utils1: Utils = Utils(getApplicationContext())
            val topicSearch: ArrayList<quranexplorer> = utils1.getTopicSearch(split.get(0)) as ArrayList<quranexplorer>
            data = ""
            for (search: quranexplorer in topicSearch) {
                if (!search.ayahref.contains("null") || !search.ayahref.contains("ref")) {
                    data = data + search.ayahref + ","
                }
            }
        }
        data = data.replace("null".toRegex(), "")
        data = data.replace(",,".toRegex(), ",")
        data = data.replace(":,".toRegex(), "")
    }

    public override fun onCreateOptionsMenu(menu: Menu): Boolean {
        getMenuInflater().inflate(R.menu.menu_main, menu)
        // Associate searchable configuration with the SearchView
        val searchManager: SearchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        searchView = menu.findItem(R.id.action_search)
            .getActionView() as SearchView?
        searchView!!.setSearchableInfo(
            searchManager
                .getSearchableInfo(getComponentName())
        )
        searchView!!.setMaxWidth(Int.MAX_VALUE)
        searchView!!.setQueryHint("Type something…")
        val sear: Drawable? = ContextCompat.getDrawable(this, R.drawable.custom_search_box)
        searchView!!.setClipToOutline(true)
        searchView!!.setBackgroundDrawable(sear)
        searchView!!.setGravity(View.TEXT_ALIGNMENT_CENTER)
        searchView!!.setMaxWidth(Int.MAX_VALUE)

        // listening to search query text change
        searchView!!.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            public override fun onQueryTextSubmit(query: String?): Boolean {
                // filter recycler view when query submitted
                searchDownloadAdapter!!.getFilter().filter(query)
                return false
            }

            public override fun onQueryTextChange(query: String?): Boolean {
                // filter recycler view when text is changed
                searchDownloadAdapter!!.getFilter().filter(query)
                return false
            }
        })
        return true
    }

    public override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id: Int = item.getItemId()
        if (id == R.id.action_search) {
            return true
        }
        if (id == R.id.backButtonView) {
            val rintent: Intent = Intent(this@QuranTopicSearchActivity, QuranGrammarAct::class.java)
            startActivity(rintent)
            finish()
        }
        val rintent: Intent = Intent(this@QuranTopicSearchActivity, QuranGrammarAct::class.java)
        startActivity(rintent)
        finish()
        //return super.onOptionsItemSelected(item);
        return true
    }

    /*
    @Override
    public void onBackPressed() {
        finish();

        if (!searchView.isIconified()) {
            searchView.setIconified(true);
            return;
        }
        super.onBackPressed();
    }
   */
    private fun whiteNotificationBar(view: View?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var flags: Int = view!!.getSystemUiVisibility()
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            view.setSystemUiVisibility(flags)
            getWindow().setStatusBarColor(Color.WHITE)
        }
    }

    public override fun onItemClick(v: View, position: Int) {
        Toast.makeText(this, "onItemCLick", Toast.LENGTH_SHORT).show()
    }

    public override fun onItemLongClick(position: Int, v: View) {}

    companion object {
        private val LAUNCH_SECOND_ACTIVITY: Int = 1
        private val TAG: String = MainActivity::class.java.getSimpleName()

        // url to fetch contacts json
        private val URL: String = "https://api.androidhive.info/json/contacts.json"
    }
}