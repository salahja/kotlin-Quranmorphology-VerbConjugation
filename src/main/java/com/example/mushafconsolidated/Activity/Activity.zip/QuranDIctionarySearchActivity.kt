package com.example.mushafconsolidated.Activityimportimportimport

import android.app.SearchManager
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.util.DisplayMetrics
import android.view.Display
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.SearchView
import android.widget.Toast
import androidx.appcompat.widget.Toolbar
import androidx.core.content.ContextCompat
import androidx.recyclerview.widget.DefaultItemAnimator
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.example.Constant
import com.example.mushafconsolidated.Activity.BaseActivity
import com.example.mushafconsolidated.Activity.QuranGrammarAct
import com.example.mushafconsolidated.Activity.SearchResult
import com.example.mushafconsolidated.Adapters.SearchAdapter
import com.example.mushafconsolidated.R
import com.example.mushafconsolidated.intrfaceimport.OnItemClickListener
import com.example.mushafconsolidatedimport.Utils
import org.sj.conjugator.MainActivity
import qurandictionary


class QuranDIctionarySearchActivity constructor() : BaseActivity(), OnItemClickListener {
    private lateinit var recyclerView: RecyclerView

    // private QuranTopicSearchAdapter topicSearchAdapter;
    private var topicSearchAdapter: SearchAdapter? = null
    private var searchView: SearchView? = null
    private val readytodownload: View? = null
    private val downloadedtranslation: View? = null
    private val backbutton: View? = null

    //  private DownloadSearchAdapter.ContactsAdapterListener contactsAdapterListener;
    private val translationDownloaded: View? = null
    private val translationReadytoDownload: View? = null
    private var view2: View? = null
    private var view1: View? = null
    private var view3: View? = null
    private var topicSearchAll: ArrayList<qurandictionary>? = null
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == QuranDIctionarySearchActivity.Companion.LAUNCH_SECOND_ACTIVITY) {
            if (resultCode == RESULT_OK) {
                val result: String? = data!!.getStringExtra("result")
                if (result != null) {
                    val split: Array<String> =
                        result.split(",".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
                    //       File file=new File(split[0]);
                    //    new InsertingTranslationFetch(TranslationActivitySearch.this).execute(split[0], split[1]);
                }
            }
            if (resultCode == RESULT_CANCELED) {
                // Write your code if there's no result
            }
        }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_main)
        val toolbar: Toolbar = findViewById(R.id.toolbar)
        //setSupportActionBar(toolbar);
        val display: Display = getWindowManager().getDefaultDisplay()
        val outMetrics: DisplayMetrics = DisplayMetrics()
        display.getMetrics(outMetrics)
        val density: Float = getResources().getDisplayMetrics().density
        val dpHeight: Float = outMetrics.heightPixels / density
        val dpWidth: Float = outMetrics.widthPixels / density
        // toolbar fancy stuff
        setSupportActionBar(toolbar)
        getSupportActionBar()!!.setDisplayHomeAsUpEnabled(true)
        getSupportActionBar()!!.setTitle(R.string.toolbar_title)
        val utils: Utils = Utils(this)
/*        view2 = findViewById(R.id.translationReadytoDownload)
        (view2.getLayoutParams()).width = (dpWidth / 2).toInt()
        view1 = findViewById(R.id.translationDownloaded)
        view3 = findViewById(R.id.backButtonView)
        (view1.getLayoutParams()).width = (dpWidth / 2).toInt()
        view1.setX(-1.0f)*/
        //     searchDownloadAdapter = new DownloadSearchAdapter(this,translationEntity -> {});
        topicSearchAll = utils.quranDictionary as ArrayList<qurandictionary>?
        recyclerView = findViewById(R.id.recycler_view)
        topicSearchAdapter =
            SearchAdapter(this@QuranDIctionarySearchActivity, topicSearchAll, false)
        topicSearchAdapter!!.SetOnItemClickListener(object : OnItemClickListener {
            public override fun onItemClick(v: View?, position: Int) {
                // TranslationEntity entity = loadedTranslation.get(position);
                val entity: qurandictionary? =
                    topicSearchAdapter!!.getItem(position) as qurandictionary?
                // View id1 =       v.findViewById(R.R.id.translationid);
                // View id2 =       v.findViewById(R.R.id.authorname);
                // View id3 =      v.findViewById(R.R.id.languagename);
                val bundle: Bundle = Bundle()
                //   Intent intent = new Intent(getActivity(), NounOccuranceAsynKAct.class);
                val intent: Intent =
                    Intent(this@QuranDIctionarySearchActivity, SearchResult::class.java)
                bundle.putString(Constant.QURAN_VERB_ROOT, entity!!.rootarabic)
                intent.putExtras(bundle)
                //   intent.putExtra(QURAN_VERB_ROOT,vb.getRoot());
                startActivity(intent)
                //   Toast.makeText(SearchActivity.this, "tobe downloaded click", Toast.LENGTH_SHORT).show();
            }
        })
        // white background notification bar
        whiteNotificationBar(recyclerView)
        val mLayoutManager: RecyclerView.LayoutManager =
            LinearLayoutManager(getApplicationContext())
        recyclerView.setLayoutManager(mLayoutManager)
        recyclerView.setItemAnimator(DefaultItemAnimator())
        //   recyclerView.addItemDecoration(new MyDividerItemDecoration(this, DividerItemDecoration.VERTICAL, 36));
        recyclerView.setAdapter(topicSearchAdapter)
    }

    public override fun onCreateOptionsMenu(menu: Menu): Boolean {
        getMenuInflater().inflate(R.menu.menu_main, menu)
        // Associate searchable configuration with the SearchView
        val searchManager: SearchManager = getSystemService(SEARCH_SERVICE) as SearchManager
        searchView = menu.findItem(R.id.action_search)
            .getActionView() as SearchView?
        searchView!!.setSearchableInfo(
            searchManager
                .getSearchableInfo(getComponentName())
        )
        val searchView: SearchView? = menu.findItem(R.id.search).getActionView() as SearchView?
        val sear: Drawable? = ContextCompat.getDrawable(this, R.drawable.custom_search_box)
        searchView!!.setClipToOutline(true)
        searchView.setBackgroundDrawable(sear)
        searchView.setGravity(View.TEXT_ALIGNMENT_CENTER)
        searchView.setMaxWidth(Int.MAX_VALUE)
        // listening to search query text change
        searchView.setOnQueryTextListener(object : SearchView.OnQueryTextListener {
            public override fun onQueryTextSubmit(query: String?): Boolean {
                // filter recycler view when query submitted
                topicSearchAdapter!!.getFilter().filter(query)
                return false
            }

            public override fun onQueryTextChange(query: String?): Boolean {
                // filter recycler view when text is changed
                topicSearchAdapter!!.getFilter().filter(query)
                return false
            }
        })
        return true
    }

    public override fun onOptionsItemSelected(item: MenuItem): Boolean {
        // Handle action bar item clicks here. The action bar will
        // automatically handle clicks on the Home/Up button, so long
        // as you specify a parent activity in AndroidManifest.xml.
        val id: Int = item.getItemId()
        if (id == R.id.action_search) {
            return true
        }
        if (id == R.id.backButtonView) {
            val rintent: Intent =
                Intent(this@QuranDIctionarySearchActivity, QuranGrammarAct::class.java)
            startActivity(rintent)
            finish()
        }
        val rintent: Intent =
            Intent(this@QuranDIctionarySearchActivity, QuranGrammarAct::class.java)
        startActivity(rintent)
        finish()
        //return super.onOptionsItemSelected(item);
        return true
    }

    public override fun onBackPressed() {
        finish()
        if (!searchView!!.isIconified()) {
            searchView!!.setIconified(true)
            return
        }
        super.onBackPressed()
    }

    private fun whiteNotificationBar(view: View?) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            var flags: Int = view!!.getSystemUiVisibility()
            flags = flags or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR
            view.setSystemUiVisibility(flags)
            getWindow().setStatusBarColor(Color.WHITE)
        }
    }

    public override fun onItemClick(v: View?, position: Int) {
        Toast.makeText(this, "back", Toast.LENGTH_SHORT).show()
        // Toast.makeText(getApplicationContext(), "Selected: " + translationEntity.getLanguage_name()+ ", " + translationEntity.getLanguage_name(), Toast.LENGTH_LONG).show();
    }

    companion object {
        private val LAUNCH_SECOND_ACTIVITY: Int = 1
        private val TAG: String = MainActivity::class.java.getSimpleName()

        // url to fetch contacts json
        private val URL: String = "https://api.androidhive.info/json/contacts.json"
    }
}