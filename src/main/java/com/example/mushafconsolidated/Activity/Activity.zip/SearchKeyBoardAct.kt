package com.example.mushafconsolidated.Activityimport








 





class SearchKeyBoardAct constructor() : BaseActivity(), View.OnClickListener {
    private val keyValues: SparseArray<String> = SparseArray()
    var quranbtn: Button? = null
    var settingbtn: Button? = null
    var floatingActionButton: FloatingActionButton? = null
    var layoutBottomSheet: RelativeLayout? = null
    var sheetBehavior: BottomSheetBehavior<*>? = null
    var tlist: ListView? = null
    var mlist: ListView? = null
    var isSarfKabeed: Boolean = false
    private var qurandictionaryArrayList: ArrayList<qurandictionary>? = null
    private var keyboard: View? = null
    private var inputConnection: InputConnection? = null
    private var actv: AutoCompleteTextView? = null
    fun setSarfKabeed(sarfKabeed: Boolean) {
        isSarfKabeed = sarfKabeed
    }

    fun setInputtext(inputtext: String?) {}
    public override fun onBackPressed() {
        Log.d("CDA", "onBackPressed Called")
        /*
       Intent setIntent = new Intent(Intent.ACTION_MAIN);
        setIntent.addCategory(Intent.CATEGORY_HOME);
       setIntent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
       startActivity(setIntent);
       */super@SearchKeyBoardAct.finish()
        super.onBackPressed()

        /*
        SearchKeyBoardAct.super.finish();

        HashMap<String, String> map = CorpusUtilityorig.getpreferences();
        Bundle dataBundle=new Bundle();
        map.get(SURAH_ARABIC_NAME);
        dataBundle.putString(SURAH_ARABIC_NAME,map.get(SURAH_ARABIC_NAME));
        dataBundle.putInt(CHAPTER, Integer.parseInt(map.get(CHAPTER)));
        dataBundle.putInt(AYAH_ID, Integer.parseInt(map.get(AYAH_ID)));

        Intent intent = new Intent(SearchKeyBoardAct.this, QuranGrammarAct.class);
        intent.putExtras(dataBundle);
        finish();
        startActivity(intent);
      */
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.search_key_activity_autocomplete)
        KeyboardUtil.hideKeyboard(this@SearchKeyBoardAct)
        keyboard = findViewById(id.arabic_keyboard)
        val callButton: FloatingTextButton = findViewById(id.action_buttons)
        callButton.setOnClickListener(View.OnClickListener({ view: View? ->
            super@SearchKeyBoardAct.finish()

            /*
        HashMap<String, String> map = CorpusUtilityorig.getpreferences();
        Bundle dataBundle=new Bundle();
        map.get(SURAH_ARABIC_NAME);
        dataBundle.putString(SURAH_ARABIC_NAME,map.get(SURAH_ARABIC_NAME));
        dataBundle.putInt(CHAPTER, Integer.parseInt(map.get(CHAPTER)));
        dataBundle.putInt(AYAH_ID, Integer.parseInt(map.get(AYAH_ID)));

            Intent intent = new Intent(SearchKeyBoardAct.this, QuranGrammarAct.class);
        intent.putExtras(dataBundle);
        finish();
        startActivity(intent);
   */super@SearchKeyBoardAct.finish()
            super.onBackPressed()
        }))
        //    hideKeyboardSoft();
        val ic: InputConnection
        SetUpAutoComplete()
        ic = actv!!.onCreateInputConnection(EditorInfo())
        // InputConnection ic = editTextAuto.onCreateInputConnection(new EditorInfo());
        setInputConnection(ic)
        init()
        // kb. getCharSequence();
    }

    private fun SetUpAutoComplete() {
        KeyboardUtil.hideKeyboard(this@SearchKeyBoardAct)
        val root: Array<String?>
        val util: Utils = Utils(this@SearchKeyBoardAct)
        //  ArrayList<MujarradVerbs> verbAll = util.getMujarradAall();
        qurandictionaryArrayList = util.getQuranDictionary()
        val size: Int = qurandictionaryArrayList.size
        root = arrayOfNulls(size)
        var i: Int = 0
        for (entity: qurandictionary in qurandictionaryArrayList) {
            val roots: String = entity.getRootarabic()
            root.get(i++) = roots
        }
        val h: HashSet<*> = HashSet<Any?>(Arrays.asList(*root))
        val aList2: List<*> = ArrayList(h)
        val adapters: ArrayAdapter<*> = ArrayAdapter(this, layout.my_simple_list_item, aList2)
        val listadapters: ArrayAdapter<*> =
            ArrayAdapter<Any?>(this, layout.my_simple_list_item, root)
        //Getting the instance of AutoCompleteTextView
        actv = findViewById<View>(id.autoCompleteTextView) as AutoCompleteTextView?
        val listdisp: ListView = findViewById(id.list_item)
        listdisp.setAdapter(listadapters)
        listdisp.setOnItemClickListener(AdapterView.OnItemClickListener({ adapterView: AdapterView<*>?, view: View?, position: Int, l: Long ->
// here you code
            val qurandictionary: qurandictionary = qurandictionaryArrayList.get(position)
            launchActivity(qurandictionary.getRootarabic())
        }))
        val sizes: Int = 1300
        actv!!.setDropDownHeight(sizes)
        actv!!.setThreshold(1) //will start working from first character
        actv!!.setAdapter(adapters) //setting the adapter data into the AutoCompleteTextView
        actv!!.setTextColor(Color.RED)
        actv!!.setTextSize(50.00.toFloat())
        //   editTextAuto = findViewById(R.id.autoCompleteTextView);
        actv!!.setRawInputType(InputType.TYPE_CLASS_TEXT)
        actv!!.setTextIsSelectable(true)
        //   KeyboardUtil.hideKeyboard(this);
        actv!!.setShowSoftInputOnFocus(false)
        actv!!.setOnFocusChangeListener(OnFocusChangeListener({ view: View?, hasFocus: Boolean ->
            if (hasFocus) {
                keyboard!!.setVisibility(LinearLayout.VISIBLE)
                //     actv.showDropDown();
                if (tlist != null) tlist!!.setAdapter(null)
                if (mlist != null) mlist!!.setAdapter(null)
            } //   keyboard.setVisibility(LinearLayout.GONE);
        }))
    }

    private fun init() {
        quranbtn = findViewById(id.qurangrammar)
        layoutBottomSheet = findViewById(id.bottom_sheet)
        sheetBehavior = BottomSheetBehavior.from(R.layoutBottomSheet)
        floatingActionButton = findViewById(id.fab)
        keyboard = findViewById(id.arabic_keyboard)
        val key_delete: Button = findViewById(id.key_delete)
        val key_AC: Button = findViewById(id.key_AC)
        val key_enter: Button = findViewById(id.key_enter)
        keyboard = findViewById(id.arabic_keyboard)
        val dhad: Button = findViewById(id.dhad)
        val suwad: Button = findViewById(id.suwad)
        val qaf: Button = findViewById(id.qaf)
        val fa: Button = findViewById(id.fa)
        val ghain: Button = findViewById(id.ghain)
        val ayn: Button = findViewById(id.ayn)
        val haaa: Button = findViewById(id.haaa)
        val kha: Button = findViewById(id.kha)
        val ha: Button = findViewById(id.ha)
        val jeem: Button = findViewById(id.jeem)
        floatingActionButton.setOnClickListener(this)
        dhad.setOnClickListener(this)
        suwad.setOnClickListener(this)
        qaf.setOnClickListener(this)
        fa.setOnClickListener(this)
        ghain.setOnClickListener(this)
        ayn.setOnClickListener(this)
        haaa.setOnClickListener(this)
        kha.setOnClickListener(this)
        ha.setOnClickListener(this)
        jeem.setOnClickListener(this)
        keyValues.put(id.dhad, "ض")
        keyValues.put(id.suwad, "ص")
        keyValues.put(id.qaf, "ق")
        keyValues.put(id.fa, "ف")
        keyValues.put(id.ghain, "غ")
        keyValues.put(id.ayn, "ع")
        keyValues.put(id.haaa, "ه")
        keyValues.put(id.kha, "خ")
        keyValues.put(id.ha, "ح")
        keyValues.put(id.jeem, "ج")
        val sheen: Button = findViewById(id.sheen)
        val seen: Button = findViewById(id.seen)
        val ya: Button = findViewById(id.ya)
        val ba: Button = findViewById(id.ba)
        val lam: Button = findViewById(id.lam)
        val alif: Button = findViewById(id.hamza)
        val ta: Button = findViewById(id.ta)
        val nun: Button = findViewById(id.nun)
        val meem: Button = findViewById(id.meem)
        val kaf: Button = findViewById(id.kaf)
        sheen.setOnClickListener(this)
        seen.setOnClickListener(this)
        ya.setOnClickListener(this)
        ba.setOnClickListener(this)
        lam.setOnClickListener(this)
        alif.setOnClickListener(this)
        ta.setOnClickListener(this)
        nun.setOnClickListener(this)
        meem.setOnClickListener(this)
        kaf.setOnClickListener(this)
        //   key00.setOnClickListener(this);
        key_delete.setOnClickListener(this)
        key_AC.setOnClickListener(this)
        key_enter.setOnClickListener(this)
        //  key_dot.setOnClickListener(this);
        keyValues.put(id.sheen, "ش")
        keyValues.put(id.seen, "س")
        keyValues.put(id.ya, "ي")
        keyValues.put(id.ba, "ب")
        keyValues.put(id.lam, "ل")
        keyValues.put(id.hamza, "ء")
        keyValues.put(id.ta, "ت")
        keyValues.put(id.nun, "ن")
        keyValues.put(id.meem, "م")
        keyValues.put(id.kaf, "ك")
        val zoay: Button = findViewById(id.zoay)
        val toay: Button = findViewById(id.toay)
        val dhal: Button = findViewById(id.dhal)
        val dal: Button = findViewById(id.dal)
        val zaa: Button = findViewById(id.zaa)
        val raa: Button = findViewById(id.raa)
        val waw: Button = findViewById(id.waw)
        val tamarboot: Button = findViewById(id.tamarboota)
        val tha: Button = findViewById(id.tha)
        zoay.setOnClickListener(this)
        toay.setOnClickListener(this)
        dhal.setOnClickListener(this)
        dal.setOnClickListener(this)
        zaa.setOnClickListener(this)
        raa.setOnClickListener(this)
        waw.setOnClickListener(this)
        tamarboot.setOnClickListener(this)
        tha.setOnClickListener(this)
        keyValues.put(id.zoay, "ظ")
        keyValues.put(id.toay, "ط")
        keyValues.put(id.dhal, "ذ")
        keyValues.put(id.dal, "د")
        keyValues.put(id.zaa, "ز")
        keyValues.put(id.raa, "ر")
        keyValues.put(id.waw, "و")
        keyValues.put(id.tamarboota, "ة")
        keyValues.put(id.tha, "ث")
    }

    public override fun onClick(view: View) {
        //   hideKeyboardSoft();
        sheetBehavior!!.setBottomSheetCallback(object : BottomSheetCallback() {
            public override fun onStateChanged(bottomSheet: View, newState: Int) {
                when (newState) {
                    BottomSheetBehavior.STATE_HIDDEN, BottomSheetBehavior.STATE_DRAGGING, BottomSheetBehavior.STATE_SETTLING, BottomSheetBehavior.STATE_HALF_EXPANDED -> {}
                    BottomSheetBehavior.STATE_EXPANDED -> {}
                    BottomSheetBehavior.STATE_COLLAPSED -> {}
                }
            }

            public override fun onSlide(bottomSheet: View, slideOffset: Float) {}
        })
        if (inputConnection == null) {
            val logTag: String = "Keyboard"
            Log.i(logTag, "Input connection == null")
            return
        }
        val currentText: CharSequence =
            inputConnection!!.getExtractedText(ExtractedTextRequest(), 0).text
        val beforeCursorText: CharSequence? =
            inputConnection!!.getTextBeforeCursor(currentText.length, 0)
        val afterCursorText: CharSequence? =
            inputConnection!!.getTextAfterCursor(currentText.length, 0)
        when (view.getId()) {
            id.fab -> {
                toggleBottomSheet()
                val charSequence: CharSequence? =
                    inputConnection!!.getTextBeforeCursor(currentText.length, 0)
                if (charSequence.toString().length == 3) {
                    setInputtext(charSequence.toString())
                    InitSelecton(charSequence.toString())
                }
            }

            id.key_enter -> {
                val charSequence: CharSequence? =
                    inputConnection!!.getTextBeforeCursor(currentText.length, 0)
                if (charSequence.toString().length == 3) {
                    setInputtext(charSequence.toString())
                    InitSelecton(charSequence.toString())
                }
            }

            id.key_delete -> {
                val selectedText: CharSequence = inputConnection!!.getSelectedText(0)
                val charSequences: CharSequence? = inputConnection!!.getTextBeforeCursor(10, 10)
                if (TextUtils.isEmpty(selectedText)) inputConnection!!.deleteSurroundingText(
                    1,
                    0
                ) else inputConnection!!.commitText("", 1)
            }

            id.key_AC -> inputConnection!!.deleteSurroundingText(
                beforeCursorText!!.length,
                afterCursorText!!.length
            )

            else -> inputConnectionCommitText(view)
        }
    }

    fun toggleBottomSheet() {
        if (sheetBehavior!!.getState() != BottomSheetBehavior.STATE_EXPANDED) {
            sheetBehavior!!.setState(BottomSheetBehavior.STATE_EXPANDED)
            //    btnBottomSheet.setText("Close sheet");
        } else {
            sheetBehavior!!.setState(BottomSheetBehavior.STATE_COLLAPSED)
            //    btnBottomSheet.setText("Expand sheet");
        }
    }

    fun setInputConnection(ic: InputConnection?) {
        inputConnection = ic
    }

    private fun inputConnectionCommitText(view: View) {
        val value: String = keyValues.get(view.getId())
        inputConnection!!.commitText(value, 1)
    }

    private fun InitSelecton(roots: String) {
        keyboard!!.setVisibility(LinearLayout.GONE)
        actv!!.clearFocus()
        val split: Array<String> =
            roots.split(",".toRegex()).dropLastWhile({ it.isEmpty() }).toTypedArray()
        val root: String = split.get(0)
        tlist = ListView(this@SearchKeyBoardAct)
        mlist = ListView(this@SearchKeyBoardAct)
        val utils: DatabaseUtils = DatabaseUtils(this@SearchKeyBoardAct)
        val util: Utils = Utils(this@SearchKeyBoardAct)
        util.getQuranDictionary()
        launchActivity(root)
    }

    private fun launchActivity(root: String) {
        val bundle: Bundle = Bundle()
        //   Intent intent = new Intent(getActivity(), NounOccuranceAsynKAct.class);
        val intent: Intent = Intent(this@SearchKeyBoardAct, SearchResult::class.java)
        //   getTypedValues();
        bundle.putString(Constant.QURAN_VERB_ROOT, root)
        intent.putExtras(bundle)
        //   intent.putExtra(QURAN_VERB_ROOT,vb.getRoot());
        startActivity(intent)
    }
}