package com.example.mushafconsolidated.Activityimport

import android.os.Bundle
import android.preference.PreferenceActivity


class ThemePreferenceActivity constructor() : PreferenceActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        addPreferencesFromResource(xml.preferences)
        findPreference("theme").setOnPreferenceChangeListener(
            RefershActivityOnPreferenceChangeListener(ThemePreferenceActivity.Companion.RESULT_CODE_THEME_UPDATED)
        )
    }

    private inner class RefershActivityOnPreferenceChangeListener constructor(private val resultCode: Int) :
        Preference.OnPreferenceChangeListener {
        public override fun onPreferenceChange(p: Preference, newValue: Any): Boolean {
            setResult(resultCode)
            return true
        }
    }

    companion object {
        val RESULT_CODE_THEME_UPDATED: Int = 1
    }
}