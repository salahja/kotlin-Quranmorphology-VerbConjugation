package com.example.mushafconsolidated.Activity

import androidx.navigation.ui.AppBarConfiguration

class SurahActivity : BaseActivity() {
    private val appBarConfiguration: AppBarConfiguration? = null
    private var parentRecyclerView: RecyclerView? = null

    //   private RecyclerView.Adapter ParentAdapter;
    private var ParentAdapter: NewSurahDisplayAdapter? = null

    //  SurahDisplayAdapter ParentAdapter;
    private val mItemClickListener: OnItemClickListener? = null
    private val isfragmentshowing = true
    private val drop: ImageView? = null
    private val devIndicatorView: TextView? = null
    private val passdataInterface: PassdataInterface? = null
    private val datapasser: PassdataInterface? = null
    private var lastreadchapterno = 0
    private var lastreadverseno = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.list_surah_juz)
        //    Toolbar toolbar = findViewById(R.id.toolbar);
        //setSupportActionBar(toolbar);
        //  getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        //  getSupportActionBar().setTitle(R.string.toolbar_title);
        val utils = Utils(this)
        val allAnaChapters = utils.allAnaChapters
        val imgs = this.resources.obtainTypedArray(R.array.sura_imgs)
        val mLayoutManager = GridLayoutManager(this, 2)
        // parentRecyclerView = view.findViewById(R.id.juzRecyclerView);
        parentRecyclerView = findViewById(id.wordByWordRecyclerView)
        val lastread = findViewById<MaterialButton>(id.lastread)
        val kahaf = findViewById<TextView>(id.kahaf)
        val ayakursi = findViewById<TextView>(id.ayatkursi)
        val pref = getSharedPreferences("lastread", MODE_PRIVATE)
        lastreadchapterno = pref.getInt(Constant.CHAPTER, 1)
        lastreadverseno = pref.getInt(Constant.AYAH_ID, 1)
        lastread.text = "Last read:Surah:$lastreadchapterno Ayah:$lastreadverseno"
        kahaf.setText(string.linkkahaf)
        lastread.setOnClickListener { //
            val intent = Intent(QuranGrammarApplication.getContext(), QuranGrammarAct::class.java)
            //  Intent intent = new Intent(DarkThemeApplication.getContext(), ReadingSurahPartActivity.class);
            intent.putExtra("chapter", lastreadchapterno)
            intent.putExtra("chapterorpart", true)
            intent.putExtra("partname", allAnaChapters[lastreadchapterno - 1].getAbjadname())
            intent.putExtra(Constant.AYAH_ID, lastreadverseno)
            intent.putExtra(Constant.AYAHNUMBER, lastreadverseno)
            startActivity(intent)
        }
        kahaf.setOnClickListener {
            val intent = Intent(QuranGrammarApplication.getContext(), QuranGrammarAct::class.java)
            //  Intent intent = new Intent(DarkThemeApplication.getContext(), ReadingSurahPartActivity.class);
            intent.putExtra("chapter", 18)
            intent.putExtra("chapterorpart", true)
            intent.putExtra("partname", allAnaChapters[18].getAbjadname())
            intent.putExtra("verseno", 1)
            intent.putExtra(Constant.AYAH_ID, 1)
            startActivity(intent)
        }
        ayakursi.setOnClickListener {
            val intent = Intent(QuranGrammarApplication.getContext(), QuranGrammarAct::class.java)
            //  Intent intent = new Intent(DarkThemeApplication.getContext(), ReadingSurahPartActivity.class);
            intent.putExtra("chapter", 2)
            intent.putExtra("chapterorpart", true)
            intent.putExtra("partname", allAnaChapters[2].getAbjadname())
            intent.putExtra("verseno", 255)
            intent.putExtra(Constant.AYAH_ID, 255)
            startActivity(intent)
        }
        parentRecyclerView.setLayoutManager(mLayoutManager)
        parentRecyclerView.setHasFixedSize(true)
        parentRecyclerView.setLayoutManager(mLayoutManager)
        ParentAdapter = NewSurahDisplayAdapter(this, allAnaChapters)
        ParentAdapter!!.setUp(allAnaChapters)
        parentRecyclerView.setAdapter(ParentAdapter)
        ParentAdapter!!.SetOnItemClickListener { v, position ->
            // TranslationEntity entity = loadedTranslation.get(position);
            val entity = ParentAdapter!!.getItem(position) as ChaptersAnaEntity
            // View id1 =       v.findViewById(R.id.translationid);
            // View id2 =       v.findViewById(R.id.authorname);
            // View id3 =      v.findViewById(R.id.languagename);
            val bundle = Bundle()
            //   Intent intent = new Intent(getActivity(), NounOccuranceAsynKAct.class);
            //   Toast.makeText(SearchActivity.this, "tobe downloaded click", Toast.LENGTH_SHORT).show();
        }
    }
}