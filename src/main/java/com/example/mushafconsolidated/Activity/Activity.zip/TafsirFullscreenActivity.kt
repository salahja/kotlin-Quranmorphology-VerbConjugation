import android.annotation.SuppressLint
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.view.View
import android.view.WindowInsets
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.ActionBar
import com.example.Constant
import com.example.mushafconsolidated.Activity.BaseActivity
import com.example.mushafconsolidatedimport.Utils
import com.google.android.material.appbar.MaterialToolbar

class TafsirFullscreenActivity constructor() : BaseActivity() {
    private val mHideHandler: Handler = Handler((Looper.myLooper())!!)
    private val mContentView: View? = null
    private val mHidePart2Runnable: Runnable = object : Runnable {
        @SuppressLint("InlinedApi")
        public override fun run() {
            // Delayed removal of status and navigation bar
            if (Build.VERSION.SDK_INT >= 30) {
                mContentView!!.getWindowInsetsController()!!.hide(
                    WindowInsets.Type.statusBars() or WindowInsets.Type.navigationBars()
                )
            } else {
                // Note that some of these constants are new as of API 16 (Jelly Bean)
                // and API 19 (KitKat). It is safe to use them, as they are inlined
                // at compile-time and do nothing on earlier devices.
                mContentView!!.setSystemUiVisibility(
                    (View.SYSTEM_UI_FLAG_LOW_PROFILE
                            or View.SYSTEM_UI_FLAG_FULLSCREEN
                            or View.SYSTEM_UI_FLAG_LAYOUT_STABLE
                            or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                            or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION
                            or View.SYSTEM_UI_FLAG_HIDE_NAVIGATION)
                )
            }
        }
    }
    private val mControlsView: View? = null

    /**
     * Touch listener to use for in-layout UI controls to delay hiding the
     * system UI. This is to prevent the jarring behavior of controls going away
     * while interacting with activity UI.
     */
    //  private ActivityTafsirFullscreenBinding binding;
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_tafsir_fullscreen)
        val bundle: Bundle? = getIntent().getExtras()
        val sura: Int = bundle!!.getInt(Constant.SURAH_ID)
        val ayah: Int = bundle.getInt(Constant.AYAH_ID)
        val surahname: String? = bundle.getString(Constant.SURAH_ARABIC_NAME)
        val utils: Utils = Utils(this)
        val materialToolbar: MaterialToolbar? = findViewById(id.toolbarmain)
        setSupportActionBar(materialToolbar)
        //   getSupportActionBar().setDisplayHomeAsUpEnabled(true);
        if (materialToolbar != null) {
            setSupportActionBar(materialToolbar)
            getSupportActionBar()!!.setDisplayShowHomeEnabled(true)
        }
        val list: List<QuranEntity> = Utils.Companion.getsurahayahVerses(sura, ayah)
        val actionBar: ActionBar? = getSupportActionBar()
        val sourcelable: TextView = findViewById(id.tvSourceLabel)
        val tafsir: TextView = findViewById(id.tvTafsir)
        val translation: TextView = findViewById(id.tvTranslation)
        val tvaryah: TextView = findViewById(id.tvData)
        val button: Button = findViewById(id.detailsbutton)
        button.setText(sura.toString() + ":" + ayah + " " + surahname)
        sourcelable.setText("Arabic Ayah")
        val tafsir_kathir: String = list.get(0).getTafsir_kathir()
        val tafsir_kathirs: String = tafsir_kathir.replace("<b>", "")
        val tafsir_kathissr: String = tafsir_kathirs.replace("</b>", "")
        tafsir.setText(tafsir_kathissr)
        translation.setText(list.get(0).getTranslation())
        tvaryah.setText(list.get(0).getQurantext())
    }

    public override fun onBackPressed() {
        // code here to show dialog
        super.onBackPressed() // optional depending on your needs
        finish()
    }

    companion object {
        /**
         * Whether or not the system UI should be auto-hidden after
         * [.AUTO_HIDE_DELAY_MILLIS] milliseconds.
         */
        private val AUTO_HIDE: Boolean = true

        /**
         * If [.AUTO_HIDE] is set, the number of milliseconds to wait after
         * user interaction before hiding the system UI.
         */
        private val AUTO_HIDE_DELAY_MILLIS: Int = 3000

        /**
         * Some older devices needs a small delay between UI widget updates
         * and a change of the status and navigation bar.
         */
        private val UI_ANIMATION_DELAY: Int = 300
    }
}