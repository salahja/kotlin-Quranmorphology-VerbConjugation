package com.example.mushafconsolidated.Activity

android.graphics.Colorimport android.graphics.drawable.ColorDrawableimport android.os.Buildimport android.os.Bundle   import android.text.TextUtilsimport android.view.Gravityimport android.view.LayoutInflaterimport android.view.Menuimport android.view.MenuItemimport android.view.Viewimport android.view.Windowimport androidx.annotation .RequiresApiimport androidx.appcompat.app.AlertDialogimport androidx.appcompat.widget.Toolbarimport androidx.preference.PreferenceManagerimport androidx.recyclerview.widget.LinearLayoutManagerimport androidx.recyclerview.widget.RecyclerViewimport com.example.Constantimport com.example.mushafconsolidated.Adapters.TopicFlowAyahWordAdapterimport com.example.mushafconsolidated.Entities.BookMarksimport com.example.mushafconsolidated.Rimport com.example.mushafconsolidated.R.animimport com.example.mushafconsolidated.R.idimport com.example.mushafconsolidated.R.layoutimport com.example.mushafconsolidated.R.styleimport com.example.mushafconsolidated.R.xmlimport com.example.mushafconsolidated.Utilsimport com.example.mushafconsolidated.fragments.GrammerFragmentsBottomSheetimport com.example.mushafconsolidated.fragments.WordAnalysisBottomSheetimport com.example.mushafconsolidated.intrface.OnItemClickListenerOnLongimport com.example.mushafconsolidated.model.CorpusAyahWordimport com.example.mushafconsolidated.model.CorpusWbwWordimport com.google.android.material.snackbar.Snackbar
//import com.example.mushafconsolidated.Entities.JoinVersesTranslationDataTranslation;
class TopicDetailAct : BaseActivity(), OnItemClickListenerOnLong {
    // --Commented out by Inspection (24/10/22, 10:04 PM):int mudhafColoragainstBlack, // --Commented out by Inspection (24/10/22, 10:04 PM):mausofColoragainstBlack, sifatColoragainstBlack, // --Commented out by Inspection (24/10/22, 10:03 PM):brokenPlurarColoragainstBlack, shartagainstback;
    // --Commented out by Inspection (24/10/22, 10:04 PM):private NavigationView navigationView;
    // --Commented out by Inspection (24/10/22, 10:04 PM):private MaterialToolbar materialToolbar;
    // --Commented out by Inspection (24/10/22, 10:03 PM):private FlowAyahWordAdapterPassage flowAyahWordAdapterpassage;
    private var corpusayahWordArrayList: ArrayList<CorpusAyahWord>? = null

    // --Commented out by Inspection (24/10/22, 10:04 PM):private int chapterno;
    // --Commented out by Inspection START (24/10/22, 10:03 PM):
    //    public int getVersescount() {
    //        return versescount;
    //    }
    // --Commented out by Inspection STOP (24/10/22, 10:03 PM)
    // --Commented out by Inspection START (24/10/22, 10:03 PM):
    //    public int getChapterno() {
    //        return chapterno;
    //    }
    // --Commented out by Inspection STOP (24/10/22, 10:03 PM)
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.menu_dua_group, menu)
        return true
    }

    override fun onPrepareOptionsMenu(menu: Menu): Boolean {
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        val id = item.itemId
        return super.onOptionsItemSelected(item)
    }

    @RequiresApi(api = Build.VERSION_CODES.Q)
    override fun onCreate(savedInstanceState: Bundle?) {
        // --Commented out by Inspection (24/10/22, 10:04 PM):private boolean kana;
        val shared = PreferenceManager.getDefaultSharedPreferences(this@TopicDetailAct)
        val preferences = shared.getString("themePref", "dark")
        when (preferences) {
            "light" -> switchTheme("light")
            "dark" -> switchTheme("dark")
            "blue" -> switchTheme("blue")
            "green" -> switchTheme("light")
            "brown" -> switchTheme("brown")
        }
        super.onCreate(savedInstanceState)
        setContentView(R.layout.topic_search_main)
        val toolbar = findViewById<Toolbar>(id.toolbar)
        setSupportActionBar(toolbar)
        //     Objects.requireNonNull(getSupportActionBar()).setDisplayHomeAsUpEnabled(true);
        android.preference.PreferenceManager.setDefaultValues(this, xml.preferences, false)
        val bundle = intent
        if (bundle.extras != null) {
            val bundles = intent.extras
            val map = bundle.getSerializableExtra("map") as HashMap<String, String>?
            var surahname: String? = null
            if (map!!.size != 0) {
                bundles!!.getSerializable("map")
                //  LinkedHashMap map = (LinkedHashMap) bundles.get("map");
                val keys: Set<String> = map.keys
                corpusayahWordArrayList = ArrayList()
                for (key in keys) {
                    val splits = map[key]!!
                    val split =
                        splits.split(",".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
                    for (s in split) {
                        getwbwy(s, key)
                    }
                }
            } else {
                val surah = bundle.extras!!.getInt(Constant.SURAH_ID)
                val ayah = bundle.extras!!.getInt(Constant.AYAH_ID)
                val header = bundle.extras!!.getString(Constant.ARABICWORD)
                surahname = bundle.extras!!.getString(Constant.SURAH_ARABIC_NAME)
                corpusayahWordArrayList = ArrayList()
                getwbwy(surah, ayah, header)
            }
            //  getwbwy(aref);
            val linearLayoutManager = LinearLayoutManager(applicationContext)
            val listener: OnItemClickListenerOnLong = this
            val flowAyahWordAdapter =
                TopicFlowAyahWordAdapter(corpusayahWordArrayList, listener, surahname)
            val parentRecyclerView = findViewById<RecyclerView>(id.recycler_view)
            parentRecyclerView.layoutManager = linearLayoutManager
            flowAyahWordAdapter.addContext(this@TopicDetailAct)
            parentRecyclerView.setHasFixedSize(true)
            parentRecyclerView.adapter = flowAyahWordAdapter
            flowAyahWordAdapter.notifyDataSetChanged()
        }
    }

    private fun getwbwy(surah: Int, ayah: Int, header: String?) {
        preparewbwarray(header, surah, ayah)
    }

    private fun getwbwy(str: String, header: String) {
        val ss = str.split(":".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        val suraid = ss[0].trim { it <= ' ' }.toInt()
        val ayah = ss[1].trim { it <= ' ' }.toInt()
        preparewbwarray(header, suraid, ayah)
    }

    private fun preparewbwarray(header: String?, suraid: Int, ayah: Int) {
        val utils = Utils(this@TopicDetailAct)
        //  CorpusWbwWord word = new CorpusWbwWord();
        val ayahWord = CorpusAyahWord()
        val wordArrayList = ArrayList<CorpusWbwWord>()
        val wbw = utils.getCorpusWbwBySurahAyahtopic(suraid, ayah)
        //    final Object o6 = wbwa.get(verseglobal).get(0);
        val sb = String ()
        for (pojo in wbw) {
            val word = CorpusWbwWord()
            word.surahId = pojo.surah
            sb.append(pojo.araone).append(pojo.aratwo)
            val sequence = TextUtils.concat(
                pojo.araone + pojo.aratwo +
                        pojo.arathree + pojo.arafour
            )
            //   Object o4 = pojo.getWord();
            val en: Any = pojo.en
            val bn: Any = pojo.bn
            val ind: Any = pojo.getIn()
            val ur = pojo.ur
            word.rootword = pojo.root_a
            word.surahId = pojo.surah
            word.verseId = pojo.ayah
            word.wordno = pojo.wordno
            word.wordcount = pojo.wordcount
            word.wordsAr = sequence.toString()
            //  word.setWordindex(getIndex(pojo.getQuranverses()));
            word.translateEn = en.toString()
            word.translateBn = bn.toString()
            word.translateIndo = ind.toString()
            word.translationUrdu = ur
            word.araone = pojo.araone
            word.aratwo = pojo.aratwo
            word.arathree = pojo.arathree
            word.arafour = pojo.arafour
            word.arafive = pojo.arafive
            word.tagone = pojo.tagone
            word.tagtwo = pojo.tagtwo
            word.tagthree = pojo.tagthree
            word.tagfour = pojo.tagfour
            word.tagfive = pojo.tagfive
            word.passage_no = pojo.passage_no
            word.detailsone = pojo.detailsone
            word.detailstwo = pojo.detailstwo
            word.detailsthree = pojo.detailsthree
            word.detailsfour = pojo.detailsfour
            word.detailsfive = pojo.detailsfive
            word.corpusSpnnableQuranverse = SpannableString .valueOf(pojo.qurantext)
            //    word.setQuranversestr(pojo.getQuranverses());
            word.quranversestr = pojo.qurantext
            word.translations = pojo.translation
            word.surahId = pojo.surah
            word.verseId = pojo.ayah
            word.wordno = pojo.wordno
            word.wordcount = pojo.wordcount
            ayahWord.ar_irab_two = pojo.ar_irab_two
            ayahWord.tafsir_kathir = pojo.tafsir_kathir
            //  ayahWord.setSpannableverse(SpannableString .valueOf(pojo.getQuranverses()));
            ayahWord.spannableverse = SpannableString.valueOf(pojo.qurantext)
            ayahWord.passage_no = pojo.passage_no
            ayahWord.en_transliteration = pojo.en_transliteration
            ayahWord.en_jalalayn = pojo.en_jalalayn
            //  ayahWord.setSpannableverse(SpannableString .valueOf(pojo.getQuranverses()));
            ayahWord.en_arberry = pojo.en_arberry
            ayahWord.quranTranslate = pojo.translation
            ayahWord.ur_jalalayn = pojo.ur_jalalayn
            //  ayahWord.setSpannableverse(SpannableString .valueOf(pojo.getQuranverses()));
            ayahWord.ur_junagarhi = pojo.ur_junagarhi
            ayahWord.topictitle = header
            wordArrayList.add(word)
            ayahWord.word = wordArrayList
            // wordArrayListpassage.add(word);
        }
        corpusayahWordArrayList!!.add(ayahWord)
        println("check")
    }

    private fun LoadItemList(dataBundle: Bundle, word: CorpusAyahWord) {
        val   = AlertDialog. (this)
         .setCancelable(false) // if you want user to wait for some process to finish,
         .setView(R.layout.layout_loading_dialog)
        val item = GrammerFragmentsBottomSheet()
        val fragmentManager = supportFragmentManager
        item.arguments = dataBundle
        val data = arrayOf(
            word.word[0].surahId.toString(),
            word.word[0].verseId.toString(),
            word.quranTranslate,
            1.toString()
        )
        val transactions = fragmentManager.beginTransaction()
            .setCustomAnimations(anim.abc_slide_in_top, android.R.anim.fade_out)
        transactions.show(item)
        GrammerFragmentsBottomSheet.Companion.newInstance(data)
            .show(supportFragmentManager, WordAnalysisBottomSheet.Companion.TAG)
    }

    override fun onItemClick(view: View, position: Int) {
        qurangrammarmenu(view, position)
    }

    fun qurangrammarmenu(view: View, position: Int) {
        var view = view
        val tag = view.tag
        var bookmarkview: View? = null
        val overflow = view.findViewById<View>(id.ivActionOverflow)
        if (tag == "bookmark") {
            bookMarkSelected(position, bookmarkview)
            //  SurahAyahPicker();
        } else if (tag == "overflow_img") {
            val   = AlertDialog. (this@TopicDetailAct)
            val factory = LayoutInflater.from(this@TopicDetailAct)
            view = factory.inflate(R.layout.topic_popup_layout, null)
            val tafsirtag = view.findViewById<View>(id.tafsir)
            bookmarkview = view.findViewById(id.bookmark)
             .setView(view)
            val location = IntArray(2)
            overflow.getLocationOnScreen(location)
            val dialog =  .create()
            dialog.window!!.setBackgroundDrawable(ColorDrawable(Color.TRANSPARENT))
            dialog.requestWindowFeature(Window.FEATURE_NO_TITLE)
            val wmlp = dialog.window!!.attributes
            wmlp.gravity = Gravity.TOP or Gravity.START
            wmlp.x = location[0] //x position
            wmlp.y = location[1] //y position
            dialog.window!!.attributes.windowAnimations = style.WindowAnimationTransition //style id
            dialog.show()
            tafsirtag.setOnClickListener { view12: View? ->
                val readingintent =
                    Intent(this@TopicDetailAct, TafsirFullscreenActivity::class.java)
                //  flowAyahWordAdapter.getItem(position);
                val chapter_no = corpusayahWordArrayList!![position].word[0].surahId
                val verse = corpusayahWordArrayList!![position].word[0].verseId
                val surahArrays = resources.getStringArray(R.array.suraharabic)
                val surahname = surahArrays[chapter_no - 1]
                readingintent.putExtra(Constant.SURAH_ID, chapter_no)
                readingintent.putExtra(Constant.AYAH_ID, verse)
                readingintent.putExtra(Constant.SURAH_ARABIC_NAME, surahname)
                startActivity(readingintent)
                dialog.dismiss()
            }
            val finalBookmarkview = bookmarkview
            bookmarkview.setOnClickListener(View.OnClickListener { view1: View? ->
                bookMarkSelected(position, finalBookmarkview)
                dialog.dismiss()
            })
            println("check")
        } else if (tag == "qurantext") {
            val word: CorpusAyahWord
            word = if (position != 0) {
                corpusayahWordArrayList!![position - 1]
            } else {
                corpusayahWordArrayList!![position]
            }
            val dataBundle = Bundle()
            dataBundle.putInt(Constant.SURAH_ID, word.word[0].surahId)
            dataBundle.putInt(Constant.AYAHNUMBER, Math.toIntExact(word.word[0].verseId.toLong()))
            LoadItemList(dataBundle, word)
        }
    }

    private fun bookMarkSelected(position: Int, bookmarkview: View?) {
        val chapter_no = corpusayahWordArrayList!![position].word[0].surahId
        val verse = corpusayahWordArrayList!![position].word[0].verseId
        val surahArrays = resources.getStringArray(R.array.suraharabic)
        val surahname = surahArrays[chapter_no - 1]
        val en = BookMarks()
        en.chapterno = chapter_no.toString()
        en.verseno = verse.toString()
        en.surahname = surahname
        //     Utils utils = new Utils(ReadingSurahPartActivity.this);
        val utils = Utils(this)
        utils.insertBookMark(en)
        val snackbar = Snackbar
            .make(bookmarkview!!, "BookMark Created", Snackbar.LENGTH_LONG)
        snackbar.setActionTextColor(Color.BLUE)
        snackbar.setTextColor(Color.CYAN)
        snackbar.setBackgroundTint(Color.BLACK)
        snackbar.show()
    }

    override fun onItemLongClick(position: Int, v: View) {
        //    Toast.makeText(this, "longclick", Toast.LENGTH_SHORT).show();
    }
}