package com.example.mushafconsolidated.Activity

import ChaptersAnaEntity
import QuranEntity
import android.content.Context
import android.media.AudioAttributes
import com.example.mushafconsolidated.Activityimport.ShowMushafActivity
import com.example.mushafconsolidated.receiversimport.FileManager
import com.example.mushafconsolidatedimport.Utils
import com.google.android.exoplayer2.ExoPlayer
import com.google.android.exoplayer2.MediaItem
import com.google.android.exoplayer2.Player
import com.google.android.exoplayer2.Tracks
import com.google.android.exoplayer2.trackselection.TrackSelectionParameters
import com.google.android.exoplayer2.ui.PlayerControlView
import com.google.android.exoplayer2.util.EventLogger
import com.google.android.exoplayer2.util.RepeatModeUtil


class myPlayer(
    var context: Context,
    private val surah: Int,
    private var marray: MutableList<MediaItem>
) {
    protected var playerView: PlayerControlView? = null
    private var player: ExoPlayer? = null
    private val trackSelectionParameters: TrackSelectionParameters? = null
    private var lastSeenTracks: Tracks? = null
    private var isMusicplaying = false
    private var pausePlayFlag = false
    private val startItemIndex = 0
    private val rangeRecitation = false
    private var marrayrange: List<MediaItem>? = null
    private val endRange = 0
    private val startRange = 0
    private val resume = false
    private val resumelastplayed = 0
    fun initplayer(marray: List<MediaItem>): ExoPlayer? {
        var marray = marray
        if (player != null) {
            player!!.release()
        }
        marray = createMediaItems()
        if (marray.isEmpty()) {
            return null
        }
        player = ExoPlayer.(context).build()
        lastSeenTracks = Tracks.EMPTY
        player!!.trackSelectionParameters = trackSelectionParameters!!
        player!!.addAnalyticsListener(EventLogger())
      //  player!!.setAudioAttributes(AudioAttributes.DEFAULT,  /* handleAudioFocus= */true)
        player!!.playWhenReady = true
        player!!.repeatMode = Player.REPEAT_MODE_ALL
        playerView!!.repeatToggleModes = RepeatModeUtil.REPEAT_TOGGLE_MODE_ONE
        playerView!!.player = player
        player!!.addListener(object : Player.Listener {
            override fun onPlaybackStateChanged(playbackState: Int) {
                if (player!!.playWhenReady && playbackState == Player.STATE_READY) {
                    isMusicplaying = true // media actually playing
                } else if (player!!.playWhenReady) {
                    isMusicplaying = false
                    // might be idle (plays after prepare()),
                    // buffering (plays when data available)
                    // or ended (plays when seek away from end)
                } else {
                    pausePlayFlag = true
                    // player paused in any state
                }
           //     super@Listener.onPlaybackStateChanged(playbackState)
            }
        })
        val haveStartPosition = startItemIndex != C.INDEX_UNSET
        if (haveStartPosition) {
            //    player.seekTo(startItemIndex, startPosition);
        }
        if (rangeRecitation) {
            marrayrange = marray.subList(startRange, endRange)
            player!!.setMediaItems(marrayrange!!,  /* resetPosition= */!haveStartPosition)
        } else {
            player!!.setMediaItems(marray,  /* resetPosition= */!haveStartPosition)
        }
        player!!.prepare()
        if (resume) {
            player!!.seekToDefaultPosition(resumelastplayed)
        }
        player!!.play()
        return player
    }

    private fun createMediaItems(): List<MediaItem> {
        val repository = Utils(
            context
        )
        val chap: List<ChaptersAnaEntity?>? = repository.getSingleChapter(surah)
        val ayaLocations: MutableList<String> = ArrayList()
        marray = ArrayList()
        val quranbySurah: List<QuranEntity?>? = Utils.Companion.getQuranbySurah(
            surah
        )
        if (quranbySurah != null) {
            for (ayaItem in quranbySurah) {
                ayaLocations.add(
                    FileManager.createAyaAudioLinkLocation(
                        context,
                        ShowMushafActivity.Companion.readerID,
                        ayaItem!!.ayah,
                        ayaItem.surah
                    )
                )
                val location = FileManager.createAyaAudioLinkLocation(
                    context,
                    ShowMushafActivity.Companion.readerID,
                    ayaItem.ayah,
                    ayaItem.surah
                )
                marray.add(MediaItem.fromUri(location))
            }
        }
        return marray
    }
}