package com.example.mushafconsolidated.Activity

import android.text.SpannableString
import com.example.mushafconsolidated.Activityimport.WordOccuranceAct

class SearchResult : WordOccuranceAct() {
    var expandLexconTitle: List<String>? = null
    var expandlexicon = LinkedHashMap<String, List<SpannableString>>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        executeDictionary()
    }

    fun executeDictionary() {
        //  ArrayList<lanelexicon> lanesDifinition = utils.getLanesDifinition(root);
        //  ArrayList<SpannableString> lanesdifinition ;
        val list: MutableList<*> = ArrayList<Any?>()
        val lanessb = String ()
        //  for (lanelexicon lanes : lanesDifinition) {
        //  <p style="margin-left:200px; margin-right:50px;">
        //    list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
        //  list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
        //  list.add(lanes.getDefinition() );
        list.add("")
        //   }
        expandlexicon["lanes Lexicon"] = list
        expandlexicon["Hans"] = list
        val expandLexconTitle: List<String>
        expandLexconTitle = ArrayList(expandlexicon.keys)
        expandNounTitles = ArrayList(expandNounVerses.keys)
        expandVerbTitles = ArrayList(expandVerbVerses.keys)
        expandNounVerses.putAll(expandlexicon)
        expandNounVerses.putAll(expandVerbVerses)
        expandNounTitles.addAll(expandLexconTitle)
        expandNounTitles.addAll(expandVerbTitles)
    }
}