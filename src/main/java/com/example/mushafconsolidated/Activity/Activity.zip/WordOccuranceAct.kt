package com.example.mushafconsolidated.Activityimport

import CorpusNounWbwOccurance
import android.text.SpannableString
import com.example.Constant
import com.example.utility.CorpusUtilityorig


open class WordOccuranceAct() : BaseActivity() {
    var corpusNounWbwOccurances: ArrayList<CorpusNounWbwOccurance>? = null
    var expandableListView: ExpandableListView? = null
    var viewPager2: ViewPager2? = null
    var isHarf = false
    var expandNounTitles: MutableList<String>? = null
    var expandVerbTitles: List<String>? = null
    var mPageNo = 0
    var imgPg: ImageView? = null
    var link: TextView? = null
    var root: String? = null
    var counter = 0
    var dialog: AlertDialog? = null
    var updatechild = LinkedHashMap<String, List<SpannableString>>()
    var expandNounVerses = LinkedHashMap<String, List<SpannableString>>()
    var expandVerbVerses = LinkedHashMap<String, List<SpannableString>>()
    var utils: Utils? = null
    var tv: TextView? = null
    var progressBar: ProgressBar? = null
    var firstcolortat = 0
    var maincolortag = 0
    var pronouncolortag = 0
    var fourcolortag = 0
    private val str2: String? = null
    private val LL: RelativeLayout? = null
    private val materialToolbar: MaterialToolbar? = null
    private val jumpto: MenuItem? = null
    private val progressBar1: ProgressBar? = null
    private val childfile: File? = null
    private val databasepath: String? = null
    private val mainDatabasesZIP: File? = null
    private val targetDirectory: File? = null
    private val `is`: FileInputStream? = null
    private val zis: ZipInputStream? = null
    private val ze: ZipEntry? = null
    private val filename: String? = null
    private var verbCorpusArrayList: ArrayList<VerbCorpusBreakup>? = null
    private var occurances: ArrayList<CorpusNounWbwOccurance>? = null
    private var nounCorpusArrayList: ArrayList<NounCorpusBreakup>? = null
    private val parentLayoutManager: LinearLayoutManager? = null
    private var shared: SharedPreferences? = null
    private val recview: RecyclerView? = null
    private val progressBarDD: ProgressDialog? = null
    private val progressBarStatus = 0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.expand_list)
        //   recview=findViewById(R.id.recyclerView);
        //  parentLayoutManager = new LinearLayoutManager(WordOccuranceAsynKAct.this);
        val bundle = intent.extras
        root = bundle!!.getString(Constant.QURAN_VERB_ROOT)
        utils = Utils(this@WordOccuranceAct)
        // String preferences = SharedPref.themePreferences();
        val   = AlertDialog. (this)
         .setCancelable(false) // if you want user to wait for some process to finish,
         .setView(R.layout.layout_loading_dialog)
        dialog =  .create()
        shared = PreferenceManager.getDefaultSharedPreferences(this)
        val whichtranslation = shared.getString("selecttranslation", "en_sahih")
        val showtranslation = shared.getBoolean("prefs_show_translation", true)
        expandableListView = findViewById<View>(id.expandableListView) as ExpandableListView
        val prefs =
            android.preference.PreferenceManager.getDefaultSharedPreferences(QuranGrammarApplication.getContext())
        val preferences = prefs.getString("theme", "dark")
        if ((preferences == "dark") || (preferences == "blue") || (preferences == "green")) {
            firstcolortat = Constant.BCYAN
            maincolortag = Constant.BYELLOW
            pronouncolortag = Constant.BBLUE
            fourcolortag = Constant.BWHITE
        } else {
            firstcolortat = Constant.WBURNTUMBER
            maincolortag =
                ContextCompat.getColor(QuranGrammarApplication.getContext(), color.prussianblue)
            pronouncolortag = Constant.WMIDNIHTBLUE
            fourcolortag = Constant.GREENDARK
        }
        val callBackbutton = findViewById<FloatingTextButton>(id.action_button)
        val pref = "dark"
        if ((pref == "dark")) {
            val color = resources.getColor(color.color_background_overlay)
            callBackbutton.backgroundColor = color
        } else {
            callBackbutton.backgroundColor = resources.getColor(color.color_background)
        }
        callBackbutton.setOnClickListener({ view: View? ->
            //  Intent quranintnt = new Intent(VerbOccuranceAsynKAct.this, ReadingSurahPartActivity.class);
            finish()
        })
        if ((root == "ACC") || (root == "LOC") || (root == "T")) {
            occurances = utils!!.getnounoccuranceHarfNasbZarf(root)
            isHarf = true
            ExecuteNounOcurrance()
        } else {
            isHarf = false
            ExecuteNounOcurrance()
        }
    }

    fun ExecuteNounOcurrance() {
        val ex = Executors.newSingleThreadExecutor()
        ex.execute(object : Runnable {
            override fun run() {
                runOnUiThread(Runnable { dialog!!.show() })
                //  occurances = utils.getNounOccuranceBreakVerses(root);
                val vroot = root!!.indexOf("ء")
                var nounroot: String? = ""
                val verb = root!!.indexOf("ا")
                var verbroot: String? = ""
                if (vroot != -1) {
                    nounroot = root!!.replace("ء", "ا")
                } else {
                    nounroot = root
                }
                if (verb != -1) {
                    verbroot = root!!.replace("ا", "ء")
                } else {
                    verbroot = root
                }
                nounCorpusArrayList = utils!!.getNounBreakup(nounroot)
                verbCorpusArrayList = utils!!.getVerbBreakUp(verbroot)
                var Lemma: String = ""
                val incexofgroup = 0
                val alist: MutableList<*> = ArrayList<Any?>()
                if (isHarf) {
                    for (vers: CorpusNounWbwOccurance in occurances!!) {
                        //    alist.add("");
                        val sb = String ()
                        val spanDark = SpannableString(vers.qurantext)
                        val spannableVerses = CorpusUtilityorig.getSpannableVerses(
                            vers.araone + vers.aratwo + vers.arathree + vers.arafour + vers.arafive,
                            vers.qurantext
                        )
                        sb.append(vers.surah).append(":").append(vers.ayah).append(":")
                            .append(vers.wordno).append("-").append(vers.en).append("-")
                        val ref = SpannableString(sb.toString())
                        ref.setSpan(
                            Constant.particlespanDark,
                            0,
                            sb.length,
                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                        )
                        val which = shared!!.getString("selecttranslation", "en_sahih")
                        var trans: SpannableString? = null
                        if ((which == "en_sahih")) {
                            trans = SpannableString.valueOf(vers.translation)
                        } else if ((which == "ur_jalalayn")) {
                            trans = SpannableString.valueOf(vers.ur_jalalayn)
                        } else if ((which == "en_jalalayn")) {
                            trans = SpannableString.valueOf(vers.en_jalalayn)
                        }
                        val charSequence = TextUtils.concat(ref, "\n ", spannableVerses)
                        alist.add(charSequence)
                        alist.add(trans)
                        expandNounVerses[sb.toString()] = alist
                    }
                }
                for (noun: NounCorpusBreakup in nounCorpusArrayList) {
                    val list: MutableList<*> = ArrayList<Any?>()
                    list.add("")
                    Lemma = noun.lemma_a
                    if ((noun.form == "null")) {
                        val sb = String ()
                        val nounexpand: String =
                            QuranMorphologyDetails.Companion.expandTags(noun.tag)
                        var times: String = ""
                        if (noun.count == 1) {
                            times = "Once"
                        } else {
                            val count = noun.count
                            val timess = count.toString()
                            times = "$timess-times"
                        }
                        sb.append(times).append(" ").append(noun.lemma_a).append(" ")
                            .append("occurs as the").append(" ").append(nounexpand)
                        expandNounVerses[sb.toString()] = list
                    } else {
                        val sb = String ()
                        val s: String =
                            QuranMorphologyDetails.Companion.expandTags(noun.propone + noun.proptwo)
                        //  String s1 = QuranMorphologyDetails.expandTags(noun.getProptwo());
                        val s2: String = QuranMorphologyDetails.Companion.expandTags(noun.tag)
                        var times: String = ""
                        if (noun.count == 1) {
                            times = "Once"
                        } else {
                            val count = noun.count
                            val timess = count.toString()
                            times = "$timess-times"
                        }
                        sb.append(times).append(" ").append(noun.lemma_a).append(" ")
                            .append("occurs as the").append(" ").append(noun.form)
                            .append(" ")
                        if (s != "null") {
                            sb.append(s).append(" ").append(" ")
                        }
                        sb.append(s2)
                        expandNounVerses[sb.toString()] = list
                    }
                }
                for (verbCorpusBreakup: VerbCorpusBreakup in verbCorpusArrayList) {
                    val list: MutableList<*> = ArrayList<Any?>()
                    list.add("")
                    Lemma = verbCorpusBreakup.lemma_a
                    if ((verbCorpusBreakup.form == "I")) {
                        val sb = String ()
                        val mujarrad: String =
                            QuranMorphologyDetails.Companion.getThulathiName(verbCorpusBreakup.thulathibab)
                                .toString()
                        sb.append(verbCorpusBreakup.count).append("-").append("times").append(" ")
                            .append(verbCorpusBreakup.lemma_a).append(" ").append("occurs as the")
                            .append(" ").append(mujarrad)
                        expandVerbVerses[sb.toString()] = list
                    } else {
                        val sb = String ()
                        val s: String =
                            QuranMorphologyDetails.Companion.expandTags(verbCorpusBreakup.tense)
                        val s1: String =
                            QuranMorphologyDetails.Companion.expandTags(verbCorpusBreakup.voice)
                        //  String s1 = QuranMorphologyDetails.expandTags(noun.getProptwo());
                        //   String s2 = QuranMorphologyDetails.expandTags(noun.get);
                        val mazeed: String =
                            QuranMorphologyDetails.Companion.getFormName(verbCorpusBreakup.form)
                                .toString()
                        sb.append(verbCorpusBreakup.count).append("-").append("times").append(" ")
                            .append(verbCorpusBreakup.lemma_a).append(" ").append("occurs as the")
                            .append(" ").append(mazeed)
                            .append(" ").append(s).append(" ").append(" ").append(s1)
                        expandVerbVerses[sb.toString()] = list
                    }
                }
                expandNounTitles = ArrayList(expandNounVerses.keys)
                expandVerbTitles = ArrayList(expandVerbVerses.keys)
                expandNounVerses.putAll(expandVerbVerses)
                expandNounTitles.addAll(expandVerbTitles)
                //post
                runOnUiThread(object : Runnable {
                    override fun run() {
                        dialog!!.dismiss()
                        // Intent intent = new Intent();
                        // intent.putExtra("result", 1);
                        //  setResult(RESULT_OK, intent);
                        val listAdapter: NounVerbOccuranceListAdapter
                        listAdapter = NounVerbOccuranceListAdapter(
                            this@WordOccuranceAct,
                            expandNounTitles,
                            expandNounVerses,
                            expandVerbVerses,
                            expandVerbTitles
                        )
                        expandableListView!!.setAdapter(listAdapter)
                        expandableListView!!.setOnGroupExpandListener(object :
                            OnGroupExpandListener {
                            override fun onGroupExpand(groupPosition: Int) {
                                val split =
                                    expandNounTitles.get(groupPosition).split("\\s".toRegex())
                                        .dropLastWhile { it.isEmpty() }
                                        .toTypedArray()
                                if (!isHarf) {
                                    if (expandNounTitles.get(groupPosition).contains("Hans")) {
                                        val ex = Executors.newSingleThreadExecutor()
                                        ex.execute(object : Runnable {
                                            override fun run() {
                                                runOnUiThread({ dialog!!.show() })
                                                var verbroot: String? = ""
                                                val indexOfHamza =
                                                    root!!.indexOf(ArabicLiterals.Hamza)
                                                val indexofAlifMaksura = root!!.indexOf(
                                                    ArabicLiterals.Ya
                                                )
                                                if (indexOfHamza != -1) {
                                                    verbroot = root!!.replace(
                                                        ArabicLiterals.Hamza.toRegex(),
                                                        ArabicLiterals.LALIF
                                                    )
                                                } else {
                                                    verbroot = root
                                                }
                                                if (indexofAlifMaksura != -1) {
                                                    verbroot = verbroot!!.replace(
                                                        ArabicLiterals.Ya.toRegex(),
                                                        ArabicLiterals.AlifMaksuraString
                                                    )
                                                }
                                                var list: MutableList<*> = ArrayList<Any?>()
                                                //   ArrayList<CorpusNounWbwOccurance> verses = utils.getNounOccuranceBreakVerses(split[1]);
                                                val lanesDifinition =
                                                    utils!!.getHansDifinition(verbroot)
                                                //    ArrayList<SpannableString> lanesdifinition;
                                                //   String  lanessb = new String ();
                                                for (hans: hanslexicon in lanesDifinition) {
                                                    //  <p style="margin-left:200px; margin-right:50px;">
                                                    //    list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    //  list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    list.add(hans.definition)
                                                    //
                                                }
                                                list = highLightParadigm(list)
                                                val finalList: List<*> = list
                                                runOnUiThread(object : Runnable {
                                                    override fun run() {
                                                        ex.shutdown()
                                                        dialog!!.dismiss()
                                                        expandNounVerses[expandNounTitles.get(
                                                            groupPosition
                                                        )] = finalList
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }

                                            private fun highLightParadigm(list: List<*>): MutableList<*> {
                                                val lists: MutableList<*> = ArrayList<Any?>()
                                                val REGEX = "aor.([\\s\\S]){3}"
                                                val pattern = Pattern.compile(REGEX)
                                                for (l: Any in list) {
                                                    val replaceAll = l.toString()
                                                        .replace("<br></br>".toRegex(), "")
                                                    val m = pattern.matcher(replaceAll)
                                                    var sb: SpannableString? = null
                                                    var indexof = 0
                                                    if (m.find()) {
                                                        println("Found value: " + m.group(0))
                                                        println("Found value: " + m.group(1))
                                                        indexof = l.toString().indexOf(m.group(0))
                                                        sb = SpannableString(l.toString())
                                                        sb.setSpan(
                                                            Constant.particlespanDark,
                                                            indexof,
                                                            m.group(0).length + indexof,
                                                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                        )
                                                        lists.add(sb)
                                                        //   System.out.println("Found value: " + m.group(2) );
                                                    } else {
                                                        lists.add(replaceAll)
                                                    }
                                                }
                                                return lists
                                            }
                                        })
                                    } else if (expandNounTitles.get(groupPosition)
                                            .contains("lanes")
                                    ) {
                                        val ex = Executors.newSingleThreadExecutor()
                                        ex.execute(object : Runnable {
                                            override fun run() {
                                                runOnUiThread({ dialog!!.show() })
                                                var list: MutableList<*> = ArrayList<Any?>()
                                                val lanesDifinition =
                                                    utils!!.getLanesDifinition(root)
                                                for (lanes: lanelexicon in lanesDifinition) {
                                                    //  <p style="margin-left:200px; margin-right:50px;">
                                                    //    list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    //  list.add("<p style=\"margin-left:200px; margin-right:50px;\">");
                                                    list.add(lanes.definition)
                                                    //
                                                }
                                                list = highLightParadigm(list)
                                                val finalList: List<*> = list
                                                runOnUiThread(object : Runnable {
                                                    override fun run() {
                                                        ex.shutdown()
                                                        dialog!!.dismiss()
                                                        expandNounVerses[expandNounTitles.get(
                                                            groupPosition
                                                        )] = finalList
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }

                                            private fun highLightParadigm(list: List<*>): MutableList<*> {
                                                val lists: MutableList<*> = ArrayList<Any?>()
                                                val REGEX = "aor.([\\s\\S]){3}"
                                                val pattern = Pattern.compile(REGEX)
                                                for (l: Any in list) {
                                                    val replaceAll = l.toString()
                                                        .replace("<br></br>".toRegex(), "")
                                                    val m = pattern.matcher(replaceAll)
                                                    var sb: SpannableString? = null
                                                    var indexof = 0
                                                    if (m.find()) {
                                                        println("Found value: " + m.group(0))
                                                        println("Found value: " + m.group(1))
                                                        indexof = l.toString().indexOf(m.group(0))
                                                        sb = SpannableString(l.toString())
                                                        sb!!.setSpan(
                                                            Constant.particlespanDark,
                                                            indexof,
                                                            m.group(0).length + indexof,
                                                            Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                        )
                                                        lists.add(sb)
                                                        //   System.out.println("Found value: " + m.group(2) );
                                                    } else {
                                                        lists.add(replaceAll)
                                                    }
                                                }
                                                return lists
                                            }
                                        })
                                    } else if (expandNounTitles.get(groupPosition)
                                            .contains("Noun") || expandNounTitles.get(groupPosition)
                                            .contains("Adverb") || expandNounTitles.get(
                                            groupPosition
                                        ).contains("Adjective")
                                    ) {
                                        val ex = Executors.newSingleThreadExecutor()
                                        val   = AlertDialog. (this@WordOccuranceAct)
                                         .setCancelable(false) // if you want user to wait for some process to finish,
                                         .setView(R.layout.layout_loading_dialog)
                                        val dialog =  .create()
                                        ex.execute(object : Runnable {
                                            override fun run() {
                                                runOnUiThread({ dialog.show() })
                                                val list: MutableList<*> = ArrayList<Any?>()
                                                val verses = utils!!.getNounOccuranceBreakVerses(
                                                    split[1]
                                                )
                                                for (vers: CorpusNounWbwOccurance in verses) {
                                                    val sb = String ()
                                                    val spanDark = SpannableString(vers.qurantext)
                                                    val spannableVerses =
                                                        CorpusUtilityorig.getSpannableVerses(
                                                            vers.araone + vers.aratwo + vers.arathree + vers.arafour + vers.arafive,
                                                            vers.qurantext
                                                        )
                                                    sb.append(vers.surah).append(":")
                                                        .append(vers.ayah).append(":")
                                                        .append(vers.wordno).append("-")
                                                        .append(vers.en).append("-")
                                                    val ref = SpannableString(sb.toString())
                                                    ref.setSpan(
                                                        Constant.particlespanDark,
                                                        0,
                                                        sb.length,
                                                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                    )
                                                    val which = shared!!.getString(
                                                        "selecttranslation",
                                                        "en_sahih"
                                                    )
                                                    var trans: SpannableString? = null
                                                    if ((which == "en_sahih")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.translation)
                                                    } else if ((which == "ur_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.ur_jalalayn)
                                                    } else if ((which == "en_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.en_jalalayn)
                                                    } else if ((which == "en_arberry")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.en_arberry)
                                                    }
                                                    val charSequence = TextUtils.concat(
                                                        ref,
                                                        "\n ",
                                                        spannableVerses
                                                    )
                                                    list.add(charSequence)
                                                    list.add(trans)
                                                }
                                                runOnUiThread(object : Runnable {
                                                    override fun run() {
                                                        ex.shutdown()
                                                        dialog.dismiss()
                                                        expandNounVerses[expandNounTitles.get(
                                                            groupPosition
                                                        )] = list
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }
                                        })
                                    } else {
                                        val ex = Executors.newSingleThreadExecutor()
                                        ex.execute(object : Runnable {
                                            override fun run() {
                                                runOnUiThread(object : Runnable {
                                                    override fun run() {
                                                        dialog!!.show()
                                                    }
                                                })
                                                val list: MutableList<*> = ArrayList<Any?>()
                                                val verses =
                                                    utils!!.getVerbOccuranceBreakVerses((split[1]))
                                                for (vers: CorpusVerbWbwOccurance in verses) {
                                                    val sb = String ()
                                                    val spanDark = SpannableString(vers.qurantext)
                                                    val spannableVerses =
                                                        CorpusUtilityorig.getSpannableVerses(
                                                            vers.araone + vers.aratwo + vers.arathree + vers.arafour + vers.arafive,
                                                            vers.qurantext
                                                        )
                                                    //  SpannableString spannableString = CorpusUtilityorig.SetWordSpanNew(vers.getTagone(), vers.getTagtwo(), vers.getTagthree(), vers.getTagfour(), vers.getTagfive(),
                                                    //     vers.getAraone(), vers.getAratwo(), vers.getArathree(), vers.getArafour(), vers.getArafive());
                                                    sb.append(vers.surah).append(":")
                                                        .append(vers.ayah).append(":")
                                                        .append(vers.wordno).append("-")
                                                        .append(vers.en).append("-")
                                                    //       sb.append(vers.getSurah()).append(":").append(vers.getAyah()).append(":").append(vers.getWordno()).append("-");
                                                    vers.wordno
                                                    val ref = SpannableString(sb.toString())
                                                    ref.setSpan(
                                                        maincolortag,
                                                        0,
                                                        sb.length,
                                                        Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                                                    )
                                                    val which = shared!!.getString(
                                                        "selecttranslation",
                                                        "en_sahih"
                                                    )
                                                    var trans: SpannableString? = null
                                                    if ((which == "en_sahih")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.translation)
                                                    } else if ((which == "ur_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.ur_jalalayn)
                                                    } else if ((which == "en_jalalayn")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.en_jalalayn)
                                                    } else if ((which == "en_arberry")) {
                                                        trans =
                                                            SpannableString.valueOf(vers.en_arberry)
                                                    }
                                                    val charSequence = TextUtils.concat(
                                                        ref,
                                                        "\n ",
                                                        spannableVerses
                                                    )
                                                    list.add(charSequence)
                                                    list.add(trans)
                                                }
                                                runOnUiThread(object : Runnable {
                                                    override fun run() {
                                                        ex.shutdown()
                                                        dialog!!.dismiss()
                                                        expandNounVerses[expandNounTitles.get(
                                                            groupPosition
                                                        )] = list
                                                        listAdapter.notifyDataSetChanged()
                                                    }
                                                })
                                            }
                                        })
                                    }
                                }
                            }
                        })
                        expandableListView!!.setOnChildClickListener(object : OnChildClickListener {
                            override fun onChildClick(
                                parent: ExpandableListView, v: View,
                                groupPosition: Int, childPosition: Int, id: Long
                            ): Boolean {
                                //   final String selected = String.valueOf((SpannableString) listAdapter.getChild(
                                //      groupPosition, childPosition));
                                val child = listAdapter.getChild(
                                    groupPosition,
                                    childPosition
                                ) as CharSequence
                                val split = child.toString().split("-".toRegex())
                                    .dropLastWhile { it.isEmpty() }
                                    .toTypedArray()
                                val surahaya =
                                    split[0].split(":".toRegex()).dropLastWhile { it.isEmpty() }
                                        .toTypedArray()
                                if (surahaya.size > 1) {
                                    try {
                                        Integer.valueOf(surahaya[2])
                                    } catch (e: NumberFormatException) {
                                        return false
                                    }
                                    try {
                                        Integer.valueOf(surahaya[1])
                                    } catch (e: NumberFormatException) {
                                        return false
                                    }
                                    try {
                                        Integer.valueOf(surahaya[0])
                                    } catch (e: NumberFormatException) {
                                        return false
                                    }
                                    val wordno = surahaya[2]
                                    val ayah = surahaya[1]
                                    val surah = surahaya[0]
                                    val dataBundle = Bundle()
                                    dataBundle.putInt(Constant.SURAH_ID, surah.toInt())
                                    dataBundle.putInt(Constant.AYAHNUMBER, ayah.toInt())
                                    dataBundle.putInt(Constant.WORDNUMBER, wordno.toInt())
                                    dataBundle.putString(Constant.SURAH_ARABIC_NAME, "SurahName")
                                    LoadItemList(dataBundle, surah, ayah, wordno)
                                    return true
                                } else {
                                    return false
                                }
                            }

                            private fun LoadItemList(
                                dataBundle: Bundle,
                                surah: String,
                                ayah: String,
                                wordno: String
                            ) {
                                val item = WordAnalysisBottomSheet()
                                //    item.setdata(rootWordMeanings,wbwRootwords,grammarRootsCombined);
                                val fragmentManager = supportFragmentManager
                                item.arguments = dataBundle
                                val data = arrayOf(surah, ayah, "", wordno)
                                val transactions =
                                    fragmentManager.beginTransaction().setCustomAnimations(
                                        anim.abc_slide_in_top, android.R.anim.fade_out
                                    )
                                //     transactions.show(item);
                                WordAnalysisBottomSheet.Companion.newInstance(data).show(
                                    supportFragmentManager, WordAnalysisBottomSheet.Companion.TAG
                                )
                                //   WordAnalysisBottomSheet.newInstance(data).show(WordOccuranceAsynKAct.this).getSupportFragmentManager(), WordAnalysisBottomSheet.TAG);
                            }
                        })
                    }
                })
            }
        })
        //  ExpandableRecAdapter expandableRecAdapter=new ExpandableRecAdapter(WordOccuranceAsynKAct.this,expandNounVerses,expandNounTitles);
        //  recview.setAdapter(expandableRecAdapter);
    }

    private fun getSpannableVerses(root_a: String, quranverses: String): SpannableString  {
        val wordlen = root_a.length
        var str: SpannableString ? = null
        val indexOf = quranverses.indexOf(root_a)
        if (indexOf != -1) {
            str = SpannableString (quranverses)
            str.setSpan(
                ForegroundColorSpan(maincolortag),
                indexOf,
                indexOf + wordlen,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        } else {
            str = SpannableString (quranverses)
        }
        return str
    }

    private fun setSpanMudhafSifaShartHarfNasb(
        surah: Int,
        ayah: Int,
        mudhafEntity: ArrayList<NewMudhafEntity>,
        sifall: ArrayList<SifaEntity>,
        shartAll: ArrayList<ShartEntity>,
        nasbIndAll: ArrayList<NewNasbEntity>,
        quranverses: String
    ): SpannableString  {
        val mudhafspans = BackgroundColorSpan(Constant.MIDNIGHTBLUE)
        val sifaspans = BackgroundColorSpan(Constant.WBURNTUMBER)
        val str = SpannableString (quranverses)
        for (mudhaf: NewMudhafEntity in mudhafEntity) {
            val ayah1 = mudhaf.ayah
            val surah1 = mudhaf.surah
            val b = surah1 == surah && ayah1 == ayah
            if (b) {
                str.setSpan(
                    mudhafspans,
                    mudhaf.startindex,
                    mudhaf.endindex,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        for (sifa: SifaEntity in sifall) {
            val ayah1 = sifa.ayah
            val surah1 = sifa.surah
            val b = surah1 == surah && ayah1 == ayah
            if (b) {
                str.setSpan(
                    sifaspans,
                    sifa.startindex,
                    sifa.endindex,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        for (shartEntity: ShartEntity in shartAll) {
            val ayah1 = shartEntity.ayah
            val surah1 = shartEntity.surah
            val b = surah1 == surah && ayah1 == ayah
            if (b) {
                str.setSpan(
                    ForegroundColorSpan(Constant.GOLD),
                    shartEntity.indexstart,
                    shartEntity.indexend,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                str.setSpan(
                    ForegroundColorSpan(Color.GREEN),
                    shartEntity.shartindexstart,
                    shartEntity.shartindexend,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
                str.setSpan(
                    ForegroundColorSpan(Color.CYAN),
                    shartEntity.jawabshartindexstart,
                    shartEntity.jawabshartindexend,
                    Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
                )
            }
        }
        for (nasb: NewNasbEntity in nasbIndAll) {
            val harfofverse = ""
            val ismofverse = ""
            val khabarofinna = ""
            val start = nasb.indexstart
            val end = nasb.indexend
            val ismstart = nasb.ismstart
            val ismend = nasb.ismend
            val khabarstart = nasb.khabarstart
            val khabarend = nasb.khabarend
            str.setSpan(Constant.harfinnaspanDark, start, end, Spanned.SPAN_EXCLUSIVE_EXCLUSIVE)
            str.setSpan(
                Constant.harfismspanDark,
                ismstart,
                ismend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
            str.setSpan(
                Constant.harfkhabarspanDark,
                khabarstart,
                khabarend,
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE
            )
        }
        return str
    }

    private fun mudhaf(surah: Int, ayah: Int, verse: String): SpannableString  {
        val strs = SpannableString ()
        val split = verse.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        val occurances = utils!!.getnounoccurancebysurahayah(surah, ayah)
        return strs
    }

    companion object {
        private val REQUEST_WRITE_STORAGE = 112
        private val REQUEST_WRITE_Settings = 113
    }
}