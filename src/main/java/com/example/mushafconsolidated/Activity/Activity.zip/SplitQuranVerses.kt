package com.example.mushafconsolidated.Activityimport

import Word
import android.content.Context


class SplitQuranVerses  // --Commented out by Inspection (26/04/22, 12:48 AM):private List<CorpusAyahWord> corpusayahWordArrayList;
    (context: Context?) {
    fun splitSingleVerse(quraverses: String): ArrayList<Word> {
        val ayahWordArrayList = ArrayList<Word>()
        val s = quraverses.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        for (i in s.indices) {
            val word = Word()
            word.wordsAr = s[i]
            word.wordno = i + 1
            ayahWordArrayList.add(word)
        }
        return ayahWordArrayList
        //     return ayahWords;
    }

    fun splitSingleVerse(
        quraverses: String,
        surah: Int,
        ayah: Int,
        startwordno: Int
    ): ArrayList<Word> {
        val ayahWordArrayList = ArrayList<Word>()
        val s = quraverses.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        for (i in s.indices) {
            val word = Word()
            word.wordsAr = s[i]
            word.wordno = i + 1
            word.surahId = surah.toLong()
            word.verseId = ayah.toLong()
            word.wordcount = startwordno
            word.translate = quraverses
            ayahWordArrayList.add(word)
        }
        return ayahWordArrayList
        //     return ayahWords;
    }

    fun splitSingleVerse(quraverses: String, surah: Int, ayah: Int): ArrayList<Word> {
        val ayahWordArrayList = ArrayList<Word>()
        val s = quraverses.split(" ".toRegex()).dropLastWhile { it.isEmpty() }.toTypedArray()
        for (i in s.indices) {
            val word = Word()
            word.wordsAr = s[i]
            word.wordno = i + 1
            word.surahId = surah.toLong()
            word.verseId = ayah.toLong()
            ayahWordArrayList.add(word)
        }
        return ayahWordArrayList
        //     return ayahWords;
    }
}